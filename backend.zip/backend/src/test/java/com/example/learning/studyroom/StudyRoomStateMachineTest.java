package com.example.learning.studyroom;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.studyroom.enums.UserRoomState;
import com.example.learning.studyroom.service.StudyRoomStateMachine;
import org.junit.jupiter.api.Test;

class StudyRoomStateMachineTest {

    private final StudyRoomStateMachine stateMachine = new StudyRoomStateMachine();

    @Test
    void shouldExposeFocusingAsInitialState() {
        assertEquals(UserRoomState.FOCUSING, stateMachine.initialState());
    }

    @Test
    void shouldAllowReconnectPathTransitions() {
        assertDoesNotThrow(() -> stateMachine.assertTransition(UserRoomState.FOCUSING, UserRoomState.DISCONNECTED));
        assertDoesNotThrow(() -> stateMachine.assertTransition(UserRoomState.DISCONNECTED, UserRoomState.FOCUSING));
        assertDoesNotThrow(() -> stateMachine.assertTransition(UserRoomState.BREAK, UserRoomState.LEFT));
    }

    @Test
    void shouldRejectInvalidTransitions() {
        BusinessException exception = assertThrows(BusinessException.class,
                () -> stateMachine.assertTransition(UserRoomState.LEFT, UserRoomState.FOCUSING));

        assertEquals(ErrorCode.STUDY_ROOM_STATE_INVALID, exception.getErrorCode());
    }
}
