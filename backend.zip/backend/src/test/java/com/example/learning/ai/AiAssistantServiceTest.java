package com.example.learning.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.ai.client.AiClientTimeoutException;
import com.example.learning.ai.client.AiMicroserviceClient;
import com.example.learning.ai.config.AiServiceProperties;
import com.example.learning.ai.dto.AiAskRequestDTO;
import com.example.learning.ai.entity.AiCallLogEntity;
import com.example.learning.ai.entity.AiConversationEntity;
import com.example.learning.ai.entity.AiMessageEntity;
import com.example.learning.ai.enums.AiCallStatus;
import com.example.learning.ai.enums.AiInputType;
import com.example.learning.ai.mapper.AiCallLogMapper;
import com.example.learning.ai.mapper.AiConversationMapper;
import com.example.learning.ai.mapper.AiMessageMapper;
import com.example.learning.ai.model.AiAnswerPayload;
import com.example.learning.ai.model.AiRecommendationPayload;
import com.example.learning.ai.service.AiRateLimitService;
import com.example.learning.ai.service.impl.AiAssistantServiceImpl;
import com.example.learning.ai.vo.AiAssistantResponseVO;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AiAssistantServiceTest {

    @Mock
    private AiConversationMapper aiConversationMapper;
    @Mock
    private AiMessageMapper aiMessageMapper;
    @Mock
    private AiCallLogMapper aiCallLogMapper;
    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseEnrollmentMapper courseEnrollmentMapper;
    @Mock
    private CourseResourceMapper courseResourceMapper;
    @Mock
    private AiRateLimitService aiRateLimitService;
    @Mock
    private AiMicroserviceClient aiMicroserviceClient;

    private AiAssistantServiceImpl aiAssistantService;

    @BeforeEach
    void setUp() {
        AiServiceProperties properties = new AiServiceProperties();
        Clock fixedClock = Clock.fixed(Instant.parse("2026-05-19T06:00:00Z"), ZoneOffset.UTC);
        aiAssistantService = new AiAssistantServiceImpl(
                aiConversationMapper,
                aiMessageMapper,
                aiCallLogMapper,
                courseMapper,
                courseEnrollmentMapper,
                courseResourceMapper,
                aiRateLimitService,
                aiMicroserviceClient,
                properties,
                new ObjectMapper(),
                fixedClock
        );
        when(aiConversationMapper.save(any(AiConversationEntity.class))).thenAnswer(invocation -> {
            AiConversationEntity entity = invocation.getArgument(0);
            if (entity.getId() == null) {
                entity.setId(11L);
            }
            return entity;
        });
        when(aiMessageMapper.save(any(AiMessageEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(aiCallLogMapper.save(any(AiCallLogEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(publishedCourse()));
        when(courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(1L, 1001L)).thenReturn(true);
    }

    @Test
    void shouldReturnAiResponseAndSaveCallLogWhenAiServiceSucceeds() {
        AiAskRequestDTO requestDTO = new AiAskRequestDTO();
        requestDTO.setCourseId(1L);
        requestDTO.setQuestion("递归和迭代有什么区别？");

        AiRecommendationPayload existing = new AiRecommendationPayload();
        existing.setType("VIDEO");
        existing.setResourceId(9001L);
        existing.setReason("可复习递归基础");
        AiRecommendationPayload missing = new AiRecommendationPayload();
        missing.setType("VIDEO");
        missing.setResourceId(9002L);
        missing.setReason("不存在的资源");
        AiAnswerPayload payload = new AiAnswerPayload();
        payload.setQuestionText("递归和迭代有什么区别？");
        payload.setKnowledgePoints(List.of("递归", "迭代"));
        payload.setDifficulty("MEDIUM");
        payload.setSolutionSteps(List.of("先看定义", "再看调用方式"));
        payload.setMistakeAnalysis("容易忽略调用栈差异。");
        payload.setRecommendations(List.of(existing, missing));

        CourseResourceEntity resource = new CourseResourceEntity();
        resource.setId(9001L);
        resource.setDeleted(false);
        when(courseResourceMapper.findAllById(any())).thenReturn(List.of(resource));
        when(aiMicroserviceClient.ask(1001L, 1L, "递归和迭代有什么区别？")).thenReturn(payload);

        AiAssistantResponseVO response = aiAssistantService.askQuestion(1001L, requestDTO);

        assertFalse(response.getDegraded());
        assertEquals(1, response.getRecommendations().size());
        verify(aiRateLimitService).assertAllowed(1001L, AiInputType.TEXT);

        ArgumentCaptor<AiCallLogEntity> logCaptor = ArgumentCaptor.forClass(AiCallLogEntity.class);
        verify(aiCallLogMapper).save(logCaptor.capture());
        assertEquals(AiCallStatus.SUCCESS, logCaptor.getValue().getStatus());
    }

    @Test
    void shouldReturnFallbackAndSaveCallLogWhenAiServiceTimesOut() {
        AiAskRequestDTO requestDTO = new AiAskRequestDTO();
        requestDTO.setCourseId(1L);
        requestDTO.setQuestion("什么是尾递归？");

        when(aiMicroserviceClient.ask(1001L, 1L, "什么是尾递归？"))
                .thenThrow(new AiClientTimeoutException("timeout", new RuntimeException("timeout")));

        AiAssistantResponseVO response = aiAssistantService.askQuestion(1001L, requestDTO);

        assertTrue(response.getDegraded());
        assertEquals("AI 助教暂时繁忙，请稍后重试，或先查看课程资源和错题解析。", response.getMessage());

        ArgumentCaptor<AiCallLogEntity> logCaptor = ArgumentCaptor.forClass(AiCallLogEntity.class);
        verify(aiCallLogMapper).save(logCaptor.capture());
        assertEquals(AiCallStatus.FALLBACK, logCaptor.getValue().getStatus());
    }

    private CourseEntity publishedCourse() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(2001L);
        course.setStatus(CourseStatus.PUBLISHED);
        return course;
    }
}
