package com.example.learning.course;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.dto.CourseCreateDTO;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.service.impl.TeacherCourseServiceImpl;
import com.example.learning.course.storage.FileStorageService;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.mapper.UserMapper;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TeacherCourseServiceTest {

    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseChapterMapper courseChapterMapper;
    @Mock
    private CourseResourceMapper courseResourceMapper;
    @Mock
    private UserMapper userMapper;
    @Mock
    private FileStorageService fileStorageService;

    @InjectMocks
    private TeacherCourseServiceImpl teacherCourseService;

    @Test
    void shouldCreateCourseWhenTeacherCreatesCourse() {
        CourseCreateDTO dto = new CourseCreateDTO();
        dto.setTitle("Java Programming");
        dto.setSummary("Intro course");
        dto.setCategory("Programming");
        dto.setDifficulty("BEGINNER");

        UserEntity teacher = new UserEntity();
        teacher.setId(1001L);
        teacher.setUsername("teacher001");
        teacher.setNickname("张老师");
        when(userMapper.findByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(teacher));
        when(courseMapper.save(any(CourseEntity.class))).thenAnswer(invocation -> {
            CourseEntity entity = invocation.getArgument(0);
            entity.setId(1L);
            return entity;
        });

        CourseDetailVO result = teacherCourseService.createCourse(1001L, dto);

        ArgumentCaptor<CourseEntity> captor = ArgumentCaptor.forClass(CourseEntity.class);
        verify(courseMapper).save(captor.capture());
        assertEquals(CourseStatus.DRAFT, captor.getValue().getStatus());
        assertEquals(1001L, captor.getValue().getTeacherId());
        assertEquals("张老师", captor.getValue().getTeacherName());
        assertEquals(CourseStatus.DRAFT.name(), result.getStatus());
        assertEquals("Java Programming", result.getTitle());
    }

    @Test
    void shouldRejectUpdateWhenTeacherDoesNotOwnCourse() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(2002L);
        course.setStatus(CourseStatus.DRAFT);
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> teacherCourseService.updateCourse(1001L, 1L, new com.example.learning.course.dto.CourseUpdateDTO()));

        assertEquals(ErrorCode.COURSE_OWNER_REQUIRED, exception.getErrorCode());
    }

    @Test
    void shouldSubmitCourseForReviewWhenStatusIsDraft() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(1001L);
        course.setTitle("Java Programming");
        course.setStatus(CourseStatus.DRAFT);
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));
        when(courseMapper.save(any(CourseEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CourseDetailVO result = teacherCourseService.submitReview(1001L, 1L);

        assertEquals(CourseStatus.PENDING.name(), result.getStatus());
        assertEquals(CourseStatus.PENDING, course.getStatus());
    }

    @Test
    void shouldRejectSubmitReviewWhenCourseStatusIsNotDraft() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(1001L);
        course.setStatus(CourseStatus.PUBLISHED);
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> teacherCourseService.submitReview(1001L, 1L));

        assertEquals(ErrorCode.COURSE_STATUS_INVALID, exception.getErrorCode());
    }
}
