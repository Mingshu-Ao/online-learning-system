package com.example.learning.knowledge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.knowledge.dto.KnowledgeRelationUpdateDTO;
import com.example.learning.knowledge.entity.KnowledgePointEntity;
import com.example.learning.knowledge.entity.KnowledgeRelationEntity;
import com.example.learning.knowledge.mapper.KnowledgePointMapper;
import com.example.learning.knowledge.mapper.KnowledgeRelationMapper;
import com.example.learning.knowledge.mapper.KnowledgeResourceMapper;
import com.example.learning.knowledge.service.impl.TeacherKnowledgeServiceImpl;
import com.example.learning.quiz.mapper.QuestionMapper;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TeacherKnowledgeServiceTest {

    @Mock
    private KnowledgePointMapper knowledgePointMapper;
    @Mock
    private KnowledgeRelationMapper knowledgeRelationMapper;
    @Mock
    private KnowledgeResourceMapper knowledgeResourceMapper;
    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseChapterMapper courseChapterMapper;
    @Mock
    private CourseResourceMapper courseResourceMapper;
    @Mock
    private QuestionMapper questionMapper;

    private TeacherKnowledgeServiceImpl teacherKnowledgeService;

    @BeforeEach
    void setUp() {
        teacherKnowledgeService = new TeacherKnowledgeServiceImpl(
                knowledgePointMapper,
                knowledgeRelationMapper,
                knowledgeResourceMapper,
                courseMapper,
                courseChapterMapper,
                courseResourceMapper,
                questionMapper
        );
    }

    @Test
    void shouldRejectWhenKnowledgeDependenciesCreateCycle() {
        KnowledgePointEntity pointA = knowledgePoint(1L, "A");
        KnowledgePointEntity pointB = knowledgePoint(2L, "B");
        KnowledgePointEntity pointC = knowledgePoint(3L, "C");
        CourseEntity course = ownedCourse();

        KnowledgeRelationEntity relationAB = relation(1L, 2L);
        KnowledgeRelationEntity relationBC = relation(2L, 3L);
        KnowledgeRelationUpdateDTO updateDTO = new KnowledgeRelationUpdateDTO();
        updateDTO.setPrerequisiteIds(List.of(1L));

        when(knowledgePointMapper.findByIdAndDeletedFalse(3L)).thenReturn(Optional.of(pointC));
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));
        when(knowledgePointMapper.findAllByIdInAndDeletedFalse(java.util.Set.of(1L))).thenReturn(List.of(pointA));
        when(knowledgeRelationMapper.findAllByCourseIdAndDeletedFalse(1L)).thenReturn(List.of(relationAB, relationBC));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> teacherKnowledgeService.updatePrerequisites(2001L, 3L, updateDTO));

        assertEquals(ErrorCode.BAD_REQUEST, exception.getErrorCode());
    }

    private CourseEntity ownedCourse() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(2001L);
        return course;
    }

    private KnowledgePointEntity knowledgePoint(Long id, String name) {
        KnowledgePointEntity entity = new KnowledgePointEntity();
        entity.setId(id);
        entity.setCourseId(1L);
        entity.setTeacherId(2001L);
        entity.setName(name);
        return entity;
    }

    private KnowledgeRelationEntity relation(Long pointId, Long prerequisiteId) {
        KnowledgeRelationEntity entity = new KnowledgeRelationEntity();
        entity.setCourseId(1L);
        entity.setKnowledgePointId(pointId);
        entity.setPrerequisiteId(prerequisiteId);
        return entity;
    }
}
