package com.example.learning.quiz;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.quiz.service.StudentExamService;
import com.example.learning.quiz.vo.ExamResultQuestionVO;
import com.example.learning.quiz.vo.ExamResultVO;
import com.example.learning.quiz.vo.ExamStartVO;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.PaperQuestionVO;
import com.example.learning.quiz.vo.QuestionOptionVO;
import com.example.learning.security.SecurityUser;
import com.example.learning.user.enums.UserStatus;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class StudentExamControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StudentExamService studentExamService;

    @Test
    void shouldRejectAnonymousUserWhenGettingPaper() throws Exception {
        mockMvc.perform(get("/api/student/papers/1"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value(40100));
    }

    @Test
    void shouldStartExamForStudentRole() throws Exception {
        when(studentExamService.startExam(1L, 1L)).thenReturn(ExamStartVO.builder()
                .examRecordId(10001L)
                .paperId(1L)
                .startTime(LocalDateTime.of(2026, 5, 19, 10, 0))
                .endTime(LocalDateTime.of(2026, 5, 19, 11, 0))
                .build());

        mockMvc.perform(post("/api/student/exams/1/start")
                        .with(authentication(studentAuthentication())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.examRecordId").value(10001));
    }

    @Test
    void shouldSubmitExamWithApiResponseEnvelope() throws Exception {
        when(studentExamService.submitExam(any(), any(), any())).thenReturn(ExamResultVO.builder()
                .examRecordId(10001L)
                .paperId(1L)
                .status("COMPLETED")
                .objectiveScore(new BigDecimal("10.00"))
                .totalScore(new BigDecimal("10.00"))
                .passed(Boolean.TRUE)
                .pendingReview(Boolean.FALSE)
                .questions(List.of(ExamResultQuestionVO.builder()
                        .questionId(1L)
                        .stem("2 + 2 = ?")
                        .questionType("SINGLE_CHOICE")
                        .fullScore(new BigDecimal("10.00"))
                        .awardedScore(new BigDecimal("10.00"))
                        .correct(Boolean.TRUE)
                        .needsManualReview(Boolean.FALSE)
                        .analysis("基础加法")
                        .options(List.of(new QuestionOptionVO("A", "4")))
                        .build()))
                .build());

        mockMvc.perform(post("/api/student/exams/10001/submit")
                        .with(authentication(studentAuthentication()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "answers": [
                                    {
                                      "questionId": 1,
                                      "answer": "A"
                                    }
                                  ]
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.status").value("COMPLETED"))
                .andExpect(jsonPath("$.data.questions[0].questionType").value("SINGLE_CHOICE"));
    }

    @Test
    void shouldReturnPaperDetailForStudentRole() throws Exception {
        when(studentExamService.getPaper(1L, 1L)).thenReturn(PaperDetailVO.builder()
                .id(1L)
                .title("Java 基础测验")
                .courseId(1L)
                .totalScore(new BigDecimal("10.00"))
                .passScore(new BigDecimal("6.00"))
                .durationMinutes(30)
                .published(Boolean.TRUE)
                .questions(List.of(PaperQuestionVO.builder()
                        .questionId(1L)
                        .stem("2 + 2 = ?")
                        .questionType("SINGLE_CHOICE")
                        .score(new BigDecimal("10.00"))
                        .partialCreditEnabled(Boolean.FALSE)
                        .options(List.of(new QuestionOptionVO("A", "4")))
                        .build()))
                .build());

        mockMvc.perform(get("/api/student/papers/1")
                        .with(authentication(studentAuthentication())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.title").value("Java 基础测验"))
                .andExpect(jsonPath("$.data.questions[0].stem").value("2 + 2 = ?"));
    }

    private UsernamePasswordAuthenticationToken studentAuthentication() {
        SecurityUser securityUser = SecurityUser.builder()
                .id(1L)
                .username("student001")
                .password("bcrypt")
                .nickname("Alice")
                .status(UserStatus.ENABLED)
                .tokenVersion(0)
                .authorities(List.of(new SimpleGrantedAuthority("ROLE_STUDENT")))
                .build();
        return new UsernamePasswordAuthenticationToken(securityUser, null, securityUser.getAuthorities());
    }
}
