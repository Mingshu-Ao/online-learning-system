package com.example.learning.quiz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.quiz.dto.ExamAnswerItemDTO;
import com.example.learning.quiz.dto.StudentExamSubmitDTO;
import com.example.learning.quiz.entity.ExamRecordEntity;
import com.example.learning.quiz.entity.PaperQuestionEntity;
import com.example.learning.quiz.entity.UserAnswerEntity;
import com.example.learning.quiz.entity.WrongQuestionEntity;
import com.example.learning.quiz.enums.ExamRecordStatus;
import com.example.learning.quiz.enums.QuestionType;
import com.example.learning.quiz.enums.WrongQuestionStatus;
import com.example.learning.quiz.mapper.ExamRecordMapper;
import com.example.learning.quiz.mapper.PaperMapper;
import com.example.learning.quiz.mapper.PaperQuestionMapper;
import com.example.learning.quiz.mapper.UserAnswerMapper;
import com.example.learning.quiz.mapper.WrongQuestionMapper;
import com.example.learning.quiz.service.QuizScoringService;
import com.example.learning.quiz.service.impl.StudentExamServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class StudentExamServiceTest {

    @Mock
    private PaperMapper paperMapper;
    @Mock
    private PaperQuestionMapper paperQuestionMapper;
    @Mock
    private ExamRecordMapper examRecordMapper;
    @Mock
    private UserAnswerMapper userAnswerMapper;
    @Mock
    private WrongQuestionMapper wrongQuestionMapper;
    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseEnrollmentMapper courseEnrollmentMapper;
    @Mock
    private QuizScoringService quizScoringService;

    private StudentExamServiceImpl studentExamService;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        Clock fixedClock = Clock.fixed(Instant.parse("2026-05-19T10:00:00Z"), ZoneOffset.UTC);
        studentExamService = new StudentExamServiceImpl(
                paperMapper,
                paperQuestionMapper,
                examRecordMapper,
                userAnswerMapper,
                wrongQuestionMapper,
                courseMapper,
                courseEnrollmentMapper,
                quizScoringService,
                objectMapper,
                fixedClock
        );
    }

    @Test
    void shouldCreateWrongQuestionWhenAnswerIncorrect() throws Exception {
        ExamRecordEntity examRecord = new ExamRecordEntity();
        examRecord.setId(1001L);
        examRecord.setPaperId(10L);
        examRecord.setCourseId(1L);
        examRecord.setUserId(2001L);
        examRecord.setStatus(ExamRecordStatus.IN_PROGRESS);
        examRecord.setPassScore(new BigDecimal("6.00"));
        examRecord.setDeadlineTime(LocalDateTime.of(2026, 5, 19, 10, 30));

        PaperQuestionEntity paperQuestion = new PaperQuestionEntity();
        paperQuestion.setId(501L);
        paperQuestion.setQuestionId(301L);
        paperQuestion.setChapterId(11L);
        paperQuestion.setQuestionType(QuestionType.SINGLE_CHOICE);
        paperQuestion.setQuestionStem("2 + 2 = ?");
        paperQuestion.setOptionSnapshot("[{\"optionKey\":\"A\",\"content\":\"3\"},{\"optionKey\":\"B\",\"content\":\"4\"}]");
        paperQuestion.setStandardAnswer("\"B\"");
        paperQuestion.setAnalysis("基础加法");
        paperQuestion.setKnowledgePoint("整数运算");
        paperQuestion.setScore(new BigDecimal("10.00"));
        paperQuestion.setPartialCreditEnabled(Boolean.FALSE);

        ExamAnswerItemDTO answerItemDTO = new ExamAnswerItemDTO();
        answerItemDTO.setQuestionId(301L);
        answerItemDTO.setAnswer(objectMapper.readTree("\"A\""));
        StudentExamSubmitDTO submitDTO = new StudentExamSubmitDTO();
        submitDTO.setAnswers(List.of(answerItemDTO));

        WrongQuestionEntity existingWrongQuestion = new WrongQuestionEntity();
        existingWrongQuestion.setId(9001L);
        existingWrongQuestion.setUserId(2001L);
        existingWrongQuestion.setQuestionId(301L);
        existingWrongQuestion.setWrongCount(1);
        existingWrongQuestion.setStatus(WrongQuestionStatus.REVIEWING);

        when(examRecordMapper.findWithLockByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(examRecord));
        when(examRecordMapper.findByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(examRecord));
        when(paperQuestionMapper.findAllByPaperIdAndDeletedFalseOrderBySortOrderAsc(10L)).thenReturn(List.of(paperQuestion));
        when(quizScoringService.score(any(PaperQuestionEntity.class), any()))
                .thenReturn(new QuizScoringService.ScoringResult(BigDecimal.ZERO, Boolean.FALSE, true, false));
        when(userAnswerMapper.saveAll(any())).thenAnswer(invocation -> {
            List<UserAnswerEntity> answers = invocation.getArgument(0);
            answers.get(0).setId(7001L);
            return answers;
        });
        when(examRecordMapper.save(any(ExamRecordEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(wrongQuestionMapper.findFirstByUserIdAndQuestionIdAndDeletedFalseOrderByCreatedAtDesc(2001L, 301L))
                .thenReturn(Optional.of(existingWrongQuestion));
        when(wrongQuestionMapper.save(any(WrongQuestionEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        studentExamService.submitExam(2001L, 1001L, submitDTO);

        ArgumentCaptor<WrongQuestionEntity> captor = ArgumentCaptor.forClass(WrongQuestionEntity.class);
        verify(wrongQuestionMapper).save(captor.capture());
        assertEquals(WrongQuestionStatus.UNMASTERED, captor.getValue().getStatus());
        assertEquals(2, captor.getValue().getWrongCount());
        assertEquals(7001L, captor.getValue().getLatestUserAnswerId());
    }

    @Test
    void shouldRejectSubmitWhenExamAlreadySubmitted() {
        ExamRecordEntity examRecord = new ExamRecordEntity();
        examRecord.setId(1001L);
        examRecord.setUserId(2001L);
        examRecord.setStatus(ExamRecordStatus.COMPLETED);

        when(examRecordMapper.findWithLockByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(examRecord));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> studentExamService.submitExam(2001L, 1001L, new StudentExamSubmitDTO()));

        assertEquals(ErrorCode.EXAM_ALREADY_SUBMITTED, exception.getErrorCode());
    }

    @Test
    void shouldRejectSubmitWhenDeadlineHasPassed() {
        ExamRecordEntity examRecord = new ExamRecordEntity();
        examRecord.setId(1001L);
        examRecord.setPaperId(10L);
        examRecord.setCourseId(1L);
        examRecord.setUserId(2001L);
        examRecord.setStatus(ExamRecordStatus.IN_PROGRESS);
        examRecord.setDeadlineTime(LocalDateTime.of(2026, 5, 19, 9, 59, 59));

        when(examRecordMapper.findWithLockByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(examRecord));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> studentExamService.submitExam(2001L, 1001L, new StudentExamSubmitDTO()));

        assertEquals(ErrorCode.EXAM_EXPIRED, exception.getErrorCode());
    }
}
