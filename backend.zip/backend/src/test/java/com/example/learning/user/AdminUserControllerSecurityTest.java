
package com.example.learning.user;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.common.vo.PageResultVO;
import com.example.learning.user.controller.AdminUserController;
import com.example.learning.user.service.AdminUserService;
import com.example.learning.user.vo.UserListItemVO;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AdminUserControllerSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminUserService adminUserService;

    @Test
    @WithMockUser(username = "student001", authorities = {"course:read"})
    void shouldReturnForbiddenWhenPermissionIsInsufficient() throws Exception {
        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40300));
    }

    @Test
    @WithMockUser(username = "admin", authorities = {"ROLE_ADMIN", "user:read"})
    void shouldAllowAccessWhenPermissionExists() throws Exception {
        when(adminUserService.listUsers(any())).thenReturn(PageResultVO.<UserListItemVO>builder()
                .total(1)
                .records(List.of(UserListItemVO.builder()
                        .id(1L)
                        .username("student001")
                        .nickname("Student One")
                        .status("ENABLED")
                        .roles(List.of("STUDENT"))
                        .build()))
                .build());

        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.total").value(1));
    }
}
