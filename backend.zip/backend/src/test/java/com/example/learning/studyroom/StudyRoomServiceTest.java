package com.example.learning.studyroom;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.studyroom.entity.RoomCheckinEntity;
import com.example.learning.studyroom.entity.RoomRecordEntity;
import com.example.learning.studyroom.entity.StudyRoomEntity;
import com.example.learning.studyroom.entity.StudyRoomSeatEntity;
import com.example.learning.studyroom.enums.RoomRecordStatus;
import com.example.learning.studyroom.enums.SeatStatus;
import com.example.learning.studyroom.enums.StudyRoomStatus;
import com.example.learning.studyroom.enums.UserRoomState;
import com.example.learning.studyroom.mapper.RoomCheckinMapper;
import com.example.learning.studyroom.mapper.RoomRecordMapper;
import com.example.learning.studyroom.mapper.StudyRoomMapper;
import com.example.learning.studyroom.mapper.StudyRoomSeatMapper;
import com.example.learning.studyroom.realtime.StudyRoomRealtimeStore;
import com.example.learning.studyroom.service.StudyRoomStateMachine;
import com.example.learning.studyroom.service.impl.StudyRoomServiceImpl;
import com.example.learning.studyroom.vo.StudyRoomJoinVO;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.websocket.StudyRoomBroadcastService;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class StudyRoomServiceTest {

    @Mock
    private StudyRoomMapper studyRoomMapper;
    @Mock
    private StudyRoomSeatMapper studyRoomSeatMapper;
    @Mock
    private RoomRecordMapper roomRecordMapper;
    @Mock
    private RoomCheckinMapper roomCheckinMapper;
    @Mock
    private UserMapper userMapper;
    @Mock
    private StudyRoomRealtimeStore realtimeStore;
    @Mock
    private StudyRoomBroadcastService broadcastService;

    private StudyRoomServiceImpl studyRoomService;

    @BeforeEach
    void setUp() {
        Clock fixedClock = Clock.fixed(Instant.parse("2026-05-19T05:00:00Z"), ZoneOffset.UTC);
        studyRoomService = new StudyRoomServiceImpl(
                studyRoomMapper,
                studyRoomSeatMapper,
                roomRecordMapper,
                roomCheckinMapper,
                userMapper,
                realtimeStore,
                new StudyRoomStateMachine(),
                broadcastService,
                fixedClock
        );
    }

    @Test
    void shouldAssignSeatWhenStudentJoinsRoom() {
        StudyRoomEntity room = openRoom();
        UserEntity user = new UserEntity();
        user.setId(1001L);
        user.setUsername("student001");
        user.setNickname("Alice");
        StudyRoomSeatEntity seat1 = seat(1, SeatStatus.EMPTY);
        StudyRoomSeatEntity seat2 = seat(2, SeatStatus.EMPTY);
        StudyRoomRealtimeStore.RoomMembership membership = new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 2, "Alice", UserRoomState.FOCUSING);

        when(studyRoomMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(room));
        when(studyRoomSeatMapper.findAllByRoomIdAndDeletedFalseOrderBySeatNoAsc(1L)).thenReturn(List.of(seat1, seat2));
        when(userMapper.findByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(user));
        when(realtimeStore.joinRoom(eq(1L), eq(1001L), eq("Alice"), any())).thenReturn(membership);

        StudyRoomJoinVO result = studyRoomService.joinRoom(1001L, 1L);

        assertEquals(2, result.getSeatNo());
        assertEquals("FOCUSING", result.getState());
        verify(broadcastService).bindUserToRoom(1001L, 1L);
        verify(realtimeStore).joinRoom(eq(1L), eq(1001L), eq("Alice"), eq(List.of(1, 2)));
    }

    @Test
    void shouldRejectJoinRoomWhenRoomIsFull() {
        StudyRoomEntity room = openRoom();
        UserEntity user = new UserEntity();
        user.setId(1001L);
        user.setUsername("student001");
        user.setNickname("Alice");
        when(studyRoomMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(room));
        when(studyRoomSeatMapper.findAllByRoomIdAndDeletedFalseOrderBySeatNoAsc(1L)).thenReturn(List.of(seat(1, SeatStatus.EMPTY)));
        when(userMapper.findByIdAndDeletedFalse(1001L)).thenReturn(Optional.of(user));
        when(realtimeStore.joinRoom(eq(1L), eq(1001L), eq("Alice"), any()))
                .thenThrow(new BusinessException(ErrorCode.STUDY_ROOM_FULL));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> studyRoomService.joinRoom(1001L, 1L));

        assertEquals(ErrorCode.STUDY_ROOM_FULL, exception.getErrorCode());
    }

    @Test
    void shouldTransitionToBreakWhenStateChangeIsAllowed() {
        StudyRoomRealtimeStore.RoomMembership current = new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 1, "Alice", UserRoomState.FOCUSING);
        StudyRoomRealtimeStore.RoomMembership updated = new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 1, "Alice", UserRoomState.BREAK);

        when(realtimeStore.findMembership(1001L)).thenReturn(Optional.of(current));
        when(realtimeStore.changeState(1L, 1001L, UserRoomState.BREAK)).thenReturn(updated);

        studyRoomService.changeUserState(1001L, 1L, UserRoomState.BREAK);

        verify(realtimeStore).changeState(1L, 1001L, UserRoomState.BREAK);
    }

    @Test
    void shouldCreateRoomRecordWhenTimerFinishes() {
        StudyRoomRealtimeStore.RoomMembership membership = new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 1, "Alice", UserRoomState.FOCUSING);
        StudyRoomRealtimeStore.TimerInfo timerInfo = new StudyRoomRealtimeStore.TimerInfo(
                "timer-1",
                25,
                LocalDateTime.of(2026, 5, 19, 13, 0),
                LocalDateTime.of(2026, 5, 19, 13, 25)
        );

        when(realtimeStore.findMembership(1001L)).thenReturn(Optional.of(membership));
        when(realtimeStore.finishTimer(1L, 1001L, "timer-1")).thenReturn(Optional.of(timerInfo));
        when(roomRecordMapper.findBySessionTokenAndDeletedFalse("timer-1")).thenReturn(Optional.empty());
        when(roomCheckinMapper.findByRoomIdAndUserIdAndCheckinDateAndDeletedFalse(1L, 1001L, LocalDate.of(2026, 5, 19)))
                .thenReturn(Optional.empty());

        studyRoomService.finishTimer(1001L, 1L, "timer-1");

        ArgumentCaptor<RoomRecordEntity> recordCaptor = ArgumentCaptor.forClass(RoomRecordEntity.class);
        verify(roomRecordMapper).save(recordCaptor.capture());
        assertEquals(RoomRecordStatus.COMPLETED, recordCaptor.getValue().getStatus());
        assertEquals(25, recordCaptor.getValue().getFocusMinutes());

        ArgumentCaptor<RoomCheckinEntity> checkinCaptor = ArgumentCaptor.forClass(RoomCheckinEntity.class);
        verify(roomCheckinMapper).save(checkinCaptor.capture());
        assertEquals(25, checkinCaptor.getValue().getTotalFocusMinutes());
        assertEquals(1, checkinCaptor.getValue().getCompletedCount());
    }

    @Test
    void shouldRejectTimerStartWhenDurationIsUnsupported() {
        BusinessException exception = assertThrows(BusinessException.class,
                () -> studyRoomService.startTimer(1001L, 1L, 30));

        assertEquals(ErrorCode.STUDY_ROOM_TIMER_INVALID, exception.getErrorCode());
    }

    @Test
    void shouldReconnectWhenUserReturnsBeforeDisconnectTtlExpires() {
        StudyRoomRealtimeStore.RoomMembership restored = new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 1, "Alice", UserRoomState.FOCUSING);
        when(realtimeStore.reconnect(1L, 1001L)).thenReturn(restored);

        studyRoomService.reconnect(1001L, 1L);

        verify(broadcastService).bindUserToRoom(1001L, 1L);
        verify(realtimeStore).reconnect(1L, 1001L);
    }

    @Test
    void shouldMarkUserDisconnectedWhenLastSocketCloses() {
        StudyRoomRealtimeStore.RoomMembership current = new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 1, "Alice", UserRoomState.FOCUSING);
        when(realtimeStore.findMembership(1001L)).thenReturn(Optional.of(current));
        when(realtimeStore.markDisconnected(eq(1L), eq(1001L), eq(UserRoomState.FOCUSING), any()))
                .thenReturn(new StudyRoomRealtimeStore.RoomMembership(1L, 1001L, 1, "Alice", UserRoomState.DISCONNECTED));

        studyRoomService.handleSocketDisconnected(1001L);

        verify(realtimeStore).markDisconnected(eq(1L), eq(1001L), eq(UserRoomState.FOCUSING), any());
    }

    private StudyRoomEntity openRoom() {
        StudyRoomEntity room = new StudyRoomEntity();
        room.setId(1L);
        room.setRoomName("Room A");
        room.setCapacity(2);
        room.setOpenTime(LocalDateTime.of(2026, 5, 19, 0, 0));
        room.setCloseTime(LocalDateTime.of(2026, 5, 19, 23, 59));
        room.setStatus(StudyRoomStatus.OPEN);
        return room;
    }

    private StudyRoomSeatEntity seat(int seatNo, SeatStatus status) {
        StudyRoomSeatEntity seat = new StudyRoomSeatEntity();
        seat.setRoomId(1L);
        seat.setSeatNo(seatNo);
        seat.setStatus(status);
        return seat;
    }
}
