package com.example.learning.admin;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.admin.service.AdminDashboardService;
import com.example.learning.admin.vo.AdminDashboardVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AdminDashboardControllerSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminDashboardService adminDashboardService;

    @Test
    @WithMockUser(username = "ops", authorities = {"dashboard:read"})
    void shouldReturnForbiddenWhenAdminRoleIsMissing() throws Exception {
        mockMvc.perform(get("/api/admin/dashboard"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40300));
    }

    @Test
    @WithMockUser(username = "admin", authorities = {"ROLE_ADMIN", "dashboard:read"})
    void shouldAllowDashboardWhenRoleAndPermissionExist() throws Exception {
        when(adminDashboardService.getDashboard()).thenReturn(AdminDashboardVO.builder()
                .totalUsers(10)
                .dailyActiveUsers(3)
                .totalCourses(5)
                .todayLearningDurationSeconds(3600)
                .currentStudyRoomOnlineUsers(8)
                .todayAiCallCount(12)
                .build());

        mockMvc.perform(get("/api/admin/dashboard"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.totalUsers").value(10));
    }
}
