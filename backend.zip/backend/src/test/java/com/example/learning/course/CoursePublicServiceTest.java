package com.example.learning.course;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.service.impl.CoursePublicServiceImpl;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CoursePublicServiceTest {

    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseChapterMapper courseChapterMapper;
    @Mock
    private CourseResourceMapper courseResourceMapper;

    @InjectMocks
    private CoursePublicServiceImpl coursePublicService;

    @Test
    void shouldRejectDetailWhenCourseIsNotPublished() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setStatus(CourseStatus.DRAFT);
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> coursePublicService.getPublishedCourseDetail(1L));

        assertEquals(ErrorCode.COURSE_NOT_PUBLISHED, exception.getErrorCode());
    }
}
