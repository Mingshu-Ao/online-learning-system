package com.example.learning.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.ai.config.AiServiceProperties;
import com.example.learning.ai.enums.AiInputType;
import com.example.learning.ai.service.impl.AiRateLimitServiceImpl;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import java.time.Duration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

@ExtendWith(MockitoExtension.class)
class AiRateLimitServiceTest {

    @Mock
    private StringRedisTemplate redisTemplate;
    @Mock
    private ValueOperations<String, String> valueOperations;

    private AiRateLimitServiceImpl rateLimitService;

    @BeforeEach
    void setUp() {
        AiServiceProperties properties = new AiServiceProperties();
        properties.setTextRequestsPerMinute(10);
        properties.setImageRequestsPerMinute(3);
        rateLimitService = new AiRateLimitServiceImpl(redisTemplate, properties);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    }

    @Test
    void shouldAllowWhenTextRequestIsWithinLimit() {
        when(valueOperations.increment("ai:ratelimit:user:1001:text")).thenReturn(1L);

        rateLimitService.assertAllowed(1001L, AiInputType.TEXT);

        verify(redisTemplate).expire("ai:ratelimit:user:1001:text", Duration.ofMinutes(1));
    }

    @Test
    void shouldRejectWhenImageRequestExceedsLimit() {
        when(valueOperations.increment("ai:ratelimit:user:1001:image")).thenReturn(4L);

        BusinessException exception = assertThrows(BusinessException.class,
                () -> rateLimitService.assertAllowed(1001L, AiInputType.IMAGE));

        assertEquals(ErrorCode.CONFLICT, exception.getErrorCode());
    }
}
