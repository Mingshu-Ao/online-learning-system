package com.example.learning.audit;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AuditSanitizerTest {

    private final AuditSanitizer auditSanitizer = new AuditSanitizer(new ObjectMapper());

    @Test
    void shouldMaskSensitiveFields() {
        String sanitized = auditSanitizer.sanitize(Map.of(
                "username", "student001",
                "password", "secret-password",
                "token", "jwt-token",
                "nested", Map.of("authorization", "Bearer abc")
        ));

        assertTrue(sanitized.contains("\"username\":\"student001\""));
        assertTrue(sanitized.contains("\"password\":\"***\""));
        assertTrue(sanitized.contains("\"token\":\"***\""));
        assertTrue(sanitized.contains("\"authorization\":\"***\""));
        assertFalse(sanitized.contains("secret-password"));
        assertFalse(sanitized.contains("jwt-token"));
        assertFalse(sanitized.contains("Bearer abc"));
    }
}
