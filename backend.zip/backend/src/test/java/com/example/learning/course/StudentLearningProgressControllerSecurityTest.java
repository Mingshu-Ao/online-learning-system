package com.example.learning.course;

import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.course.service.LearningProgressService;
import com.example.learning.course.vo.CourseLearningProgressVO;
import com.example.learning.course.vo.LearningStatsVO;
import com.example.learning.security.SecurityUser;
import com.example.learning.user.enums.UserStatus;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class StudentLearningProgressControllerSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LearningProgressService learningProgressService;

    @Test
    @WithMockUser(username = "teacher001", roles = {"TEACHER"})
    void shouldReturnForbiddenWhenTeacherReportsStudentProgress() throws Exception {
        mockMvc.perform(post("/api/student/video-progress")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "courseId": 1,
                                  "chapterId": 10,
                                  "resourceId": 100,
                                  "currentPosition": 10,
                                  "duration": 1200,
                                  "playbackRate": 1.0,
                                  "clientTimestamp": 1710000000000
                                }
                                """))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40300));
    }

    @Test
    void shouldAllowStudentToQueryCourseProgress() throws Exception {
        CourseLearningProgressVO progressVO = CourseLearningProgressVO.builder()
                .courseId(1L)
                .completionPercent(66.7D)
                .completed(false)
                .build();
        org.mockito.Mockito.when(learningProgressService.getCourseProgress(eq(1L), eq(1L))).thenReturn(progressVO);

        mockMvc.perform(get("/api/student/courses/1/progress")
                        .with(authentication(buildStudentAuthentication())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.courseId").value(1))
                .andExpect(jsonPath("$.data.completionPercent").value(66.7));
    }

    @Test
    void shouldAllowStudentToQueryLearningStats() throws Exception {
        LearningStatsVO statsVO = LearningStatsVO.builder()
                .startDate(LocalDate.of(2026, 5, 1))
                .endDate(LocalDate.of(2026, 5, 18))
                .todayStudySeconds(300L)
                .totalStudySeconds(1800L)
                .activeDays(6L)
                .consecutiveStudyDays(3L)
                .calendar(List.of())
                .build();
        org.mockito.Mockito.when(learningProgressService.getLearningStats(eq(1L), org.mockito.ArgumentMatchers.any()))
                .thenReturn(statsVO);

        mockMvc.perform(get("/api/student/learning-stats")
                        .param("startDate", "2026-05-01")
                        .param("endDate", "2026-05-18")
                        .with(authentication(buildStudentAuthentication())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.todayStudySeconds").value(300))
                .andExpect(jsonPath("$.data.consecutiveStudyDays").value(3));
    }

    private UsernamePasswordAuthenticationToken buildStudentAuthentication() {
        SecurityUser securityUser = SecurityUser.builder()
                .id(1L)
                .username("student001")
                .password("encoded")
                .nickname("Student")
                .status(UserStatus.ENABLED)
                .tokenVersion(0)
                .authorities(List.of(new SimpleGrantedAuthority("ROLE_STUDENT")))
                .build();
        return new UsernamePasswordAuthenticationToken(securityUser, null, securityUser.getAuthorities());
    }
}
