package com.example.learning.course;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.common.vo.PageResultVO;
import com.example.learning.course.service.CoursePublicService;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.course.vo.CourseListItemVO;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class CourseControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CoursePublicService coursePublicService;

    @Test
    void shouldListCoursesWithoutAuthentication() throws Exception {
        when(coursePublicService.listPublishedCourses(any())).thenReturn(PageResultVO.<CourseListItemVO>builder()
                .total(1)
                .records(List.of(CourseListItemVO.builder()
                        .id(1L)
                        .title("Java 程序设计")
                        .teacherName("张老师")
                        .difficulty("BEGINNER")
                        .studentCount(200L)
                        .build()))
                .build());

        mockMvc.perform(get("/api/courses").param("pageNum", "1").param("pageSize", "10").param("keyword", "java"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.total").value(1))
                .andExpect(jsonPath("$.data.records[0].title").value("Java 程序设计"));
    }

    @Test
    void shouldReturnCourseDetailWithApiResponseEnvelope() throws Exception {
        when(coursePublicService.getPublishedCourseDetail(1L)).thenReturn(CourseDetailVO.builder()
                .id(1L)
                .title("Java 程序设计")
                .summary("面向入门学习者")
                .teacherName("张老师")
                .status("PUBLISHED")
                .build());

        mockMvc.perform(get("/api/courses/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.id").value(1))
                .andExpect(jsonPath("$.data.status").value("PUBLISHED"));
    }
}
