package com.example.learning.quiz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.learning.quiz.entity.PaperQuestionEntity;
import com.example.learning.quiz.enums.QuestionType;
import com.example.learning.quiz.service.QuizScoringService;
import com.example.learning.quiz.service.impl.QuizScoringServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class QuizScoringServiceTest {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final QuizScoringService quizScoringService = new QuizScoringServiceImpl(objectMapper);

    @Test
    void shouldScoreSingleChoiceWhenAnswerMatches() throws Exception {
        PaperQuestionEntity question = buildQuestion(QuestionType.SINGLE_CHOICE, new BigDecimal("5.00"), "\"A\"");

        QuizScoringService.ScoringResult result = quizScoringService.score(question, objectMapper.readTree("\"A\""));

        assertTrue(result.correct());
        assertEquals(new BigDecimal("5.00"), result.awardedScore());
        assertTrue(result.autoGraded());
        assertFalse(result.needsManualReview());
    }

    @Test
    void shouldGivePartialScoreForMultipleChoiceWhenSubsetMatchesAndPartialCreditEnabled() throws Exception {
        PaperQuestionEntity question = buildQuestion(QuestionType.MULTIPLE_CHOICE, new BigDecimal("10.00"), "[\"A\",\"C\"]");
        question.setPartialCreditEnabled(Boolean.TRUE);

        QuizScoringService.ScoringResult result = quizScoringService.score(question, objectMapper.readTree("[\"A\"]"));

        assertFalse(result.correct());
        assertEquals(new BigDecimal("5.00"), result.awardedScore());
    }

    @Test
    void shouldScoreTrueFalseWhenTextValueMatchesIgnoringCase() throws Exception {
        PaperQuestionEntity question = buildQuestion(QuestionType.TRUE_FALSE, new BigDecimal("2.00"), "true");

        QuizScoringService.ScoringResult result = quizScoringService.score(question, objectMapper.readTree("\"TRUE\""));

        assertTrue(result.correct());
        assertEquals(new BigDecimal("2.00"), result.awardedScore());
    }

    private PaperQuestionEntity buildQuestion(QuestionType questionType, BigDecimal score, String standardAnswer) {
        PaperQuestionEntity question = new PaperQuestionEntity();
        question.setQuestionType(questionType);
        question.setScore(score);
        question.setStandardAnswer(standardAnswer);
        question.setPartialCreditEnabled(Boolean.FALSE);
        return question;
    }
}
