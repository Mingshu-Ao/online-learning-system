package com.example.learning.course;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.example.learning.audit.AuditLogService;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceAccessType;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.service.impl.ResourceAccessServiceImpl;
import com.example.learning.course.vo.ResourceAccessVO;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ResourceAccessServiceTest {

    @Mock
    private CourseResourceMapper courseResourceMapper;
    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseEnrollmentMapper courseEnrollmentMapper;
    @Mock
    private UserRoleMapper userRoleMapper;
    @Mock
    private RoleMapper roleMapper;
    @Mock
    private AuditLogService auditLogService;

    @InjectMocks
    private ResourceAccessServiceImpl resourceAccessService;

    @Test
    void shouldReturnAccessUrlWhenStudentIsEnrolledForRestrictedResource() {
        CourseResourceEntity resource = new CourseResourceEntity();
        resource.setId(10L);
        resource.setCourseId(1L);
        resource.setAccessType(ResourceAccessType.ENROLLED);
        resource.setResourceType(ResourceType.VIDEO);
        resource.setFileUrl("/local-storage/resources/demo.mp4");

        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(1001L);
        course.setStatus(CourseStatus.PUBLISHED);

        when(courseResourceMapper.findByIdAndDeletedFalse(10L)).thenReturn(Optional.of(resource));
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));
        when(userRoleMapper.findAllByUserIdAndDeletedFalse(3001L)).thenReturn(List.of());
        when(courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(1L, 3001L)).thenReturn(true);

        ResourceAccessVO result = resourceAccessService.getResourceAccessUrl(3001L, 10L);

        assertEquals(10L, result.getResourceId());
        assertEquals("/local-storage/resources/demo.mp4", result.getAccessUrl());
    }

    @Test
    void shouldRejectResourceAccessWhenStudentNotEnrolled() {
        CourseResourceEntity resource = new CourseResourceEntity();
        resource.setId(10L);
        resource.setCourseId(1L);
        resource.setAccessType(ResourceAccessType.ENROLLED);
        resource.setResourceType(ResourceType.VIDEO);
        resource.setFileUrl("/local-storage/resources/demo.mp4");

        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setTeacherId(1001L);
        course.setStatus(CourseStatus.PUBLISHED);

        when(courseResourceMapper.findByIdAndDeletedFalse(10L)).thenReturn(Optional.of(resource));
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));
        when(userRoleMapper.findAllByUserIdAndDeletedFalse(3001L)).thenReturn(List.of());
        when(courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(1L, 3001L)).thenReturn(false);

        BusinessException exception = assertThrows(BusinessException.class,
                () -> resourceAccessService.getResourceAccessUrl(3001L, 10L));

        assertEquals(ErrorCode.NO_COURSE_ACCESS_PERMISSION, exception.getErrorCode());
    }
}
