package com.example.learning.admin;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.admin.service.AuditLogAdminService;
import com.example.learning.admin.vo.LoginLogVO;
import com.example.learning.common.vo.PageResultVO;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AdminAuditLogControllerSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuditLogAdminService auditLogAdminService;

    @Test
    @WithMockUser(username = "admin", authorities = {"audit:read"})
    void shouldRejectAuditLogQueryWhenAdminRoleIsMissing() throws Exception {
        mockMvc.perform(get("/api/admin/logs/login"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40300));
    }

    @Test
    @WithMockUser(username = "admin", authorities = {"ROLE_ADMIN", "audit:read"})
    void shouldAllowAuditLogQueryWhenRoleAndPermissionExist() throws Exception {
        when(auditLogAdminService.listLoginLogs(any())).thenReturn(PageResultVO.<LoginLogVO>builder()
                .total(1)
                .records(List.of(LoginLogVO.builder()
                        .id(1L)
                        .username("student001")
                        .success(true)
                        .build()))
                .build());

        mockMvc.perform(get("/api/admin/logs/login"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.total").value(1));
    }
}
