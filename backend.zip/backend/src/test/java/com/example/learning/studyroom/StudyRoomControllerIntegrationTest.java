package com.example.learning.studyroom;

import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.security.SecurityUser;
import com.example.learning.studyroom.service.StudyRoomService;
import com.example.learning.studyroom.vo.StudyRoomJoinVO;
import com.example.learning.studyroom.vo.StudyRoomListItemVO;
import com.example.learning.studyroom.vo.StudyRoomSeatVO;
import com.example.learning.studyroom.vo.StudyRoomSnapshotVO;
import com.example.learning.user.enums.UserStatus;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class StudyRoomControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StudyRoomService studyRoomService;

    @Test
    void shouldRejectAnonymousUserWhenListingStudyRooms() throws Exception {
        mockMvc.perform(get("/api/study-rooms"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value(40100));
    }

    @Test
    void shouldJoinStudyRoomForStudentRole() throws Exception {
        when(studyRoomService.joinRoom(1L, 1L)).thenReturn(StudyRoomJoinVO.builder()
                .roomId(1L)
                .seatNo(8)
                .state("FOCUSING")
                .build());

        mockMvc.perform(post("/api/study-rooms/1/join")
                        .with(authentication(studentAuthentication())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.seatNo").value(8))
                .andExpect(jsonPath("$.data.state").value("FOCUSING"));
    }

    @Test
    void shouldReturnSnapshotForStudentRole() throws Exception {
        when(studyRoomService.getSnapshot(1L)).thenReturn(StudyRoomSnapshotVO.builder()
                .roomId(1L)
                .onlineCount(1L)
                .seats(List.of(StudyRoomSeatVO.builder()
                        .seatNo(1)
                        .userId(1001L)
                        .nickname("Alice")
                        .state("FOCUSING")
                        .build()))
                .build());
        when(studyRoomService.listRooms()).thenReturn(List.of(StudyRoomListItemVO.builder()
                .roomId(1L)
                .roomName("Room A")
                .capacity(50)
                .currentOnlineCount(1L)
                .openTime(LocalDateTime.of(2026, 5, 19, 8, 0))
                .closeTime(LocalDateTime.of(2026, 5, 19, 22, 0))
                .status("OPEN")
                .build()));

        mockMvc.perform(get("/api/study-rooms/1/snapshot")
                        .with(authentication(studentAuthentication())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.roomId").value(1))
                .andExpect(jsonPath("$.data.seats[0].nickname").value("Alice"));
    }

    private UsernamePasswordAuthenticationToken studentAuthentication() {
        SecurityUser securityUser = SecurityUser.builder()
                .id(1L)
                .username("student001")
                .password("bcrypt")
                .nickname("Alice")
                .status(UserStatus.ENABLED)
                .tokenVersion(0)
                .authorities(List.of(new SimpleGrantedAuthority("ROLE_STUDENT")))
                .build();
        return new UsernamePasswordAuthenticationToken(securityUser, null, securityUser.getAuthorities());
    }
}
