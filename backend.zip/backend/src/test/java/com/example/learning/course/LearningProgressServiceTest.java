package com.example.learning.course;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.dto.LearningStatsQueryDTO;
import com.example.learning.course.dto.VideoProgressReportDTO;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.entity.LearningDailyStatEntity;
import com.example.learning.course.entity.StudyRecordEntity;
import com.example.learning.course.entity.VideoProgressEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceAccessType;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.enums.TranscodingStatus;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.mapper.LearningDailyStatMapper;
import com.example.learning.course.mapper.StudyRecordMapper;
import com.example.learning.course.mapper.VideoProgressMapper;
import com.example.learning.course.service.impl.LearningProgressServiceImpl;
import com.example.learning.course.vo.CourseLearningProgressVO;
import com.example.learning.course.vo.LearningStatsVO;
import com.example.learning.course.vo.VideoProgressReportVO;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LearningProgressServiceTest {

    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseChapterMapper courseChapterMapper;
    @Mock
    private CourseResourceMapper courseResourceMapper;
    @Mock
    private CourseEnrollmentMapper courseEnrollmentMapper;
    @Mock
    private VideoProgressMapper videoProgressMapper;
    @Mock
    private StudyRecordMapper studyRecordMapper;
    @Mock
    private LearningDailyStatMapper learningDailyStatMapper;
    @Mock
    private Clock clock;

    @InjectMocks
    private LearningProgressServiceImpl learningProgressService;

    @BeforeEach
    void setUpClock() {
        lenient().when(clock.getZone()).thenReturn(ZoneOffset.UTC);
        lenient().when(clock.instant()).thenReturn(Instant.parse("2026-05-18T15:00:00Z"));
    }

    @Test
    void shouldReportVideoProgressNormallyWhenProgressIsReasonable() {
        mockPublishedEnrolledVideoContext();
        when(videoProgressMapper.findByUserIdAndResourceIdAndDeletedFalse(2001L, 100L)).thenReturn(Optional.empty());
        when(videoProgressMapper.save(any(VideoProgressEntity.class))).thenAnswer(invocation -> {
            VideoProgressEntity entity = invocation.getArgument(0);
            entity.setId(1L);
            return entity;
        });
        when(studyRecordMapper.save(any(StudyRecordEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(learningDailyStatMapper.findByUserIdAndStatDateAndDeletedFalse(2001L, LocalDate.of(2026, 5, 18)))
                .thenReturn(Optional.empty());
        when(learningDailyStatMapper.save(any(LearningDailyStatEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        VideoProgressReportVO result = learningProgressService.reportVideoProgress(2001L, buildReportDTO(10L, 1200L, 1D, 1710000000000L));

        assertEquals(100L, result.getResourceId());
        assertEquals(10L, result.getCurrentPosition());
        assertEquals(10L, result.getEffectiveStudySeconds());
        assertEquals(0.8D, result.getProgressPercent());
        assertFalse(result.getCompleted());

        ArgumentCaptor<LearningDailyStatEntity> statCaptor = ArgumentCaptor.forClass(LearningDailyStatEntity.class);
        verify(learningDailyStatMapper).save(statCaptor.capture());
        assertEquals(10L, statCaptor.getValue().getTotalStudySeconds());
    }

    @Test
    void shouldCapTrustedProgressWhenReportedJumpIsTooLarge() {
        mockPublishedEnrolledVideoContext();
        VideoProgressEntity existing = buildProgress(2001L, 1L, 10L, 100L, 100L, 100L, false,
                LocalDateTime.of(2026, 5, 18, 14, 59, 50));
        existing.setId(99L);
        when(videoProgressMapper.findByUserIdAndResourceIdAndDeletedFalse(2001L, 100L)).thenReturn(Optional.of(existing));
        when(videoProgressMapper.save(any(VideoProgressEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(studyRecordMapper.save(any(StudyRecordEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(learningDailyStatMapper.findByUserIdAndStatDateAndDeletedFalse(2001L, LocalDate.of(2026, 5, 18)))
                .thenReturn(Optional.empty());
        when(learningDailyStatMapper.save(any(LearningDailyStatEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        VideoProgressReportVO result = learningProgressService.reportVideoProgress(2001L, buildReportDTO(200L, 1200L, 1D, 1710000010000L));

        assertEquals(110L, result.getCurrentPosition());
        assertEquals(110L, result.getEffectiveStudySeconds());

        ArgumentCaptor<StudyRecordEntity> recordCaptor = ArgumentCaptor.forClass(StudyRecordEntity.class);
        verify(studyRecordMapper).save(recordCaptor.capture());
        assertTrue(recordCaptor.getValue().getSuspicious());
        assertEquals(10L, recordCaptor.getValue().getTrustedIncrementSeconds());
    }

    @Test
    void shouldAllowTrustedGrowthWithinPlaybackRateWindow() {
        mockPublishedEnrolledVideoContext();
        VideoProgressEntity existing = buildProgress(2001L, 1L, 10L, 100L, 100L, 100L, false,
                LocalDateTime.of(2026, 5, 18, 14, 59, 50));
        existing.setId(99L);
        when(videoProgressMapper.findByUserIdAndResourceIdAndDeletedFalse(2001L, 100L)).thenReturn(Optional.of(existing));
        when(videoProgressMapper.save(any(VideoProgressEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(studyRecordMapper.save(any(StudyRecordEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(learningDailyStatMapper.findByUserIdAndStatDateAndDeletedFalse(2001L, LocalDate.of(2026, 5, 18)))
                .thenReturn(Optional.empty());
        when(learningDailyStatMapper.save(any(LearningDailyStatEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        VideoProgressReportVO result = learningProgressService.reportVideoProgress(2001L, buildReportDTO(120L, 1200L, 2D, 1710000010000L));

        assertEquals(120L, result.getCurrentPosition());
        assertEquals(120L, result.getEffectiveStudySeconds());
        assertEquals(10.0D, result.getProgressPercent());
    }

    @Test
    void shouldNotIncreaseEffectiveStudySecondsWhenVideoIsAlreadyCompleted() {
        mockPublishedEnrolledVideoContext();
        VideoProgressEntity existing = buildProgress(2001L, 1L, 10L, 100L, 1080L, 1080L, true,
                LocalDateTime.of(2026, 5, 18, 14, 59, 50));
        existing.setId(99L);
        when(videoProgressMapper.findByUserIdAndResourceIdAndDeletedFalse(2001L, 100L)).thenReturn(Optional.of(existing));
        when(videoProgressMapper.save(any(VideoProgressEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(studyRecordMapper.save(any(StudyRecordEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        VideoProgressReportVO result = learningProgressService.reportVideoProgress(2001L, buildReportDTO(1200L, 1200L, 1D, 1710000010000L));

        assertEquals(1200L, result.getCurrentPosition());
        assertEquals(1080L, result.getEffectiveStudySeconds());
        assertTrue(result.getCompleted());
        verify(learningDailyStatMapper, never()).save(any(LearningDailyStatEntity.class));
    }

    @Test
    void shouldKeepMaximumTrustedPositionWhenReportedPositionMovesBackward() {
        mockPublishedEnrolledVideoContext();
        VideoProgressEntity existing = buildProgress(2001L, 1L, 10L, 100L, 300L, 300L, false,
                LocalDateTime.of(2026, 5, 18, 14, 59, 20));
        existing.setId(99L);
        when(videoProgressMapper.findByUserIdAndResourceIdAndDeletedFalse(2001L, 100L)).thenReturn(Optional.of(existing));
        when(videoProgressMapper.save(any(VideoProgressEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(studyRecordMapper.save(any(StudyRecordEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        VideoProgressReportVO result = learningProgressService.reportVideoProgress(2001L, buildReportDTO(250L, 1200L, 1D, 1710000020000L));

        assertEquals(300L, result.getCurrentPosition());
        assertEquals(300L, result.getEffectiveStudySeconds());
    }

    @Test
    void shouldRejectProgressWhenCurrentPositionExceedsDuration() {
        mockPublishedEnrolledVideoContext();

        BusinessException exception = assertThrows(BusinessException.class,
                () -> learningProgressService.reportVideoProgress(2001L, buildReportDTO(1300L, 1200L, 1D, 1710000010000L)));

        assertEquals(ErrorCode.VIDEO_PROGRESS_INVALID, exception.getErrorCode());
    }

    @Test
    void shouldCalculateCourseCompletionAndResumeInfo() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setStatus(CourseStatus.PUBLISHED);
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));
        when(courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(1L, 2001L)).thenReturn(true);

        CourseResourceEntity video1 = buildVideoResource(100L, 1L, 10L, 100L);
        video1.setTitle("Intro");
        CourseResourceEntity video2 = buildVideoResource(101L, 1L, 11L, 200L);
        video2.setTitle("Advanced");
        when(courseResourceMapper.findAllByCourseIdAndResourceTypeAndDeletedFalse(1L, ResourceType.VIDEO))
                .thenReturn(List.of(video1, video2));

        VideoProgressEntity progress1 = buildProgress(2001L, 1L, 10L, 100L, 100L, 90L, true,
                LocalDateTime.of(2026, 5, 18, 14, 0, 0));
        VideoProgressEntity progress2 = buildProgress(2001L, 1L, 11L, 101L, 100L, 90L, false,
                LocalDateTime.of(2026, 5, 18, 15, 0, 0));
        when(videoProgressMapper.findAllByUserIdAndResourceIdInAndDeletedFalse(2001L, List.of(100L, 101L)))
                .thenReturn(List.of(progress1, progress2));

        CourseLearningProgressVO result = learningProgressService.getCourseProgress(2001L, 1L);

        assertEquals(2L, result.getTotalVideoCount());
        assertEquals(1L, result.getCompletedVideoCount());
        assertEquals(300L, result.getTotalDurationSeconds());
        assertEquals(180L, result.getTotalEffectiveStudySeconds());
        assertEquals(66.7D, result.getCompletionPercent());
        assertEquals(101L, result.getResumeResourceId());
        assertEquals(11L, result.getResumeChapterId());
        assertEquals(100L, result.getResumePosition());
        assertEquals(2, result.getVideos().size());
    }

    @Test
    void shouldReturnLearningStatsWithCalendarAndConsecutiveDays() {
        LearningStatsQueryDTO queryDTO = new LearningStatsQueryDTO();
        queryDTO.setStartDate(LocalDate.of(2026, 5, 15));
        queryDTO.setEndDate(LocalDate.of(2026, 5, 18));

        when(learningDailyStatMapper.findAllByUserIdAndStatDateBetweenAndDeletedFalseOrderByStatDateAsc(
                2001L,
                LocalDate.of(2026, 5, 15),
                LocalDate.of(2026, 5, 18)
        )).thenReturn(List.of(
                buildDailyStat(2001L, LocalDate.of(2026, 5, 15), 120L),
                buildDailyStat(2001L, LocalDate.of(2026, 5, 17), 240L),
                buildDailyStat(2001L, LocalDate.of(2026, 5, 18), 300L)
        ));
        when(learningDailyStatMapper.findByUserIdAndStatDateAndDeletedFalse(2001L, LocalDate.of(2026, 5, 18)))
                .thenReturn(Optional.of(buildDailyStat(2001L, LocalDate.of(2026, 5, 18), 300L)));

        LearningStatsVO result = learningProgressService.getLearningStats(2001L, queryDTO);

        assertEquals(LocalDate.of(2026, 5, 15), result.getStartDate());
        assertEquals(LocalDate.of(2026, 5, 18), result.getEndDate());
        assertEquals(300L, result.getTodayStudySeconds());
        assertEquals(660L, result.getTotalStudySeconds());
        assertEquals(3L, result.getActiveDays());
        assertEquals(2L, result.getConsecutiveStudyDays());
        assertEquals(4, result.getCalendar().size());
        assertEquals(0L, result.getCalendar().get(1).getStudySeconds());
        assertFalse(result.getCalendar().get(1).getActive());
        assertTrue(result.getCalendar().get(3).getActive());
    }

    @Test
    void shouldRejectLearningStatsWhenDateRangeIsInvalid() {
        LearningStatsQueryDTO queryDTO = new LearningStatsQueryDTO();
        queryDTO.setStartDate(LocalDate.of(2026, 5, 19));
        queryDTO.setEndDate(LocalDate.of(2026, 5, 18));

        BusinessException exception = assertThrows(BusinessException.class,
                () -> learningProgressService.getLearningStats(2001L, queryDTO));

        assertEquals(ErrorCode.BAD_REQUEST, exception.getErrorCode());
    }

    private void mockPublishedEnrolledVideoContext() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setStatus(CourseStatus.PUBLISHED);
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(course));
        when(courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(1L, 2001L)).thenReturn(true);

        CourseChapterEntity chapter = new CourseChapterEntity();
        chapter.setId(10L);
        chapter.setCourseId(1L);
        when(courseChapterMapper.findByIdAndDeletedFalse(10L)).thenReturn(Optional.of(chapter));

        when(courseResourceMapper.findByIdAndDeletedFalse(100L)).thenReturn(Optional.of(buildVideoResource(100L, 1L, 10L, 1200L)));
    }

    private VideoProgressReportDTO buildReportDTO(Long currentPosition, Long duration, Double playbackRate, Long clientTimestamp) {
        VideoProgressReportDTO dto = new VideoProgressReportDTO();
        dto.setCourseId(1L);
        dto.setChapterId(10L);
        dto.setResourceId(100L);
        dto.setCurrentPosition(currentPosition);
        dto.setDuration(duration);
        dto.setPlaybackRate(playbackRate);
        dto.setClientTimestamp(clientTimestamp);
        return dto;
    }

    private CourseResourceEntity buildVideoResource(Long resourceId, Long courseId, Long chapterId, Long durationSeconds) {
        CourseResourceEntity resource = new CourseResourceEntity();
        resource.setId(resourceId);
        resource.setCourseId(courseId);
        resource.setChapterId(chapterId);
        resource.setTitle("Video");
        resource.setResourceType(ResourceType.VIDEO);
        resource.setAccessType(ResourceAccessType.ENROLLED);
        resource.setOriginalFileName("lesson.mp4");
        resource.setStoragePath("/local/lesson.mp4");
        resource.setFileUrl("/local/lesson.mp4");
        resource.setFileSize(1024L);
        resource.setDurationSeconds(durationSeconds);
        resource.setTranscodingStatus(TranscodingStatus.PENDING);
        return resource;
    }

    private VideoProgressEntity buildProgress(Long userId,
                                              Long courseId,
                                              Long chapterId,
                                              Long resourceId,
                                              Long currentPosition,
                                              Long effectiveStudySeconds,
                                              boolean completed,
                                              LocalDateTime lastReportAt) {
        VideoProgressEntity progress = new VideoProgressEntity();
        progress.setUserId(userId);
        progress.setCourseId(courseId);
        progress.setChapterId(chapterId);
        progress.setResourceId(resourceId);
        progress.setCurrentPosition(currentPosition);
        progress.setDurationSeconds(1200L);
        progress.setEffectiveStudySeconds(effectiveStudySeconds);
        progress.setProgressPercent(Math.round(currentPosition * 1000D / 1200D) / 10D);
        progress.setCompleted(completed);
        progress.setLastPlaybackRate(1D);
        progress.setLastClientTimestamp(1710000000000L);
        progress.setLastReportAt(lastReportAt);
        progress.setLastStudyAt(lastReportAt);
        return progress;
    }

    private LearningDailyStatEntity buildDailyStat(Long userId, LocalDate statDate, Long totalStudySeconds) {
        LearningDailyStatEntity stat = new LearningDailyStatEntity();
        stat.setUserId(userId);
        stat.setStatDate(statDate);
        stat.setTotalStudySeconds(totalStudySeconds);
        stat.setLastStudyAt(statDate.atTime(20, 0));
        return stat;
    }
}
