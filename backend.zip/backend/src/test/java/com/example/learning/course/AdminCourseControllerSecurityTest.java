package com.example.learning.course;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.learning.course.service.AdminCourseService;
import com.example.learning.course.vo.CourseDetailVO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AdminCourseControllerSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminCourseService adminCourseService;

    @Test
    @WithMockUser(username = "teacher001", authorities = {"course:update"})
    void shouldReturnForbiddenWhenReviewPermissionIsMissing() throws Exception {
        mockMvc.perform(post("/api/admin/courses/1/review")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"action\":\"APPROVE\"}"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40300));
    }

    @Test
    @WithMockUser(username = "admin", authorities = {"ROLE_ADMIN", "course:review"})
    void shouldAllowReviewWhenPermissionExists() throws Exception {
        when(adminCourseService.reviewCourse(any(), any())).thenReturn(CourseDetailVO.builder()
                .id(1L)
                .title("Java Programming")
                .status("PUBLISHED")
                .build());

        mockMvc.perform(post("/api/admin/courses/1/review")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"action\":\"APPROVE\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.status").value("PUBLISHED"));
    }
}
