package com.example.learning.ai;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import com.example.learning.ai.client.AiClientInvalidResponseException;
import com.example.learning.ai.client.FastApiAiMicroserviceClient;
import com.example.learning.ai.config.AiClientConfig;
import com.example.learning.ai.config.AiServiceProperties;
import com.example.learning.ai.model.AiAnswerPayload;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

class AiMicroserviceClientTest {

    private FastApiAiMicroserviceClient client;
    private MockRestServiceServer server;

    @BeforeEach
    void setUp() {
        AiServiceProperties properties = new AiServiceProperties();
        properties.setBaseUrl("http://ai-service.local");
        RestTemplate restTemplate = new AiClientConfig().aiRestTemplate(properties);
        client = new FastApiAiMicroserviceClient(restTemplate, properties);
        server = MockRestServiceServer.createServer(restTemplate);
    }

    @AfterEach
    void tearDown() {
        server.verify();
    }

    @Test
    void shouldReturnStructuredResponseWhenAiServiceSucceeds() {
        server.expect(requestTo("http://ai-service.local/ai/ask"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess("""
                        {
                          \"question_text\": \"递归和迭代有什么区别？\",
                          \"knowledge_points\": [\"递归\", \"迭代\"],
                          \"difficulty\": \"MEDIUM\",
                          \"solution_steps\": [\"先看定义\", \"再看调用方式\"],
                          \"mistake_analysis\": \"容易混淆调用栈开销。\",
                          \"recommendations\": [
                            {
                              \"type\": \"VIDEO\",
                              \"resource_id\": 1001,
                              \"reason\": \"该视频讲解递归基础\"
                            }
                          ]
                        }
                        """, MediaType.APPLICATION_JSON));

        AiAnswerPayload payload = client.ask(1001L, 1L, "递归和迭代有什么区别？");

        assertEquals("递归和迭代有什么区别？", payload.getQuestionText());
        assertEquals(2, payload.getKnowledgePoints().size());
        assertEquals(1, payload.getRecommendations().size());
        assertEquals(1001L, payload.getRecommendations().get(0).getResourceId());
    }

    @Test
    void shouldRejectInvalidResponseWhenAiServiceReturnsEmptyPayload() {
        server.expect(requestTo("http://ai-service.local/ai/ask"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess("{}", MediaType.APPLICATION_JSON));

        assertThrows(AiClientInvalidResponseException.class,
                () -> client.ask(1001L, 1L, "递归和迭代有什么区别？"));
    }
}
