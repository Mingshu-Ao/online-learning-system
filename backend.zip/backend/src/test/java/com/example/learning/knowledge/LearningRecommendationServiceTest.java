package com.example.learning.knowledge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.when;

import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.knowledge.entity.KnowledgePointEntity;
import com.example.learning.knowledge.entity.KnowledgeRelationEntity;
import com.example.learning.knowledge.entity.KnowledgeResourceEntity;
import com.example.learning.knowledge.entity.LearningRecommendationEntity;
import com.example.learning.knowledge.enums.KnowledgeResourceType;
import com.example.learning.knowledge.mapper.KnowledgePointMapper;
import com.example.learning.knowledge.mapper.KnowledgeRelationMapper;
import com.example.learning.knowledge.mapper.KnowledgeResourceMapper;
import com.example.learning.knowledge.mapper.LearningRecommendationMapper;
import com.example.learning.knowledge.service.impl.LearningRecommendationServiceImpl;
import com.example.learning.knowledge.vo.LearningRecommendationVO;
import com.example.learning.quiz.entity.QuestionEntity;
import com.example.learning.quiz.entity.WrongQuestionEntity;
import com.example.learning.quiz.enums.WrongQuestionStatus;
import com.example.learning.quiz.mapper.QuestionMapper;
import com.example.learning.quiz.mapper.WrongQuestionMapper;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;

@ExtendWith(MockitoExtension.class)
class LearningRecommendationServiceTest {

    @Mock
    private CourseMapper courseMapper;
    @Mock
    private CourseEnrollmentMapper courseEnrollmentMapper;
    @Mock
    private KnowledgePointMapper knowledgePointMapper;
    @Mock
    private KnowledgeRelationMapper knowledgeRelationMapper;
    @Mock
    private KnowledgeResourceMapper knowledgeResourceMapper;
    @Mock
    private LearningRecommendationMapper learningRecommendationMapper;
    @Mock
    private WrongQuestionMapper wrongQuestionMapper;
    @Mock
    private CourseChapterMapper courseChapterMapper;
    @Mock
    private CourseResourceMapper courseResourceMapper;
    @Mock
    private QuestionMapper questionMapper;

    private LearningRecommendationServiceImpl learningRecommendationService;

    @BeforeEach
    void setUp() {
        Clock fixedClock = Clock.fixed(Instant.parse("2026-05-19T07:00:00Z"), ZoneOffset.UTC);
        learningRecommendationService = new LearningRecommendationServiceImpl(
                courseMapper,
                courseEnrollmentMapper,
                knowledgePointMapper,
                knowledgeRelationMapper,
                knowledgeResourceMapper,
                learningRecommendationMapper,
                wrongQuestionMapper,
                courseChapterMapper,
                courseResourceMapper,
                questionMapper,
                fixedClock
        );
        when(courseMapper.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(publishedCourse()));
        when(courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(1L, 1001L)).thenReturn(true);
        when(learningRecommendationMapper.saveAll(any())).thenAnswer(invocation -> {
            List<LearningRecommendationEntity> entities = invocation.getArgument(0);
            long id = 1L;
            for (LearningRecommendationEntity entity : entities) {
                entity.setId(id++);
            }
            return entities;
        });
    }

    @Test
    void shouldGeneratePathFromWrongQuestionsAndPrerequisites() {
        KnowledgePointEntity basics = knowledgePoint(1L, "递归基础");
        KnowledgePointEntity divide = knowledgePoint(2L, "分治递归");
        WrongQuestionEntity wrongQuestion = wrongQuestion(2001L, "分治递归", 3);
        KnowledgeRelationEntity relation = relation(2L, 1L);
        CourseChapterEntity chapter = chapter(11L, "递归章节");
        CourseResourceEntity video = video(21L, "分治递归视频");
        KnowledgeResourceEntity basicsBinding = binding(1L, KnowledgeResourceType.CHAPTER, 11L);
        KnowledgeResourceEntity divideBinding = binding(2L, KnowledgeResourceType.VIDEO, 21L);

        when(knowledgePointMapper.findAllByCourseIdAndDeletedFalseOrderByNameAsc(1L)).thenReturn(List.of(basics, divide));
        when(wrongQuestionMapper.findAllByUserIdAndDeletedFalseOrderByLastWrongAtDesc(1001L)).thenReturn(List.of(wrongQuestion));
        when(knowledgeRelationMapper.findAllByCourseIdAndDeletedFalse(1L)).thenReturn(List.of(relation));
        when(knowledgeResourceMapper.findAllByKnowledgePointIdInAndDeletedFalse(any())).thenReturn(List.of(basicsBinding, divideBinding));
        when(courseChapterMapper.findAllByIdInAndDeletedFalse(any())).thenReturn(List.of(chapter));
        when(courseResourceMapper.findAllById(any())).thenReturn(List.of(video));

        LearningRecommendationVO response = learningRecommendationService.generateRecommendations(1001L, 1L);

        assertFalse(response.getDefaultRecommendation());
        assertEquals(1, response.getWeakKnowledgePoints().size());
        assertEquals("分治递归", response.getWeakKnowledgePoints().get(0).getKnowledgePointName());
        assertEquals(2, response.getRecommendations().size());
        assertEquals("CHAPTER", response.getRecommendations().get(0).getResourceType());
        assertEquals("VIDEO", response.getRecommendations().get(1).getResourceType());
    }

    @Test
    void shouldReturnDefaultRecommendationWhenLearningDataIsInsufficient() {
        CourseChapterEntity chapter = chapter(11L, "课程导学");
        CourseResourceEntity video = video(21L, "导学视频");
        CourseResourceEntity document = document(22L, "课程讲义");
        QuestionEntity question = question(31L, "什么是递归？");

        when(knowledgePointMapper.findAllByCourseIdAndDeletedFalseOrderByNameAsc(1L)).thenReturn(List.of());
        when(wrongQuestionMapper.findAllByUserIdAndDeletedFalseOrderByLastWrongAtDesc(1001L)).thenReturn(List.of());
        when(courseChapterMapper.findAllByCourseIdAndDeletedFalseOrderBySortOrderAscIdAsc(1L)).thenReturn(List.of(chapter));
        when(courseResourceMapper.findAllByCourseIdAndDeletedFalse(1L)).thenReturn(List.of(video, document));
        when(questionMapper.findAll(org.mockito.ArgumentMatchers.<Specification<QuestionEntity>>any())).thenReturn(List.of(question));

        LearningRecommendationVO response = learningRecommendationService.generateRecommendations(1001L, 1L);

        assertTrue(response.getDefaultRecommendation());
        assertTrue(response.getWeakKnowledgePoints().isEmpty());
        assertEquals(4, response.getRecommendations().size());
    }

    private CourseEntity publishedCourse() {
        CourseEntity course = new CourseEntity();
        course.setId(1L);
        course.setStatus(CourseStatus.PUBLISHED);
        return course;
    }

    private KnowledgePointEntity knowledgePoint(Long id, String name) {
        KnowledgePointEntity entity = new KnowledgePointEntity();
        entity.setId(id);
        entity.setCourseId(1L);
        entity.setTeacherId(2001L);
        entity.setName(name);
        return entity;
    }

    private WrongQuestionEntity wrongQuestion(Long questionId, String knowledgePoint, int wrongCount) {
        WrongQuestionEntity entity = new WrongQuestionEntity();
        entity.setQuestionId(questionId);
        entity.setCourseId(1L);
        entity.setKnowledgePoint(knowledgePoint);
        entity.setWrongCount(wrongCount);
        entity.setStatus(WrongQuestionStatus.UNMASTERED);
        return entity;
    }

    private KnowledgeRelationEntity relation(Long pointId, Long prerequisiteId) {
        KnowledgeRelationEntity entity = new KnowledgeRelationEntity();
        entity.setCourseId(1L);
        entity.setKnowledgePointId(pointId);
        entity.setPrerequisiteId(prerequisiteId);
        return entity;
    }

    private CourseChapterEntity chapter(Long id, String title) {
        CourseChapterEntity entity = new CourseChapterEntity();
        entity.setId(id);
        entity.setCourseId(1L);
        entity.setTitle(title);
        entity.setSortOrder(1);
        return entity;
    }

    private CourseResourceEntity video(Long id, String title) {
        CourseResourceEntity entity = new CourseResourceEntity();
        entity.setId(id);
        entity.setCourseId(1L);
        entity.setChapterId(11L);
        entity.setTitle(title);
        entity.setResourceType(ResourceType.VIDEO);
        entity.setDeleted(false);
        return entity;
    }

    private CourseResourceEntity document(Long id, String title) {
        CourseResourceEntity entity = new CourseResourceEntity();
        entity.setId(id);
        entity.setCourseId(1L);
        entity.setChapterId(11L);
        entity.setTitle(title);
        entity.setResourceType(ResourceType.PDF);
        entity.setDeleted(false);
        return entity;
    }

    private KnowledgeResourceEntity binding(Long knowledgePointId, KnowledgeResourceType resourceType, Long resourceId) {
        KnowledgeResourceEntity entity = new KnowledgeResourceEntity();
        entity.setKnowledgePointId(knowledgePointId);
        entity.setResourceType(resourceType);
        entity.setResourceId(resourceId);
        entity.setCourseId(1L);
        return entity;
    }

    private QuestionEntity question(Long id, String stem) {
        QuestionEntity entity = new QuestionEntity();
        entity.setId(id);
        entity.setCourseId(1L);
        entity.setTeacherId(2001L);
        entity.setStem(stem);
        return entity;
    }
}
