package com.example.learning.user;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.security.JwtTokenProvider;
import com.example.learning.security.SecurityUser;
import com.example.learning.security.SecurityUserDetailsService;
import com.example.learning.user.dto.AuthLoginDTO;
import com.example.learning.user.dto.AuthRegisterDTO;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.enums.RoleCode;
import com.example.learning.user.enums.UserStatus;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import com.example.learning.user.service.impl.AuthServiceImpl;
import com.example.learning.user.vo.LoginVO;
import com.example.learning.user.vo.UserProfileVO;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserMapper userMapper;
    @Mock
    private RoleMapper roleMapper;
    @Mock
    private UserRoleMapper userRoleMapper;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private JwtTokenProvider jwtTokenProvider;
    @Mock
    private SecurityUserDetailsService securityUserDetailsService;

    @InjectMocks
    private AuthServiceImpl authService;

    @Test
    void shouldEncodePasswordWhenRegisteringUser() {
        AuthRegisterDTO dto = new AuthRegisterDTO();
        dto.setUsername("student001");
        dto.setPassword("12345678");
        dto.setNickname("Student One");
        dto.setEmail("student001@example.com");
        dto.setPhone("13800138000");

        RoleEntity studentRole = new RoleEntity();
        studentRole.setId(2L);
        studentRole.setCode(RoleCode.STUDENT.name());

        when(roleMapper.findByCodeAndDeletedFalse(RoleCode.STUDENT.name())).thenReturn(Optional.of(studentRole));
        when(passwordEncoder.encode("12345678")).thenReturn("bcrypt-hash");
        when(userMapper.save(any(UserEntity.class))).thenAnswer(invocation -> {
            UserEntity entity = invocation.getArgument(0);
            entity.setId(1L);
            return entity;
        });

        UserProfileVO result = authService.register(dto);

        ArgumentCaptor<UserEntity> userCaptor = ArgumentCaptor.forClass(UserEntity.class);
        verify(userMapper).save(userCaptor.capture());
        assertEquals("bcrypt-hash", userCaptor.getValue().getPasswordHash());
        assertTrue(!"12345678".equals(userCaptor.getValue().getPasswordHash()));
        assertEquals(List.of(RoleCode.STUDENT.name()), result.getRoles());
    }

    @Test
    void shouldLoginSuccessfullyWhenPasswordIsCorrect() {
        AuthLoginDTO dto = new AuthLoginDTO();
        dto.setUsername("student001");
        dto.setPassword("123456");

        UserEntity user = new UserEntity();
        user.setId(1L);
        user.setUsername("student001");
        user.setPasswordHash("bcrypt-hash");
        user.setStatus(UserStatus.ENABLED);
        user.setTokenVersion(0);

        SecurityUser securityUser = SecurityUser.builder()
                .id(1L)
                .username("student001")
                .password("bcrypt-hash")
                .status(UserStatus.ENABLED)
                .tokenVersion(0)
                .authorities(List.of(new SimpleGrantedAuthority("ROLE_STUDENT")))
                .build();

        when(userMapper.findByUsernameAndDeletedFalse("student001")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("123456", "bcrypt-hash")).thenReturn(true);
        when(securityUserDetailsService.loadUserById(1L)).thenReturn(securityUser);
        when(jwtTokenProvider.generateToken(securityUser)).thenReturn("jwt-token");

        LoginVO result = authService.login(dto);

        assertEquals("jwt-token", result.getToken());
        assertEquals(1L, result.getUserId());
        assertEquals(List.of("STUDENT"), result.getRoles());
    }

    @Test
    void shouldRejectLoginWhenPasswordIsIncorrect() {
        AuthLoginDTO dto = new AuthLoginDTO();
        dto.setUsername("student001");
        dto.setPassword("wrong-password");

        UserEntity user = new UserEntity();
        user.setId(1L);
        user.setUsername("student001");
        user.setPasswordHash("bcrypt-hash");
        user.setStatus(UserStatus.ENABLED);

        when(userMapper.findByUsernameAndDeletedFalse("student001")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrong-password", "bcrypt-hash")).thenReturn(false);

        BusinessException exception = assertThrows(BusinessException.class, () -> authService.login(dto));

        assertEquals(ErrorCode.PASSWORD_ERROR, exception.getErrorCode());
    }

    @Test
    void shouldRejectLoginWhenUserDisabled() {
        AuthLoginDTO dto = new AuthLoginDTO();
        dto.setUsername("student001");
        dto.setPassword("123456");

        UserEntity user = new UserEntity();
        user.setId(1L);
        user.setUsername("student001");
        user.setPasswordHash("bcrypt-hash");
        user.setStatus(UserStatus.DISABLED);

        when(userMapper.findByUsernameAndDeletedFalse("student001")).thenReturn(Optional.of(user));

        BusinessException exception = assertThrows(BusinessException.class, () -> authService.login(dto));
        assertEquals(ErrorCode.USER_DISABLED, exception.getErrorCode());
    }
}
