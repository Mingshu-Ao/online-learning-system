package com.example.learning.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import com.example.learning.audit.AuditLogService;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.common.exception.GlobalExceptionHandler;
import com.example.learning.common.response.ApiResponse;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler(mock(AuditLogService.class));

    @ParameterizedTest
    @MethodSource("businessExceptionCases")
    void shouldMapBusinessExceptionToExpectedHttpStatus(ErrorCode errorCode, HttpStatus expectedStatus) {
        ResponseEntity<ApiResponse<Void>> response = handler.handleBusinessException(new BusinessException(errorCode));

        assertEquals(expectedStatus, response.getStatusCode());
        assertEquals(errorCode.getCode(), response.getBody().getCode());
    }

    @Test
    void shouldReturnForbiddenForAccessDeniedException() {
        ResponseEntity<ApiResponse<Void>> response =
                handler.handleAccessDeniedException(new AccessDeniedException("forbidden"));

        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertEquals(ErrorCode.FORBIDDEN.getCode(), response.getBody().getCode());
    }

    @Test
    void shouldReturnUnauthorizedForAuthenticationException() {
        ResponseEntity<ApiResponse<Void>> response =
                handler.handleAuthenticationException(new BadCredentialsException("bad credentials"));

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals(ErrorCode.UNAUTHORIZED.getCode(), response.getBody().getCode());
    }

    @Test
    void shouldReturnInternalServerErrorForUnexpectedException() {
        ResponseEntity<ApiResponse<Void>> response = handler.handleException(new RuntimeException("boom"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(ErrorCode.INTERNAL_SERVER_ERROR.getCode(), response.getBody().getCode());
    }

    private static Stream<Arguments> businessExceptionCases() {
        return Stream.of(
                Arguments.of(ErrorCode.BAD_REQUEST, HttpStatus.BAD_REQUEST),
                Arguments.of(ErrorCode.USERNAME_ALREADY_EXISTS, HttpStatus.BAD_REQUEST),
                Arguments.of(ErrorCode.UNAUTHORIZED, HttpStatus.UNAUTHORIZED),
                Arguments.of(ErrorCode.TOKEN_INVALID, HttpStatus.UNAUTHORIZED),
                Arguments.of(ErrorCode.FORBIDDEN, HttpStatus.FORBIDDEN),
                Arguments.of(ErrorCode.USER_DISABLED, HttpStatus.FORBIDDEN),
                Arguments.of(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND),
                Arguments.of(ErrorCode.USER_NOT_FOUND, HttpStatus.NOT_FOUND),
                Arguments.of(ErrorCode.CONFLICT, HttpStatus.CONFLICT),
                Arguments.of(ErrorCode.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR)
        );
    }
}
