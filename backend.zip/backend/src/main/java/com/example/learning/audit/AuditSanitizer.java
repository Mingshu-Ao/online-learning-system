package com.example.learning.audit;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;

@Component
@RequiredArgsConstructor
public class AuditSanitizer {

    private static final int MAX_LENGTH = 2000;

    private final ObjectMapper objectMapper;

    public String sanitize(Object value) {
        if (value == null) {
            return null;
        }
        Object normalized = normalize(value);
        JsonNode node = objectMapper.valueToTree(normalized);
        sanitizeNode(node);
        String result = node.toString();
        return result.length() <= MAX_LENGTH ? result : result.substring(0, MAX_LENGTH);
    }

    private Object normalize(Object value) {
        if (value == null
                || value instanceof Number
                || value instanceof Boolean
                || value instanceof Enum<?>
                || value instanceof CharSequence) {
            return value;
        }
        if (value instanceof MultipartFile file) {
            return Map.of("fileName", file.getOriginalFilename(), "size", file.getSize(), "contentType", file.getContentType());
        }
        if (value instanceof BindingResult || value instanceof Authentication) {
            return "[IGNORED]";
        }
        if (value instanceof jakarta.servlet.ServletRequest || value instanceof jakarta.servlet.ServletResponse) {
            return "[IGNORED]";
        }
        if (value instanceof Collection<?> collection) {
            return collection.stream().map(this::normalize).toList();
        }
        if (value.getClass().isArray()) {
            int length = Array.getLength(value);
            Object[] array = new Object[length];
            for (int i = 0; i < length; i++) {
                array[i] = normalize(Array.get(value, i));
            }
            return array;
        }
        if (value instanceof Map<?, ?> sourceMap) {
            Map<String, Object> target = new LinkedHashMap<>();
            sourceMap.forEach((key, mapValue) -> target.put(String.valueOf(key), normalize(mapValue)));
            return target;
        }
        return value;
    }

    private void sanitizeNode(JsonNode node) {
        if (node instanceof ObjectNode objectNode) {
            objectNode.fields().forEachRemaining(entry -> {
                if (isSensitiveKey(entry.getKey())) {
                    objectNode.put(entry.getKey(), "***");
                    return;
                }
                sanitizeNode(entry.getValue());
            });
            return;
        }
        if (node instanceof ArrayNode arrayNode) {
            arrayNode.forEach(this::sanitizeNode);
        }
    }

    private boolean isSensitiveKey(String key) {
        String normalized = key.toLowerCase(Locale.ROOT);
        return normalized.contains("password")
                || normalized.contains("token")
                || normalized.contains("authorization")
                || normalized.contains("secret")
                || normalized.contains("credential");
    }
}
