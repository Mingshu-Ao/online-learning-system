package com.example.learning.admin.service.impl;

import com.example.learning.admin.dto.AdminStatisticsQueryDTO;
import com.example.learning.admin.entity.LoginLogEntity;
import com.example.learning.admin.service.AdminDashboardService;
import com.example.learning.admin.vo.AdminDailyStatisticsItemVO;
import com.example.learning.admin.vo.AdminDashboardVO;
import com.example.learning.admin.vo.AdminStatisticsVO;
import com.example.learning.admin.mapper.LoginLogMapper;
import com.example.learning.ai.entity.AiCallLogEntity;
import com.example.learning.ai.mapper.AiCallLogMapper;
import com.example.learning.course.entity.StudyRecordEntity;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.StudyRecordMapper;
import com.example.learning.studyroom.entity.StudyRoomEntity;
import com.example.learning.studyroom.mapper.StudyRoomMapper;
import com.example.learning.studyroom.realtime.StudyRoomRealtimeStore;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.mapper.UserMapper;
import jakarta.persistence.criteria.Predicate;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminDashboardServiceImpl implements AdminDashboardService {

    private final UserMapper userMapper;
    private final CourseMapper courseMapper;
    private final StudyRecordMapper studyRecordMapper;
    private final LoginLogMapper loginLogMapper;
    private final AiCallLogMapper aiCallLogMapper;
    private final StudyRoomMapper studyRoomMapper;
    private final StudyRoomRealtimeStore studyRoomRealtimeStore;
    private final Clock clock;

    @Override
    public AdminDashboardVO getDashboard() {
        LocalDate today = LocalDate.now(clock);
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = today.plusDays(1).atStartOfDay().minusNanos(1);
        return AdminDashboardVO.builder()
                .totalUsers(userMapper.countByDeletedFalse())
                .dailyActiveUsers(loginLogMapper.countDistinctActiveUsers(start, end))
                .totalCourses(courseMapper.countByDeletedFalse())
                .todayLearningDurationSeconds(studyRecordMapper.sumTrustedIncrementSecondsBetween(start, end))
                .currentStudyRoomOnlineUsers(resolveCurrentStudyRoomOnlineUsers())
                .todayAiCallCount(aiCallLogMapper.countByDeletedFalseAndCreatedAtBetween(start, end))
                .build();
    }

    @Override
    public AdminStatisticsVO getStatistics(AdminStatisticsQueryDTO queryDTO) {
        LocalDate today = LocalDate.now(clock);
        LocalDate startDate = today.minusDays(queryDTO.getDays() - 1L);
        LocalDateTime start = startDate.atStartOfDay();
        LocalDateTime end = today.plusDays(1).atStartOfDay().minusNanos(1);

        List<UserEntity> users = userMapper.findAllByDeletedFalseAndCreatedAtBetween(start, end);
        List<LoginLogEntity> loginLogs = loginLogMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            predicates.add(cb.isTrue(root.get("success")));
            predicates.add(cb.isNotNull(root.get("userId")));
            predicates.add(cb.between(root.get("createdAt"), start, end));
            return cb.and(predicates.toArray(Predicate[]::new));
        });
        List<AiCallLogEntity> aiCallLogs = aiCallLogMapper.findAllByDeletedFalseAndCreatedAtBetween(start, end);
        List<StudyRecordEntity> studyRecords = studyRecordMapper.findAllByDeletedFalseAndCreatedAtBetween(start, end);

        Map<LocalDate, Long> newUsersByDate = new LinkedHashMap<>();
        users.forEach(user -> newUsersByDate.merge(user.getCreatedAt().toLocalDate(), 1L, Long::sum));
        Map<LocalDate, Set<Long>> activeUsersByDate = new LinkedHashMap<>();
        loginLogs.forEach(log -> activeUsersByDate
                .computeIfAbsent(log.getCreatedAt().toLocalDate(), key -> new LinkedHashSet<>())
                .add(log.getUserId()));
        Map<LocalDate, Long> aiCallsByDate = new LinkedHashMap<>();
        aiCallLogs.forEach(log -> aiCallsByDate.merge(log.getCreatedAt().toLocalDate(), 1L, Long::sum));
        Map<LocalDate, Long> learningDurationByDate = new LinkedHashMap<>();
        studyRecords.forEach(record -> learningDurationByDate.merge(
                record.getCreatedAt().toLocalDate(),
                record.getTrustedIncrementSeconds(),
                Long::sum
        ));

        List<AdminDailyStatisticsItemVO> items = new ArrayList<>();
        for (LocalDate date = startDate; !date.isAfter(today); date = date.plusDays(1)) {
            items.add(AdminDailyStatisticsItemVO.builder()
                    .date(date)
                    .newUsers(newUsersByDate.getOrDefault(date, 0L))
                    .dailyActiveUsers(activeUsersByDate.getOrDefault(date, Set.of()).size())
                    .aiCallCount(aiCallsByDate.getOrDefault(date, 0L))
                    .learningDurationSeconds(learningDurationByDate.getOrDefault(date, 0L))
                    .build());
        }
        return AdminStatisticsVO.builder()
                .days(queryDTO.getDays())
                .items(items)
                .build();
    }

    private long resolveCurrentStudyRoomOnlineUsers() {
        long total = 0L;
        for (StudyRoomEntity room : studyRoomMapper.findAllByDeletedFalseOrderByIdAsc()) {
            try {
                total += studyRoomRealtimeStore.snapshotRoom(room.getId(), List.of()).onlineCount();
            } catch (Exception ignored) {
                // Degrade dashboard stats when Redis is temporarily unavailable.
            }
        }
        return total;
    }
}
