package com.example.learning.course.enums;

public enum ResourceAccessType {
    PUBLIC,
    ENROLLED
}
