package com.example.learning.user.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AuthRegisterDTO {

    @NotBlank(message = "username is required")
    @Size(min = 4, max = 64, message = "username length must be between 4 and 64")
    private String username;

    @NotBlank(message = "password is required")
    @Size(min = 6, max = 64, message = "password length must be between 6 and 64")
    private String password;

    @NotBlank(message = "nickname is required")
    @Size(max = 64, message = "nickname length must be less than or equal to 64")
    private String nickname;

    @Email(message = "email format is invalid")
    @Size(max = 128, message = "email length must be less than or equal to 128")
    private String email;

    @Pattern(regexp = "^$|^[0-9+\\-]{6,32}$", message = "phone format is invalid")
    private String phone;
}
