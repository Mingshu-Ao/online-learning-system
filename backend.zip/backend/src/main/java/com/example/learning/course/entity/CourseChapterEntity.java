package com.example.learning.course.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "course_chapter")
@EqualsAndHashCode(callSuper = true)
public class CourseChapterEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "parent_id")
    private Long parentId;

    @Column(name = "title", nullable = false, length = 128)
    private String title;

    @Column(name = "sort_order", nullable = false)
    private Integer sortOrder;
}
