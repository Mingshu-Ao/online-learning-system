package com.example.learning.quiz.vo;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class QuestionVO {

    private Long id;
    private Long courseId;
    private Long chapterId;
    private String stem;
    private String questionType;
    private JsonNode standardAnswer;
    private String analysis;
    private String difficulty;
    private String knowledgePoint;
    private Boolean partialCreditEnabled;
    private List<QuestionOptionVO> options;
}
