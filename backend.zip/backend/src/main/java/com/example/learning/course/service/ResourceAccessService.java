package com.example.learning.course.service;

import com.example.learning.course.vo.ResourceAccessVO;

public interface ResourceAccessService {

    ResourceAccessVO getResourceAccessUrl(Long currentUserId, Long resourceId);
}
