package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "question_option", uniqueConstraints = {
        @UniqueConstraint(name = "uk_question_option_key", columnNames = {"question_id", "option_key"})
})
@EqualsAndHashCode(callSuper = true)
public class QuestionOptionEntity extends BaseEntity {

    @Column(name = "question_id", nullable = false)
    private Long questionId;

    @Column(name = "option_key", nullable = false, length = 16)
    private String optionKey;

    @Lob
    @Column(name = "option_content", nullable = false)
    private String optionContent;

    @Column(name = "sort_order", nullable = false)
    private Integer sortOrder;
}
