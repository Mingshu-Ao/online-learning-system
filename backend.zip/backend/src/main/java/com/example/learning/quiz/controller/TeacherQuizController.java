package com.example.learning.quiz.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.quiz.dto.PaperCreateDTO;
import com.example.learning.quiz.dto.QuestionQueryDTO;
import com.example.learning.quiz.dto.QuestionUpsertDTO;
import com.example.learning.quiz.service.TeacherQuizService;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.QuestionVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher")
public class TeacherQuizController {

    private final TeacherQuizService teacherQuizService;

    @PostMapping("/questions")
    @PreAuthorize("hasAuthority('question:create')")
    public ApiResponse<QuestionVO> createQuestion(@Valid @RequestBody QuestionUpsertDTO upsertDTO) {
        return ApiResponse.success(teacherQuizService.createQuestion(SecurityUtils.getCurrentUserId(), upsertDTO));
    }

    @PutMapping("/questions/{id}")
    @PreAuthorize("hasAuthority('question:update')")
    public ApiResponse<QuestionVO> updateQuestion(@PathVariable Long id, @Valid @RequestBody QuestionUpsertDTO upsertDTO) {
        return ApiResponse.success(teacherQuizService.updateQuestion(SecurityUtils.getCurrentUserId(), id, upsertDTO));
    }

    @GetMapping("/questions")
    @PreAuthorize("hasAuthority('question:read')")
    public ApiResponse<List<QuestionVO>> listQuestions(@Valid QuestionQueryDTO queryDTO) {
        return ApiResponse.success(teacherQuizService.listQuestions(SecurityUtils.getCurrentUserId(), queryDTO));
    }

    @PostMapping("/papers")
    @PreAuthorize("hasAuthority('paper:create')")
    public ApiResponse<PaperDetailVO> createPaper(@Valid @RequestBody PaperCreateDTO createDTO) {
        return ApiResponse.success(teacherQuizService.createPaper(SecurityUtils.getCurrentUserId(), createDTO));
    }
}
