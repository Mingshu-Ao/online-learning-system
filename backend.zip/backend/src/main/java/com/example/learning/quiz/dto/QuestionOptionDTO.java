package com.example.learning.quiz.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class QuestionOptionDTO {

    @NotBlank(message = "optionKey cannot be blank")
    private String optionKey;

    @NotBlank(message = "content cannot be blank")
    private String content;
}
