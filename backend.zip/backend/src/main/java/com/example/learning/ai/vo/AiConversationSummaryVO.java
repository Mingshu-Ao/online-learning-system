package com.example.learning.ai.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AiConversationSummaryVO {
    Long conversationId;
    Long courseId;
    String inputType;
    String title;
    String latestSummary;
    LocalDateTime lastMessageAt;
}
