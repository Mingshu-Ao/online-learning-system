package com.example.learning.admin.mapper;

import com.example.learning.admin.entity.ResourceAccessLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ResourceAccessLogMapper extends JpaRepository<ResourceAccessLogEntity, Long>, JpaSpecificationExecutor<ResourceAccessLogEntity> {
}
