package com.example.learning.course.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "study_record")
@EqualsAndHashCode(callSuper = true)
public class StudyRecordEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "chapter_id", nullable = false)
    private Long chapterId;

    @Column(name = "resource_id", nullable = false)
    private Long resourceId;

    @Column(name = "reported_position", nullable = false)
    private Long reportedPosition;

    @Column(name = "trusted_position", nullable = false)
    private Long trustedPosition;

    @Column(name = "duration_seconds", nullable = false)
    private Long durationSeconds;

    @Column(name = "trusted_increment_seconds", nullable = false)
    private Long trustedIncrementSeconds;

    @Column(name = "report_interval_seconds", nullable = false)
    private Long reportIntervalSeconds;

    @Column(name = "playback_rate", nullable = false)
    private Double playbackRate;

    @Column(name = "client_timestamp")
    private Long clientTimestamp;

    @Column(name = "suspicious", nullable = false)
    private Boolean suspicious;

    @Column(name = "suspicious_reason", length = 255)
    private String suspiciousReason;
}
