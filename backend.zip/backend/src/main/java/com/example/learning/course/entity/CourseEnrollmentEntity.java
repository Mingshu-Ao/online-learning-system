package com.example.learning.course.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "course_enrollment", uniqueConstraints = {
        @UniqueConstraint(name = "uk_course_enrollment_pair", columnNames = {"course_id", "user_id"})
})
@EqualsAndHashCode(callSuper = true)
public class CourseEnrollmentEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "user_id", nullable = false)
    private Long userId;
}
