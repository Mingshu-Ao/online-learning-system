package com.example.learning.ai.mapper;

import com.example.learning.ai.entity.AiMessageEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AiMessageMapper extends JpaRepository<AiMessageEntity, Long> {

    List<AiMessageEntity> findAllByConversationIdAndDeletedFalseOrderByIdAsc(Long conversationId);
}
