package com.example.learning.course.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(
        name = "video_progress",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_video_progress_user_resource", columnNames = {"user_id", "resource_id"})
        }
)
@EqualsAndHashCode(callSuper = true)
public class VideoProgressEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "chapter_id", nullable = false)
    private Long chapterId;

    @Column(name = "resource_id", nullable = false)
    private Long resourceId;

    @Column(name = "current_position", nullable = false)
    private Long currentPosition;

    @Column(name = "duration_seconds", nullable = false)
    private Long durationSeconds;

    @Column(name = "effective_study_seconds", nullable = false)
    private Long effectiveStudySeconds;

    @Column(name = "progress_percent", nullable = false)
    private Double progressPercent;

    @Column(name = "completed", nullable = false)
    private Boolean completed;

    @Column(name = "last_playback_rate", nullable = false)
    private Double lastPlaybackRate;

    @Column(name = "last_client_timestamp")
    private Long lastClientTimestamp;

    @Column(name = "last_report_at", nullable = false)
    private LocalDateTime lastReportAt;

    @Column(name = "last_study_at", nullable = false)
    private LocalDateTime lastStudyAt;
}
