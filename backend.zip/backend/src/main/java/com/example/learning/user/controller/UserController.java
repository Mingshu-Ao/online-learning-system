package com.example.learning.user.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.security.SecurityUtils;
import com.example.learning.user.service.UserService;
import com.example.learning.user.vo.UserProfileVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/user")
public class UserController {

    private final UserService userService;

    @GetMapping("/profile")
    public ApiResponse<UserProfileVO> getCurrentUserProfile() {
        return ApiResponse.success(userService.getCurrentUserProfile(SecurityUtils.getCurrentUserId()));
    }
}
