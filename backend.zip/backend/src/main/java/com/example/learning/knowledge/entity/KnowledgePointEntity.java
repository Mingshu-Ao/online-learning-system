package com.example.learning.knowledge.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "knowledge_point", uniqueConstraints = {
        @UniqueConstraint(name = "uk_knowledge_point_course_name", columnNames = {"course_id", "name"})
})
@EqualsAndHashCode(callSuper = true)
public class KnowledgePointEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "teacher_id", nullable = false)
    private Long teacherId;

    @Column(name = "name", nullable = false, length = 128)
    private String name;

    @Column(name = "description", length = 500)
    private String description;
}
