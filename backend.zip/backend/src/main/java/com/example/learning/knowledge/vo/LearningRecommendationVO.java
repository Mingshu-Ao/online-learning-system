package com.example.learning.knowledge.vo;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class LearningRecommendationVO {
    Long courseId;
    String batchNo;
    Boolean defaultRecommendation;
    LocalDateTime generatedAt;
    List<WeakKnowledgePointVO> weakKnowledgePoints;
    List<LearningRecommendationItemVO> recommendations;
}
