package com.example.learning.admin.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginLogVO {

    private Long id;
    private Long userId;
    private String username;
    private Boolean success;
    private String failureReason;
    private String requestPath;
    private String ipAddress;
    private String userAgent;
    private LocalDateTime createdAt;
}
