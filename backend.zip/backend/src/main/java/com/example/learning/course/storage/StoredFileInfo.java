package com.example.learning.course.storage;

public record StoredFileInfo(String storagePath, String accessUrl) {
}
