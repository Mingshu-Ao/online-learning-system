package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.course.dto.CourseChapterUpdateDTO;
import com.example.learning.course.service.TeacherCourseService;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher/chapters")
public class TeacherChapterController {

    private final TeacherCourseService teacherCourseService;

    @PutMapping("/{chapterId}")
    @PreAuthorize("hasAuthority('chapter:manage')")
    public ApiResponse<CourseChapterVO> updateChapter(@PathVariable Long chapterId,
                                                      @Valid @RequestBody CourseChapterUpdateDTO updateDTO) {
        return ApiResponse.success(teacherCourseService.updateChapter(SecurityUtils.getCurrentUserId(), chapterId, updateDTO));
    }
}
