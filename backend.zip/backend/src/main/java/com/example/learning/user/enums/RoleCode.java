package com.example.learning.user.enums;

public enum RoleCode {
    STUDENT,
    TEACHER,
    ADMIN
}
