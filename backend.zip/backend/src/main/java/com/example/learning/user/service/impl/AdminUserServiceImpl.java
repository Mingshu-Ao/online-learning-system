package com.example.learning.user.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.common.vo.PageResultVO;
import com.example.learning.user.dto.AssignRolesDTO;
import com.example.learning.user.dto.ResetPasswordDTO;
import com.example.learning.user.dto.UpdateUserStatusDTO;
import com.example.learning.user.dto.UserQueryDTO;
import com.example.learning.user.entity.PermissionEntity;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.RolePermissionEntity;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.entity.UserRoleEntity;
import com.example.learning.user.enums.RoleCode;
import com.example.learning.user.enums.UserStatus;
import com.example.learning.user.mapper.PermissionMapper;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.RolePermissionMapper;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import com.example.learning.user.service.AdminUserService;
import com.example.learning.user.vo.UserListItemVO;
import com.example.learning.user.vo.UserProfileVO;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class AdminUserServiceImpl implements AdminUserService {

    private final UserMapper userMapper;
    private final RoleMapper roleMapper;
    private final UserRoleMapper userRoleMapper;
    private final RolePermissionMapper rolePermissionMapper;
    private final PermissionMapper permissionMapper;
    private final PasswordEncoder passwordEncoder;

    @Override
    public PageResultVO<UserListItemVO> listUsers(UserQueryDTO queryDTO) {
        PageRequest pageRequest = PageRequest.of(
                queryDTO.getPageNum() - 1,
                queryDTO.getPageSize(),
                Sort.by(Sort.Direction.DESC, "id")
        );
        Specification<UserEntity> specification = (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(criteriaBuilder.isFalse(root.get("deleted")));
            if (StringUtils.hasText(queryDTO.getKeyword())) {
                String keyword = "%" + queryDTO.getKeyword().trim() + "%";
                predicates.add(criteriaBuilder.or(
                        criteriaBuilder.like(root.get("username"), keyword),
                        criteriaBuilder.like(root.get("nickname"), keyword),
                        criteriaBuilder.like(root.get("email"), keyword),
                        criteriaBuilder.like(root.get("phone"), keyword)
                ));
            }
            if (queryDTO.getStatus() != null) {
                predicates.add(criteriaBuilder.equal(root.get("status"), queryDTO.getStatus()));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };

        Page<UserEntity> page = userMapper.findAll(specification, pageRequest);
        Map<Long, List<String>> roleMap = buildUserRoleCodeMap(page.getContent().stream().map(UserEntity::getId).toList());
        List<UserListItemVO> records = page.getContent().stream()
                .map(user -> UserListItemVO.builder()
                        .id(user.getId())
                        .username(user.getUsername())
                        .nickname(user.getNickname())
                        .email(user.getEmail())
                        .phone(user.getPhone())
                        .status(user.getStatus().name())
                        .roles(roleMap.getOrDefault(user.getId(), List.of()))
                        .build())
                .toList();

        return PageResultVO.<UserListItemVO>builder()
                .total(page.getTotalElements())
                .records(records)
                .build();
    }

    @Override
    @Transactional
    public void updateUserStatus(Long userId, UpdateUserStatusDTO updateUserStatusDTO) {
        UserEntity user = userMapper.findByIdAndDeletedFalse(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        user.setStatus(updateUserStatusDTO.getStatus());
        if (updateUserStatusDTO.getStatus() == UserStatus.DISABLED) {
            user.setTokenVersion(user.getTokenVersion() + 1);
        }
        userMapper.save(user);
    }

    @Override
    @Transactional
    public void resetPassword(Long userId, ResetPasswordDTO resetPasswordDTO) {
        UserEntity user = userMapper.findByIdAndDeletedFalse(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        user.setPasswordHash(passwordEncoder.encode(resetPasswordDTO.getNewPassword()));
        user.setTokenVersion(user.getTokenVersion() + 1);
        userMapper.save(user);
    }

    @Override
    @Transactional
    public UserProfileVO assignRoles(Long operatorUserId, Long userId, AssignRolesDTO assignRolesDTO) {
        UserEntity user = userMapper.findByIdAndDeletedFalse(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));

        List<Long> roleIds = assignRolesDTO.getRoleIds().stream().distinct().toList();
        List<RoleEntity> roles = roleMapper.findAllByIdInAndDeletedFalse(roleIds);
        if (roles.size() != roleIds.size()) {
            throw new BusinessException(ErrorCode.ROLE_NOT_FOUND);
        }

        List<Long> currentRoleIds = userRoleMapper.findAllByUserIdAndDeletedFalse(userId).stream()
                .map(UserRoleEntity::getRoleId)
                .distinct()
                .toList();
        boolean currentHasAdmin = rolesContainCode(currentRoleIds, RoleCode.ADMIN.name());
        boolean nextHasAdmin = roles.stream().anyMatch(role -> RoleCode.ADMIN.name().equals(role.getCode()));
        if (operatorUserId.equals(userId) && currentHasAdmin && !nextHasAdmin) {
            throw new BusinessException(ErrorCode.SELF_ROLE_REMOVAL_NOT_ALLOWED);
        }

        userRoleMapper.deleteByUserId(userId);
        List<UserRoleEntity> newUserRoles = roles.stream().map(role -> {
            UserRoleEntity entity = new UserRoleEntity();
            entity.setUserId(userId);
            entity.setRoleId(role.getId());
            return entity;
        }).toList();
        userRoleMapper.saveAll(newUserRoles);

        user.setTokenVersion(user.getTokenVersion() + 1);
        userMapper.save(user);
        return buildUserProfile(user, roles, roleIds);
    }

    private UserProfileVO buildUserProfile(UserEntity user, List<RoleEntity> roles, List<Long> roleIds) {
        List<RolePermissionEntity> rolePermissions = roleIds.isEmpty()
                ? List.of()
                : rolePermissionMapper.findAllByRoleIdInAndDeletedFalse(roleIds);
        List<Long> permissionIds = rolePermissions.stream().map(RolePermissionEntity::getPermissionId).distinct().toList();
        List<PermissionEntity> permissions = permissionIds.isEmpty()
                ? List.of()
                : permissionMapper.findAllByIdInAndDeletedFalse(permissionIds);
        Set<String> permissionCodes = new LinkedHashSet<>();
        permissions.forEach(permission -> permissionCodes.add(permission.getCode()));

        return UserProfileVO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .nickname(user.getNickname())
                .email(user.getEmail())
                .phone(user.getPhone())
                .status(user.getStatus().name())
                .roles(roles.stream().map(RoleEntity::getCode).toList())
                .permissions(new ArrayList<>(permissionCodes))
                .build();
    }

    private Map<Long, List<String>> buildUserRoleCodeMap(Collection<Long> userIds) {
        if (userIds.isEmpty()) {
            return Map.of();
        }
        List<UserRoleEntity> userRoles = userRoleMapper.findAllByUserIdInAndDeletedFalse(userIds);
        List<Long> roleIds = userRoles.stream().map(UserRoleEntity::getRoleId).distinct().toList();
        List<RoleEntity> roles = roleIds.isEmpty() ? List.of() : roleMapper.findAllByIdInAndDeletedFalse(roleIds);
        Map<Long, String> roleCodeMap = new HashMap<>();
        roles.forEach(role -> roleCodeMap.put(role.getId(), role.getCode()));

        Map<Long, List<String>> result = new HashMap<>();
        for (UserRoleEntity userRole : userRoles) {
            String roleCode = roleCodeMap.get(userRole.getRoleId());
            if (roleCode == null) {
                continue;
            }
            result.computeIfAbsent(userRole.getUserId(), key -> new ArrayList<>()).add(roleCode);
        }
        return result;
    }

    private boolean rolesContainCode(List<Long> roleIds, String roleCode) {
        if (roleIds.isEmpty()) {
            return false;
        }
        return roleMapper.findAllByIdInAndDeletedFalse(roleIds).stream()
                .anyMatch(role -> roleCode.equals(role.getCode()));
    }
}
