package com.example.learning.ai.service.impl;

import com.example.learning.ai.client.AiClientException;
import com.example.learning.ai.client.AiMicroserviceClient;
import com.example.learning.ai.config.AiServiceProperties;
import com.example.learning.ai.dto.AiAskRequestDTO;
import com.example.learning.ai.entity.AiCallLogEntity;
import com.example.learning.ai.entity.AiConversationEntity;
import com.example.learning.ai.entity.AiMessageEntity;
import com.example.learning.ai.enums.AiCallStatus;
import com.example.learning.ai.enums.AiInputType;
import com.example.learning.ai.enums.AiMessageRole;
import com.example.learning.ai.mapper.AiCallLogMapper;
import com.example.learning.ai.mapper.AiConversationMapper;
import com.example.learning.ai.mapper.AiMessageMapper;
import com.example.learning.ai.model.AiAnswerPayload;
import com.example.learning.ai.model.AiRecommendationPayload;
import com.example.learning.ai.service.AiAssistantService;
import com.example.learning.ai.service.AiRateLimitService;
import com.example.learning.ai.vo.AiAssistantResponseVO;
import com.example.learning.ai.vo.AiConversationDetailVO;
import com.example.learning.ai.vo.AiConversationMessageVO;
import com.example.learning.ai.vo.AiConversationSummaryVO;
import com.example.learning.ai.vo.AiRecommendationVO;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class AiAssistantServiceImpl implements AiAssistantService {

    private static final int MAX_SUMMARY_LENGTH = 500;
    private static final int MAX_TITLE_LENGTH = 60;

    private final AiConversationMapper aiConversationMapper;
    private final AiMessageMapper aiMessageMapper;
    private final AiCallLogMapper aiCallLogMapper;
    private final CourseMapper courseMapper;
    private final CourseEnrollmentMapper courseEnrollmentMapper;
    private final CourseResourceMapper courseResourceMapper;
    private final AiRateLimitService aiRateLimitService;
    private final AiMicroserviceClient aiMicroserviceClient;
    private final AiServiceProperties aiServiceProperties;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    @Override
    @Transactional
    public AiAssistantResponseVO askQuestion(Long userId, AiAskRequestDTO requestDTO) {
        CourseEntity course = getAccessibleCourse(userId, requestDTO.getCourseId());
        aiRateLimitService.assertAllowed(userId, AiInputType.TEXT);

        AiConversationEntity conversation = createConversation(userId, course.getId(), AiInputType.TEXT,
                truncate(requestDTO.getQuestion(), MAX_TITLE_LENGTH));
        saveUserTextMessage(conversation.getId(), requestDTO.getQuestion());

        long startedAt = System.nanoTime();
        try {
            AiAnswerPayload payload = filterRecommendations(aiMicroserviceClient.ask(userId, course.getId(), requestDTO.getQuestion()));
            AiAssistantResponseVO response = toResponseVO(conversation.getId(), payload, false, null);
            saveAssistantMessage(conversation, response, payload);
            saveCallLog(userId, conversation.getId(), course.getId(), AiInputType.TEXT, "/ai/ask",
                    "question=" + truncate(requestDTO.getQuestion(), MAX_SUMMARY_LENGTH),
                    serializePayload(payload), null, startedAt, AiCallStatus.SUCCESS);
            return response;
        } catch (AiClientException ex) {
            AiAssistantResponseVO fallback = buildFallbackResponse(conversation.getId(), requestDTO.getQuestion());
            saveAssistantMessage(conversation, fallback, null);
            saveCallLog(userId, conversation.getId(), course.getId(), AiInputType.TEXT, "/ai/ask",
                    "question=" + truncate(requestDTO.getQuestion(), MAX_SUMMARY_LENGTH),
                    fallback.getMessage(), ex.getMessage(), startedAt, AiCallStatus.FALLBACK);
            return fallback;
        }
    }

    @Override
    @Transactional
    public AiAssistantResponseVO solveImage(Long userId, Long courseId, MultipartFile image) {
        CourseEntity course = getAccessibleCourse(userId, courseId);
        validateImage(image);
        aiRateLimitService.assertAllowed(userId, AiInputType.IMAGE);

        AiConversationEntity conversation = createConversation(userId, course.getId(), AiInputType.IMAGE,
                truncate(Objects.requireNonNullElse(image.getOriginalFilename(), "图片错题解析"), MAX_TITLE_LENGTH));
        saveUserImageMessage(conversation.getId(), image);

        long startedAt = System.nanoTime();
        try {
            AiAnswerPayload payload = filterRecommendations(aiMicroserviceClient.solveImage(userId, course.getId(), image));
            AiAssistantResponseVO response = toResponseVO(conversation.getId(), payload, false, null);
            saveAssistantMessage(conversation, response, payload);
            saveCallLog(userId, conversation.getId(), course.getId(), AiInputType.IMAGE, "/ai/solve-image",
                    buildImageRequestSummary(image), serializePayload(payload), null, startedAt, AiCallStatus.SUCCESS);
            return response;
        } catch (AiClientException ex) {
            AiAssistantResponseVO fallback = buildFallbackResponse(conversation.getId(), "图片解析请求已记录");
            saveAssistantMessage(conversation, fallback, null);
            saveCallLog(userId, conversation.getId(), course.getId(), AiInputType.IMAGE, "/ai/solve-image",
                    buildImageRequestSummary(image), fallback.getMessage(), ex.getMessage(), startedAt, AiCallStatus.FALLBACK);
            return fallback;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<AiConversationSummaryVO> listConversations(Long userId) {
        return aiConversationMapper.findAllByUserIdAndDeletedFalseOrderByLastMessageAtDescIdDesc(userId).stream()
                .map(conversation -> AiConversationSummaryVO.builder()
                        .conversationId(conversation.getId())
                        .courseId(conversation.getCourseId())
                        .inputType(conversation.getInputType().name())
                        .title(conversation.getTitle())
                        .latestSummary(conversation.getLatestSummary())
                        .lastMessageAt(conversation.getLastMessageAt())
                        .build())
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public AiConversationDetailVO getConversation(Long userId, Long conversationId) {
        AiConversationEntity conversation = aiConversationMapper.findByIdAndUserIdAndDeletedFalse(conversationId, userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "ai conversation not found"));
        List<AiConversationMessageVO> messages = aiMessageMapper.findAllByConversationIdAndDeletedFalseOrderByIdAsc(conversationId).stream()
                .map(this::toMessageVO)
                .toList();
        return AiConversationDetailVO.builder()
                .conversationId(conversation.getId())
                .courseId(conversation.getCourseId())
                .inputType(conversation.getInputType().name())
                .title(conversation.getTitle())
                .latestSummary(conversation.getLatestSummary())
                .lastMessageAt(conversation.getLastMessageAt())
                .messages(messages)
                .build();
    }

    private CourseEntity getAccessibleCourse(Long userId, Long courseId) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (course.getStatus() != CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_NOT_PUBLISHED);
        }
        if (!courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(courseId, userId)) {
            throw new BusinessException(ErrorCode.USER_NOT_ENROLLED);
        }
        return course;
    }

    private void validateImage(MultipartFile image) {
        if (image == null || image.isEmpty()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "image cannot be empty");
        }
        if (image.getSize() > aiServiceProperties.getMaxImageSizeBytes()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "image size exceeds limit");
        }
        String contentType = image.getContentType();
        if (contentType == null || aiServiceProperties.getAllowedImageContentTypes().stream().noneMatch(contentType::equalsIgnoreCase)) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "image content type is not supported");
        }
        String fileName = Objects.requireNonNullElse(image.getOriginalFilename(), "").toLowerCase();
        boolean extensionAllowed = aiServiceProperties.getAllowedImageExtensions().stream().anyMatch(fileName::endsWith);
        if (!extensionAllowed) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "image extension is not supported");
        }
    }

    private AiConversationEntity createConversation(Long userId, Long courseId, AiInputType inputType, String title) {
        AiConversationEntity conversation = new AiConversationEntity();
        conversation.setUserId(userId);
        conversation.setCourseId(courseId);
        conversation.setInputType(inputType);
        conversation.setTitle(title == null || title.isBlank() ? "AI 助教会话" : title);
        conversation.setLatestSummary(title);
        conversation.setLastMessageAt(LocalDateTime.now(clock));
        return aiConversationMapper.save(conversation);
    }

    private void saveUserTextMessage(Long conversationId, String question) {
        AiMessageEntity message = new AiMessageEntity();
        message.setConversationId(conversationId);
        message.setMessageRole(AiMessageRole.USER);
        message.setInputType(AiInputType.TEXT);
        message.setContent(question);
        aiMessageMapper.save(message);
    }

    private void saveUserImageMessage(Long conversationId, MultipartFile image) {
        AiMessageEntity message = new AiMessageEntity();
        message.setConversationId(conversationId);
        message.setMessageRole(AiMessageRole.USER);
        message.setInputType(AiInputType.IMAGE);
        message.setContent("上传图片请求");
        message.setFileName(image.getOriginalFilename());
        message.setMimeType(image.getContentType());
        message.setFileSize(image.getSize());
        aiMessageMapper.save(message);
    }

    private void saveAssistantMessage(AiConversationEntity conversation, AiAssistantResponseVO response, AiAnswerPayload payload) {
        AiMessageEntity message = new AiMessageEntity();
        message.setConversationId(conversation.getId());
        message.setMessageRole(AiMessageRole.ASSISTANT);
        message.setInputType(conversation.getInputType());
        message.setContent(response.getMessage() != null ? response.getMessage() : summarizeResponse(response));
        message.setStructuredPayload(payload == null ? null : serializePayload(payload));
        aiMessageMapper.save(message);

        conversation.setLatestSummary(truncate(message.getContent(), MAX_SUMMARY_LENGTH));
        conversation.setLastMessageAt(LocalDateTime.now(clock));
        aiConversationMapper.save(conversation);
    }

    private void saveCallLog(Long userId,
                             Long conversationId,
                             Long courseId,
                             AiInputType inputType,
                             String endpoint,
                             String requestSummary,
                             String responseSummary,
                             String errorMessage,
                             long startedAt,
                             AiCallStatus status) {
        AiCallLogEntity log = new AiCallLogEntity();
        log.setUserId(userId);
        log.setConversationId(conversationId);
        log.setCourseId(courseId);
        log.setInputType(inputType);
        log.setEndpoint(endpoint);
        log.setStatus(status);
        log.setRequestSummary(truncate(requestSummary, MAX_SUMMARY_LENGTH));
        log.setResponseSummary(truncate(responseSummary, MAX_SUMMARY_LENGTH));
        log.setErrorMessage(truncate(errorMessage, MAX_SUMMARY_LENGTH));
        log.setDurationMs((System.nanoTime() - startedAt) / 1_000_000L);
        aiCallLogMapper.save(log);
    }

    private AiAssistantResponseVO buildFallbackResponse(Long conversationId, String questionText) {
        return AiAssistantResponseVO.builder()
                .conversationId(conversationId)
                .questionText(questionText)
                .knowledgePoints(List.of())
                .solutionSteps(List.of())
                .recommendations(List.of())
                .degraded(Boolean.TRUE)
                .message(aiServiceProperties.getDegradedMessage())
                .build();
    }

    private AiAssistantResponseVO toResponseVO(Long conversationId, AiAnswerPayload payload, boolean degraded, String message) {
        return AiAssistantResponseVO.builder()
                .conversationId(conversationId)
                .questionText(payload.getQuestionText())
                .knowledgePoints(payload.getKnowledgePoints() == null ? List.of() : payload.getKnowledgePoints())
                .difficulty(payload.getDifficulty())
                .solutionSteps(payload.getSolutionSteps() == null ? List.of() : payload.getSolutionSteps())
                .mistakeAnalysis(payload.getMistakeAnalysis())
                .recommendations(toRecommendationVOs(payload.getRecommendations()))
                .degraded(degraded)
                .message(message)
                .build();
    }

    private List<AiRecommendationVO> toRecommendationVOs(List<AiRecommendationPayload> items) {
        if (items == null) {
            return List.of();
        }
        return items.stream()
                .map(item -> AiRecommendationVO.builder()
                        .type(item.getType())
                        .resourceId(item.getResourceId())
                        .reason(item.getReason())
                        .build())
                .toList();
    }

    private AiConversationMessageVO toMessageVO(AiMessageEntity message) {
        return AiConversationMessageVO.builder()
                .messageId(message.getId())
                .role(message.getMessageRole().name())
                .inputType(message.getInputType().name())
                .content(message.getContent())
                .fileName(message.getFileName())
                .mimeType(message.getMimeType())
                .fileSize(message.getFileSize())
                .createdAt(message.getCreatedAt())
                .structuredResponse(parseStructuredResponse(message))
                .build();
    }

    private AiAssistantResponseVO parseStructuredResponse(AiMessageEntity message) {
        if (message.getStructuredPayload() == null || message.getStructuredPayload().isBlank()) {
            return null;
        }
        try {
            AiAnswerPayload payload = objectMapper.readValue(message.getStructuredPayload(), AiAnswerPayload.class);
            return toResponseVO(message.getConversationId(), payload, false, null);
        } catch (Exception ex) {
            return null;
        }
    }

    private String serializePayload(AiAnswerPayload payload) {
        try {
            return objectMapper.writeValueAsString(payload);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "ai payload serialization failed");
        }
    }

    private AiAnswerPayload filterRecommendations(AiAnswerPayload payload) {
        if (payload.getRecommendations() == null || payload.getRecommendations().isEmpty()) {
            payload.setRecommendations(List.of());
            return payload;
        }
        Set<Long> resourceIds = payload.getRecommendations().stream()
                .map(AiRecommendationPayload::getResourceId)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(HashSet::new));
        if (resourceIds.isEmpty()) {
            return payload;
        }
        Set<Long> existingIds = courseResourceMapper.findAllById(resourceIds).stream()
                .filter(resource -> !Boolean.TRUE.equals(resource.getDeleted()))
                .map(CourseResourceEntity::getId)
                .collect(Collectors.toSet());
        payload.setRecommendations(payload.getRecommendations().stream()
                .filter(item -> item.getResourceId() == null || existingIds.contains(item.getResourceId()))
                .toList());
        return payload;
    }

    private String buildImageRequestSummary(MultipartFile image) {
        return "fileName=" + image.getOriginalFilename()
                + ", contentType=" + image.getContentType()
                + ", size=" + image.getSize();
    }

    private String summarizeResponse(AiAssistantResponseVO response) {
        if (response.getMistakeAnalysis() != null && !response.getMistakeAnalysis().isBlank()) {
            return truncate(response.getMistakeAnalysis(), MAX_SUMMARY_LENGTH);
        }
        if (!response.getSolutionSteps().isEmpty()) {
            return truncate(String.join(" ", response.getSolutionSteps()), MAX_SUMMARY_LENGTH);
        }
        if (!response.getKnowledgePoints().isEmpty()) {
            return truncate("知识点：" + String.join("、", response.getKnowledgePoints()), MAX_SUMMARY_LENGTH);
        }
        return aiServiceProperties.getDegradedMessage();
    }

    private String truncate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }
}
