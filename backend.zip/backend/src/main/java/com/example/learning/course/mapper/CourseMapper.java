package com.example.learning.course.mapper;

import com.example.learning.course.entity.CourseEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CourseMapper extends JpaRepository<CourseEntity, Long>, JpaSpecificationExecutor<CourseEntity> {

    Optional<CourseEntity> findByIdAndDeletedFalse(Long id);

    long countByDeletedFalse();
}
