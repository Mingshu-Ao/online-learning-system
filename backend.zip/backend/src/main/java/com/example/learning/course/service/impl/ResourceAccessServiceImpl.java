package com.example.learning.course.service.impl;

import com.example.learning.audit.AuditLogService;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceAccessType;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.service.ResourceAccessService;
import com.example.learning.course.vo.ResourceAccessVO;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.UserRoleEntity;
import com.example.learning.user.enums.RoleCode;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ResourceAccessServiceImpl implements ResourceAccessService {

    private final CourseResourceMapper courseResourceMapper;
    private final CourseMapper courseMapper;
    private final CourseEnrollmentMapper courseEnrollmentMapper;
    private final UserRoleMapper userRoleMapper;
    private final RoleMapper roleMapper;
    private final AuditLogService auditLogService;

    @Override
    public ResourceAccessVO getResourceAccessUrl(Long currentUserId, Long resourceId) {
        CourseResourceEntity resource = courseResourceMapper.findByIdAndDeletedFalse(resourceId)
                .orElseThrow(() -> new BusinessException(ErrorCode.RESOURCE_NOT_FOUND));
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(resource.getCourseId())
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));

        if (isAdmin(currentUserId) || currentUserId.equals(course.getTeacherId())) {
            auditLogService.recordResourceAccess(currentUserId, course.getId(), resource.getId(), resource.getResourceType().name());
            return buildAccessVO(resource);
        }
        if (course.getStatus() != CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_NOT_PUBLISHED);
        }
        if (resource.getAccessType() == ResourceAccessType.ENROLLED
                && !courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(course.getId(), currentUserId)) {
            throw new BusinessException(ErrorCode.NO_COURSE_ACCESS_PERMISSION);
        }
        auditLogService.recordResourceAccess(currentUserId, course.getId(), resource.getId(), resource.getResourceType().name());
        return buildAccessVO(resource);
    }

    private boolean isAdmin(Long userId) {
        List<UserRoleEntity> userRoles = userRoleMapper.findAllByUserIdAndDeletedFalse(userId);
        if (userRoles.isEmpty()) {
            return false;
        }
        List<Long> roleIds = userRoles.stream().map(UserRoleEntity::getRoleId).distinct().toList();
        List<RoleEntity> roles = roleMapper.findAllByIdInAndDeletedFalse(roleIds);
        return roles.stream().anyMatch(role -> RoleCode.ADMIN.name().equals(role.getCode()));
    }

    private ResourceAccessVO buildAccessVO(CourseResourceEntity resource) {
        return ResourceAccessVO.builder()
                .resourceId(resource.getId())
                .accessUrl(resource.getFileUrl())
                .resourceType(resource.getResourceType().name())
                .build();
    }
}
