package com.example.learning.admin.mapper;

import com.example.learning.admin.entity.SystemErrorLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface SystemErrorLogMapper extends JpaRepository<SystemErrorLogEntity, Long>, JpaSpecificationExecutor<SystemErrorLogEntity> {
}
