package com.example.learning.websocket;

import com.example.learning.security.SecurityUser;
import java.security.Principal;

public record StudyRoomWebSocketPrincipal(SecurityUser securityUser) implements Principal {

    @Override
    public String getName() {
        return securityUser.getId().toString();
    }
}
