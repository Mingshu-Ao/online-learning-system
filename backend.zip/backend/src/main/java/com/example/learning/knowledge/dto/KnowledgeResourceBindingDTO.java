package com.example.learning.knowledge.dto;

import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class KnowledgeResourceBindingDTO {

    @NotNull
    private List<Long> chapterIds;

    @NotNull
    private List<Long> courseResourceIds;
}
