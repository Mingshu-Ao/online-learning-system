package com.example.learning.course.service;

import com.example.learning.common.vo.PageResultVO;
import com.example.learning.course.dto.CourseListQueryDTO;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.course.vo.CourseListItemVO;
import java.util.List;

public interface CoursePublicService {

    PageResultVO<CourseListItemVO> listPublishedCourses(CourseListQueryDTO queryDTO);

    CourseDetailVO getPublishedCourseDetail(Long courseId);

    List<CourseChapterVO> listPublishedCourseChapters(Long courseId);
}
