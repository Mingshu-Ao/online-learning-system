package com.example.learning.ai.vo;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AiConversationDetailVO {
    Long conversationId;
    Long courseId;
    String inputType;
    String title;
    String latestSummary;
    LocalDateTime lastMessageAt;
    List<AiConversationMessageVO> messages;
}
