package com.example.learning.course.mapper;

import com.example.learning.course.entity.CourseChapterEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseChapterMapper extends JpaRepository<CourseChapterEntity, Long> {

    Optional<CourseChapterEntity> findByIdAndDeletedFalse(Long id);

    List<CourseChapterEntity> findAllByCourseIdAndDeletedFalseOrderBySortOrderAscIdAsc(Long courseId);

    List<CourseChapterEntity> findAllByIdInAndDeletedFalse(Collection<Long> ids);
}
