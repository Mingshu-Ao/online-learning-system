package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.WrongQuestionEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WrongQuestionMapper extends JpaRepository<WrongQuestionEntity, Long> {

    Optional<WrongQuestionEntity> findByIdAndDeletedFalse(Long id);

    List<WrongQuestionEntity> findAllByUserIdAndDeletedFalseOrderByLastWrongAtDesc(Long userId);

    Optional<WrongQuestionEntity> findFirstByUserIdAndQuestionIdAndDeletedFalseOrderByCreatedAtDesc(Long userId, Long questionId);
}
