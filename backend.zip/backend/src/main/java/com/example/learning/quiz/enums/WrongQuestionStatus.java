package com.example.learning.quiz.enums;

public enum WrongQuestionStatus {
    UNMASTERED,
    REVIEWING,
    MASTERED
}
