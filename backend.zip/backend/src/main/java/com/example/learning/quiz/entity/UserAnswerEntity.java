package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.quiz.enums.QuestionType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "user_answer", uniqueConstraints = {
        @UniqueConstraint(name = "uk_user_answer_question", columnNames = {"exam_record_id", "paper_question_id"})
})
@EqualsAndHashCode(callSuper = true)
public class UserAnswerEntity extends BaseEntity {

    @Column(name = "exam_record_id", nullable = false)
    private Long examRecordId;

    @Column(name = "paper_question_id", nullable = false)
    private Long paperQuestionId;

    @Column(name = "question_id", nullable = false)
    private Long questionId;

    @Enumerated(EnumType.STRING)
    @Column(name = "question_type", nullable = false, length = 32)
    private QuestionType questionType;

    @Lob
    @Column(name = "answer_content")
    private String answerContent;

    @Column(name = "awarded_score", precision = 10, scale = 2)
    private BigDecimal awardedScore;

    @Column(name = "correct_flag")
    private Boolean correct;

    @Column(name = "auto_graded", nullable = false)
    private Boolean autoGraded;

    @Column(name = "needs_manual_review", nullable = false)
    private Boolean needsManualReview;
}
