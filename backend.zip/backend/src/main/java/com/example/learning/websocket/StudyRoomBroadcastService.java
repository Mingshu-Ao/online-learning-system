package com.example.learning.websocket;

import com.example.learning.studyroom.vo.StudyRoomWsEnvelopeVO;

public interface StudyRoomBroadcastService {

    void registerSession(Long userId, org.springframework.web.socket.WebSocketSession session, Long currentRoomId);

    void unregisterSession(org.springframework.web.socket.WebSocketSession session);

    void bindUserToRoom(Long userId, Long roomId);

    void unbindUserFromRoom(Long userId);

    void broadcastToRoom(Long roomId, StudyRoomWsEnvelopeVO message);

    void sendToUser(Long userId, StudyRoomWsEnvelopeVO message);

    boolean hasActiveSession(Long userId);
}
