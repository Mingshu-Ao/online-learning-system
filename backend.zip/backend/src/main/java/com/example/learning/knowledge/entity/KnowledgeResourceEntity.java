package com.example.learning.knowledge.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.knowledge.enums.KnowledgeResourceType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "knowledge_resource", uniqueConstraints = {
        @UniqueConstraint(name = "uk_knowledge_resource_pair", columnNames = {"knowledge_point_id", "resource_type", "resource_id"})
})
@EqualsAndHashCode(callSuper = true)
public class KnowledgeResourceEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "knowledge_point_id", nullable = false)
    private Long knowledgePointId;

    @Enumerated(EnumType.STRING)
    @Column(name = "resource_type", nullable = false, length = 32)
    private KnowledgeResourceType resourceType;

    @Column(name = "resource_id", nullable = false)
    private Long resourceId;
}
