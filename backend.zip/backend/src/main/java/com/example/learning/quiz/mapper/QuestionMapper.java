package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.QuestionEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface QuestionMapper extends JpaRepository<QuestionEntity, Long>, JpaSpecificationExecutor<QuestionEntity> {

    Optional<QuestionEntity> findByIdAndDeletedFalse(Long id);

    List<QuestionEntity> findAllByIdInAndDeletedFalse(List<Long> ids);
}
