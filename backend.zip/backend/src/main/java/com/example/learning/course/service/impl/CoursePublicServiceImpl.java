package com.example.learning.course.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.common.vo.PageResultVO;
import com.example.learning.course.dto.CourseListQueryDTO;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.service.CoursePublicService;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.course.vo.CourseListItemVO;
import com.example.learning.course.vo.CourseResourceVO;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class CoursePublicServiceImpl implements CoursePublicService {

    private final CourseMapper courseMapper;
    private final CourseChapterMapper courseChapterMapper;
    private final CourseResourceMapper courseResourceMapper;

    @Override
    public PageResultVO<CourseListItemVO> listPublishedCourses(CourseListQueryDTO queryDTO) {
        PageRequest pageRequest = PageRequest.of(queryDTO.getPageNum() - 1, queryDTO.getPageSize(), Sort.by(Sort.Direction.DESC, "id"));
        Specification<CourseEntity> specification = (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(criteriaBuilder.isFalse(root.get("deleted")));
            predicates.add(criteriaBuilder.equal(root.get("status"), CourseStatus.PUBLISHED));
            if (StringUtils.hasText(queryDTO.getKeyword())) {
                String keyword = "%" + queryDTO.getKeyword().trim() + "%";
                predicates.add(criteriaBuilder.or(
                        criteriaBuilder.like(root.get("title"), keyword),
                        criteriaBuilder.like(root.get("summary"), keyword),
                        criteriaBuilder.like(root.get("teacherName"), keyword)
                ));
            }
            if (StringUtils.hasText(queryDTO.getCategory())) {
                predicates.add(criteriaBuilder.equal(root.get("category"), queryDTO.getCategory().trim()));
            }
            if (StringUtils.hasText(queryDTO.getDifficulty())) {
                predicates.add(criteriaBuilder.equal(root.get("difficulty"), queryDTO.getDifficulty().trim()));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };

        Page<CourseEntity> page = courseMapper.findAll(specification, pageRequest);
        List<CourseListItemVO> records = page.getContent().stream()
                .map(this::buildCourseListItem)
                .toList();
        return PageResultVO.<CourseListItemVO>builder()
                .total(page.getTotalElements())
                .records(records)
                .build();
    }

    @Override
    public CourseDetailVO getPublishedCourseDetail(Long courseId) {
        CourseEntity course = getCourse(courseId);
        ensurePublished(course);
        return buildCourseDetail(course, true);
    }

    @Override
    public List<CourseChapterVO> listPublishedCourseChapters(Long courseId) {
        CourseEntity course = getCourse(courseId);
        ensurePublished(course);
        return buildCourseChapters(courseId);
    }

    private CourseEntity getCourse(Long courseId) {
        return courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
    }

    private void ensurePublished(CourseEntity course) {
        if (course.getStatus() != CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_NOT_PUBLISHED);
        }
    }

    public CourseDetailVO buildCourseDetail(CourseEntity course, boolean includeChapters) {
        return CourseDetailVO.builder()
                .id(course.getId())
                .title(course.getTitle())
                .summary(course.getSummary())
                .coverUrl(course.getCoverUrl())
                .category(course.getCategory())
                .difficulty(course.getDifficulty())
                .teacherId(course.getTeacherId())
                .teacherName(course.getTeacherName())
                .studentCount(course.getStudentCount())
                .status(course.getStatus().name())
                .reviewComment(course.getReviewComment())
                .chapters(includeChapters ? buildCourseChapters(course.getId()) : List.of())
                .build();
    }

    private List<CourseChapterVO> buildCourseChapters(Long courseId) {
        List<CourseChapterEntity> chapters = courseChapterMapper.findAllByCourseIdAndDeletedFalseOrderBySortOrderAscIdAsc(courseId);
        if (chapters.isEmpty()) {
            return List.of();
        }
        List<Long> chapterIds = chapters.stream().map(CourseChapterEntity::getId).toList();
        List<CourseResourceEntity> resources = courseResourceMapper.findAllByChapterIdInAndDeletedFalse(chapterIds);
        Map<Long, List<CourseResourceVO>> resourceMap = new HashMap<>();
        for (CourseResourceEntity resource : resources) {
            resourceMap.computeIfAbsent(resource.getChapterId(), key -> new ArrayList<>()).add(buildCourseResource(resource));
        }
        return chapters.stream()
                .map(chapter -> CourseChapterVO.builder()
                        .id(chapter.getId())
                        .courseId(chapter.getCourseId())
                        .parentId(chapter.getParentId())
                        .title(chapter.getTitle())
                        .sortOrder(chapter.getSortOrder())
                        .resources(resourceMap.getOrDefault(chapter.getId(), List.of()))
                        .build())
                .toList();
    }

    private CourseListItemVO buildCourseListItem(CourseEntity course) {
        return CourseListItemVO.builder()
                .id(course.getId())
                .title(course.getTitle())
                .coverUrl(course.getCoverUrl())
                .teacherName(course.getTeacherName())
                .difficulty(course.getDifficulty())
                .studentCount(course.getStudentCount())
                .build();
    }

    public CourseResourceVO buildCourseResource(CourseResourceEntity resource) {
        return CourseResourceVO.builder()
                .id(resource.getId())
                .courseId(resource.getCourseId())
                .chapterId(resource.getChapterId())
                .title(resource.getTitle())
                .resourceType(resource.getResourceType().name())
                .accessType(resource.getAccessType().name())
                .fileUrl(resource.getFileUrl())
                .originalFileName(resource.getOriginalFileName())
                .mimeType(resource.getMimeType())
                .fileSize(resource.getFileSize())
                .durationSeconds(resource.getDurationSeconds())
                .transcodingStatus(resource.getTranscodingStatus().name())
                .coverUrl(resource.getCoverUrl())
                .build();
    }
}
