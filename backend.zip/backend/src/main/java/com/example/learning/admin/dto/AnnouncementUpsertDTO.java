package com.example.learning.admin.dto;

import com.example.learning.admin.enums.AnnouncementStatus;
import com.example.learning.admin.enums.AnnouncementVisibility;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class AnnouncementUpsertDTO {

    @NotBlank(message = "title is required")
    private String title;

    @NotBlank(message = "content is required")
    private String content;

    @NotNull(message = "visibility is required")
    private AnnouncementVisibility visibility;

    @NotNull(message = "status is required")
    private AnnouncementStatus status;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime publishAt;
}
