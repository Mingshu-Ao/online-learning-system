package com.example.learning.admin.vo;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AdminStatisticsVO {

    private int days;
    private List<AdminDailyStatisticsItemVO> items;
}
