package com.example.learning.ai.entity;

import com.example.learning.ai.enums.AiCallStatus;
import com.example.learning.ai.enums.AiInputType;
import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "ai_call_log")
@EqualsAndHashCode(callSuper = true)
public class AiCallLogEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "conversation_id", nullable = false)
    private Long conversationId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Enumerated(EnumType.STRING)
    @Column(name = "input_type", nullable = false, length = 32)
    private AiInputType inputType;

    @Column(name = "endpoint", nullable = false, length = 64)
    private String endpoint;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private AiCallStatus status;

    @Lob
    @Column(name = "request_summary", nullable = false)
    private String requestSummary;

    @Lob
    @Column(name = "response_summary")
    private String responseSummary;

    @Column(name = "error_message", length = 500)
    private String errorMessage;

    @Column(name = "duration_ms", nullable = false)
    private Long durationMs;
}
