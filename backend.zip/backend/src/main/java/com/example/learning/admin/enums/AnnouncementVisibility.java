package com.example.learning.admin.enums;

public enum AnnouncementVisibility {
    ALL,
    STUDENT,
    TEACHER,
    ADMIN
}
