package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.quiz.enums.ExamRecordStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "exam_record", uniqueConstraints = {
        @UniqueConstraint(name = "uk_exam_record_attempt", columnNames = {"paper_id", "user_id", "attempt_no"})
})
@EqualsAndHashCode(callSuper = true)
public class ExamRecordEntity extends BaseEntity {

    @Column(name = "paper_id", nullable = false)
    private Long paperId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "attempt_no", nullable = false)
    private Integer attemptNo;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "deadline_time", nullable = false)
    private LocalDateTime deadlineTime;

    @Column(name = "submit_time")
    private LocalDateTime submitTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private ExamRecordStatus status;

    @Column(name = "objective_score", precision = 10, scale = 2)
    private BigDecimal objectiveScore;

    @Column(name = "total_score", precision = 10, scale = 2)
    private BigDecimal totalScore;

    @Column(name = "pass_score", nullable = false, precision = 10, scale = 2)
    private BigDecimal passScore;

    @Column(name = "passed")
    private Boolean passed;

    @Column(name = "answered_count", nullable = false)
    private Integer answeredCount;

    @Column(name = "total_question_count", nullable = false)
    private Integer totalQuestionCount;
}
