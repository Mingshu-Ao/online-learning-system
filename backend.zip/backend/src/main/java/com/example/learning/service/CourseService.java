package com.example.learning.service;

import com.example.learning.dto.CourseQueryDTO;
import com.example.learning.vo.CourseSimpleVO;
import java.util.List;

public interface CourseService {

    List<CourseSimpleVO> listPublicCourses(CourseQueryDTO queryDTO);
}

