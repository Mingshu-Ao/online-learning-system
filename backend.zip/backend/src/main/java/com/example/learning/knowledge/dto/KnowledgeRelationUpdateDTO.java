package com.example.learning.knowledge.dto;

import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class KnowledgeRelationUpdateDTO {

    @NotNull
    private List<Long> prerequisiteIds;
}
