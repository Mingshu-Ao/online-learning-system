package com.example.learning.studyroom.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StudyRoomSeatVO {

    private Integer seatNo;
    private Long userId;
    private String nickname;
    private String state;
}
