package com.example.learning.admin.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class AdminStatisticsQueryDTO {

    @Min(value = 1, message = "days must be greater than 0")
    @Max(value = 30, message = "days must be less than or equal to 30")
    private int days = 7;
}
