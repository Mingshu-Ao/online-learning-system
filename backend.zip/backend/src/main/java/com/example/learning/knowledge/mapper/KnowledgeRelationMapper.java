package com.example.learning.knowledge.mapper;

import com.example.learning.knowledge.entity.KnowledgeRelationEntity;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KnowledgeRelationMapper extends JpaRepository<KnowledgeRelationEntity, Long> {

    List<KnowledgeRelationEntity> findAllByCourseIdAndDeletedFalse(Long courseId);

    List<KnowledgeRelationEntity> findAllByKnowledgePointIdInAndDeletedFalse(Collection<Long> knowledgePointIds);

    List<KnowledgeRelationEntity> findAllByKnowledgePointIdAndDeletedFalse(Long knowledgePointId);
}
