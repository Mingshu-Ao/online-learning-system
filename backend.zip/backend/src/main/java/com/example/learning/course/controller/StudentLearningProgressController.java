package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.course.dto.LearningStatsQueryDTO;
import com.example.learning.course.dto.VideoProgressReportDTO;
import com.example.learning.course.service.LearningProgressService;
import com.example.learning.course.vo.CourseLearningProgressVO;
import com.example.learning.course.vo.LearningStatsVO;
import com.example.learning.course.vo.VideoProgressReportVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student")
public class StudentLearningProgressController {

    private final LearningProgressService learningProgressService;

    @PostMapping("/video-progress")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<VideoProgressReportVO> reportVideoProgress(@Valid @RequestBody VideoProgressReportDTO reportDTO) {
        return ApiResponse.success(learningProgressService.reportVideoProgress(SecurityUtils.getCurrentUserId(), reportDTO));
    }

    @GetMapping("/courses/{courseId}/progress")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<CourseLearningProgressVO> getCourseProgress(@PathVariable Long courseId) {
        return ApiResponse.success(learningProgressService.getCourseProgress(SecurityUtils.getCurrentUserId(), courseId));
    }

    @GetMapping("/learning-stats")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<LearningStatsVO> getLearningStats(@Valid LearningStatsQueryDTO queryDTO) {
        return ApiResponse.success(learningProgressService.getLearningStats(SecurityUtils.getCurrentUserId(), queryDTO));
    }
}
