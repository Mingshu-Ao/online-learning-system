package com.example.learning.studyroom.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "room_checkin", uniqueConstraints = {
        @UniqueConstraint(name = "uk_room_checkin_daily", columnNames = {"room_id", "user_id", "checkin_date"})
})
@EqualsAndHashCode(callSuper = true)
public class RoomCheckinEntity extends BaseEntity {

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "checkin_date", nullable = false)
    private LocalDate checkinDate;

    @Column(name = "total_focus_minutes", nullable = false)
    private Integer totalFocusMinutes;

    @Column(name = "completed_count", nullable = false)
    private Integer completedCount;

    @Column(name = "last_checkin_at", nullable = false)
    private LocalDateTime lastCheckinAt;
}
