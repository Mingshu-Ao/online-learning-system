package com.example.learning.quiz.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.quiz.entity.PaperQuestionEntity;
import com.example.learning.quiz.enums.QuestionType;
import com.example.learning.quiz.service.QuizScoringService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.TextNode;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import org.springframework.stereotype.Service;

@Service
public class QuizScoringServiceImpl implements QuizScoringService {

    private final ObjectMapper objectMapper;

    public QuizScoringServiceImpl(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public ScoringResult score(PaperQuestionEntity paperQuestion, JsonNode answerNode) {
        QuestionType questionType = paperQuestion.getQuestionType();
        if (questionType == QuestionType.SHORT_ANSWER) {
            return new ScoringResult(null, null, false, true);
        }
        if (answerNode == null || answerNode.isNull()) {
            return new ScoringResult(BigDecimal.ZERO, Boolean.FALSE, true, false);
        }

        JsonNode standardAnswer = parseStoredJson(paperQuestion.getStandardAnswer());
        return switch (questionType) {
            case SINGLE_CHOICE -> scoreSingleChoice(paperQuestion.getScore(), standardAnswer, answerNode);
            case MULTIPLE_CHOICE -> scoreMultipleChoice(paperQuestion.getScore(), standardAnswer, answerNode,
                    Boolean.TRUE.equals(paperQuestion.getPartialCreditEnabled()));
            case TRUE_FALSE -> scoreTrueFalse(paperQuestion.getScore(), standardAnswer, answerNode);
            case FILL_BLANK -> scoreFillBlank(paperQuestion.getScore(), standardAnswer, answerNode);
            case SHORT_ANSWER -> new ScoringResult(null, null, false, true);
        };
    }

    private ScoringResult scoreSingleChoice(BigDecimal fullScore, JsonNode standardAnswer, JsonNode answerNode) {
        String expected = normalizeTextNode(standardAnswer);
        String actual = normalizeTextNode(answerNode);
        boolean correct = expected.equals(actual);
        return new ScoringResult(correct ? fullScore : BigDecimal.ZERO, correct, true, false);
    }

    private ScoringResult scoreMultipleChoice(BigDecimal fullScore,
                                              JsonNode standardAnswer,
                                              JsonNode answerNode,
                                              boolean partialCreditEnabled) {
        Set<String> expected = normalizeTextSet(standardAnswer);
        Set<String> actual = normalizeTextSet(answerNode);
        boolean correct = expected.equals(actual);
        if (correct) {
            return new ScoringResult(fullScore, Boolean.TRUE, true, false);
        }
        if (!partialCreditEnabled) {
            return new ScoringResult(BigDecimal.ZERO, Boolean.FALSE, true, false);
        }
        if (actual.isEmpty() || !expected.containsAll(actual)) {
            return new ScoringResult(BigDecimal.ZERO, Boolean.FALSE, true, false);
        }
        BigDecimal ratio = BigDecimal.valueOf(actual.size())
                .divide(BigDecimal.valueOf(expected.size()), 2, RoundingMode.HALF_UP);
        return new ScoringResult(fullScore.multiply(ratio).setScale(2, RoundingMode.HALF_UP), Boolean.FALSE, true, false);
    }

    private ScoringResult scoreTrueFalse(BigDecimal fullScore, JsonNode standardAnswer, JsonNode answerNode) {
        boolean expected = normalizeBoolean(standardAnswer);
        boolean actual = normalizeBoolean(answerNode);
        boolean correct = expected == actual;
        return new ScoringResult(correct ? fullScore : BigDecimal.ZERO, correct, true, false);
    }

    private ScoringResult scoreFillBlank(BigDecimal fullScore, JsonNode standardAnswer, JsonNode answerNode) {
        ArrayNode expected = normalizeBlankArray(standardAnswer);
        ArrayNode actual = normalizeBlankArray(answerNode);
        if (expected.size() != actual.size()) {
            return new ScoringResult(BigDecimal.ZERO, Boolean.FALSE, true, false);
        }
        for (int i = 0; i < expected.size(); i++) {
            if (!expected.get(i).asText().equals(actual.get(i).asText())) {
                return new ScoringResult(BigDecimal.ZERO, Boolean.FALSE, true, false);
            }
        }
        return new ScoringResult(fullScore, Boolean.TRUE, true, false);
    }

    private JsonNode parseStoredJson(String json) {
        try {
            return objectMapper.readTree(json);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "stored answer payload is invalid");
        }
    }

    private String normalizeTextNode(JsonNode node) {
        if (node == null || node.isNull()) {
            return "";
        }
        if (node.isTextual() || node.isNumber() || node.isBoolean()) {
            return node.asText().trim();
        }
        throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "answer format is invalid for current question type");
    }

    private Set<String> normalizeTextSet(JsonNode node) {
        if (!node.isArray()) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "multiple choice answer must be an array");
        }
        Set<String> values = new LinkedHashSet<>();
        node.forEach(item -> values.add(normalizeTextNode(item)));
        return values;
    }

    private boolean normalizeBoolean(JsonNode node) {
        if (node.isBoolean()) {
            return node.asBoolean();
        }
        if (node.isTextual()) {
            String text = node.asText().trim().toLowerCase(Locale.ROOT);
            if ("true".equals(text) || "t".equals(text) || "1".equals(text) || "yes".equals(text)) {
                return true;
            }
            if ("false".equals(text) || "f".equals(text) || "0".equals(text) || "no".equals(text)) {
                return false;
            }
        }
        throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "true/false answer must be boolean-like");
    }

    private ArrayNode normalizeBlankArray(JsonNode node) {
        ArrayNode normalized = JsonNodeFactory.instance.arrayNode();
        if (node.isArray()) {
            node.forEach(item -> normalized.add(TextNode.valueOf(normalizeBlankText(item))));
            return normalized;
        }
        normalized.add(TextNode.valueOf(normalizeBlankText(node)));
        return normalized;
    }

    private String normalizeBlankText(JsonNode node) {
        if (node == null || node.isNull()) {
            return "";
        }
        if (!node.isTextual() && !node.isNumber() && !node.isBoolean()) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "fill blank answer format is invalid");
        }
        return node.asText().trim().toLowerCase(Locale.ROOT);
    }
}
