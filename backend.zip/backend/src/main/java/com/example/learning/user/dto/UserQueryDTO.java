package com.example.learning.user.dto;

import com.example.learning.common.dto.PageRequestDTO;
import com.example.learning.user.enums.UserStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class UserQueryDTO extends PageRequestDTO {

    private String keyword;
    private UserStatus status;
}
