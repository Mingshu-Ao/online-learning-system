package com.example.learning.course.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.dto.CourseReviewDTO;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.enums.CourseReviewAction;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.service.AdminCourseService;
import com.example.learning.course.vo.CourseDetailVO;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AdminCourseServiceImpl implements AdminCourseService {

    private final CourseMapper courseMapper;

    @Override
    @Transactional
    public CourseDetailVO reviewCourse(Long courseId, CourseReviewDTO reviewDTO) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));

        if (reviewDTO.getAction() == CourseReviewAction.APPROVE) {
            if (course.getStatus() != CourseStatus.PENDING) {
                throw new BusinessException(ErrorCode.COURSE_STATUS_INVALID, "only pending course can be approved");
            }
            course.setStatus(CourseStatus.PUBLISHED);
            course.setReviewComment(null);
        } else if (reviewDTO.getAction() == CourseReviewAction.REJECT) {
            if (course.getStatus() != CourseStatus.PENDING) {
                throw new BusinessException(ErrorCode.COURSE_STATUS_INVALID, "only pending course can be rejected");
            }
            course.setStatus(CourseStatus.REJECTED);
            course.setReviewComment(reviewDTO.getReviewComment());
        } else if (reviewDTO.getAction() == CourseReviewAction.OFFLINE) {
            if (course.getStatus() != CourseStatus.PUBLISHED) {
                throw new BusinessException(ErrorCode.COURSE_STATUS_INVALID, "only published course can be taken offline");
            }
            course.setStatus(CourseStatus.OFFLINE);
            course.setReviewComment(reviewDTO.getReviewComment());
        }

        CourseEntity saved = courseMapper.save(course);
        return buildCourseDetail(saved);
    }

    private CourseDetailVO buildCourseDetail(CourseEntity course) {
        return CourseDetailVO.builder()
                .id(course.getId())
                .title(course.getTitle())
                .summary(course.getSummary())
                .coverUrl(course.getCoverUrl())
                .category(course.getCategory())
                .difficulty(course.getDifficulty())
                .teacherId(course.getTeacherId())
                .teacherName(course.getTeacherName())
                .studentCount(course.getStudentCount())
                .status(course.getStatus().name())
                .reviewComment(course.getReviewComment())
                .chapters(List.of())
                .build();
    }
}
