package com.example.learning.audit;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.user.vo.LoginVO;
import java.lang.reflect.Method;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.stereotype.Component;

@Aspect
@Component
@RequiredArgsConstructor
public class LoginAuditAspect {

    private final AuditLogService auditLogService;

    private final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();

    @Around("@annotation(com.example.learning.audit.LoginAudit)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        String username = extractUsername(joinPoint);
        try {
            Object result = joinPoint.proceed();
            LoginVO loginVO = extractLoginVO(result);
            auditLogService.recordLogin(loginVO == null ? null : loginVO.getUserId(),
                    loginVO == null ? username : loginVO.getUsername(),
                    true,
                    null);
            return result;
        } catch (Throwable throwable) {
            auditLogService.recordLogin(null, username, false, throwable.getMessage());
            throw throwable;
        }
    }

    private String extractUsername(ProceedingJoinPoint joinPoint) {
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        String[] parameterNames = parameterNameDiscoverer.getParameterNames(method);
        Object[] args = joinPoint.getArgs();
        for (int i = 0; i < args.length; i++) {
            Object arg = args[i];
            if (arg == null) {
                continue;
            }
            String parameterName = parameterNames != null && i < parameterNames.length ? parameterNames[i] : "";
            if ("loginDTO".equals(parameterName) || arg.getClass().getSimpleName().contains("LoginDTO")) {
                try {
                    Method getter = arg.getClass().getMethod("getUsername");
                    Object value = getter.invoke(arg);
                    return value == null ? null : String.valueOf(value);
                } catch (ReflectiveOperationException ignored) {
                    return null;
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private LoginVO extractLoginVO(Object result) {
        if (result instanceof ApiResponse<?> apiResponse && apiResponse.getData() instanceof LoginVO loginVO) {
            return loginVO;
        }
        return null;
    }
}
