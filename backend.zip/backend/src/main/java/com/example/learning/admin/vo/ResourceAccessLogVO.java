package com.example.learning.admin.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResourceAccessLogVO {

    private Long id;
    private Long userId;
    private Long courseId;
    private Long resourceId;
    private String resourceType;
    private String requestPath;
    private String ipAddress;
    private String userAgent;
    private LocalDateTime createdAt;
}
