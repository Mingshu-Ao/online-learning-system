package com.example.learning.knowledge.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "knowledge_relation", uniqueConstraints = {
        @UniqueConstraint(name = "uk_knowledge_relation_pair", columnNames = {"knowledge_point_id", "prerequisite_id"})
})
@EqualsAndHashCode(callSuper = true)
public class KnowledgeRelationEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "knowledge_point_id", nullable = false)
    private Long knowledgePointId;

    @Column(name = "prerequisite_id", nullable = false)
    private Long prerequisiteId;
}
