package com.example.learning.admin.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AdminDashboardVO {

    private long totalUsers;
    private long dailyActiveUsers;
    private long totalCourses;
    private long todayLearningDurationSeconds;
    private long currentStudyRoomOnlineUsers;
    private long todayAiCallCount;
}
