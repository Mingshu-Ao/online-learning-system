package com.example.learning.studyroom.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StudyRoomJoinVO {

    private Long roomId;
    private Integer seatNo;
    private String state;
}
