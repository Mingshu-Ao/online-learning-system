package com.example.learning.user.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.audit.LoginAudit;
import com.example.learning.security.SecurityUtils;
import com.example.learning.user.dto.AuthLoginDTO;
import com.example.learning.user.dto.AuthRegisterDTO;
import com.example.learning.user.service.AuthService;
import com.example.learning.user.vo.LoginVO;
import com.example.learning.user.vo.UserProfileVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ApiResponse<UserProfileVO> register(@Valid @RequestBody AuthRegisterDTO registerDTO) {
        return ApiResponse.success(authService.register(registerDTO));
    }

    @PostMapping("/login")
    @LoginAudit
    public ApiResponse<LoginVO> login(@Valid @RequestBody AuthLoginDTO loginDTO) {
        return ApiResponse.success(authService.login(loginDTO));
    }

    @PostMapping("/logout")
    public ApiResponse<Void> logout() {
        authService.logout(SecurityUtils.getCurrentUserId());
        return ApiResponse.success(null);
    }
}
