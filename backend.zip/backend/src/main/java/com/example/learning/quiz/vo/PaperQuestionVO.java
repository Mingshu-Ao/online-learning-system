package com.example.learning.quiz.vo;

import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaperQuestionVO {

    private Long questionId;
    private String stem;
    private String questionType;
    private BigDecimal score;
    private Boolean partialCreditEnabled;
    private List<QuestionOptionVO> options;
}
