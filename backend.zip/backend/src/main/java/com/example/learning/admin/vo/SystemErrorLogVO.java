package com.example.learning.admin.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SystemErrorLogVO {

    private Long id;
    private Long userId;
    private Integer errorCode;
    private String exceptionClass;
    private String errorMessage;
    private String httpMethod;
    private String requestPath;
    private String requestSummary;
    private String ipAddress;
    private String userAgent;
    private LocalDateTime createdAt;
}
