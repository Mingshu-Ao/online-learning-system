package com.example.learning.common.exception;

import com.example.learning.audit.AuditLogService;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.response.ApiResponse;
import jakarta.validation.ConstraintViolationException;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@Slf4j
@RestControllerAdvice
@RequiredArgsConstructor
public class GlobalExceptionHandler {

    private final AuditLogService auditLogService;

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiResponse<Void>> handleBusinessException(BusinessException ex) {
        return buildErrorResponse(ex.getErrorCode(), ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        String message = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining("; "));
        auditLogService.recordException(ex, ErrorCode.BAD_REQUEST, message);
        return buildErrorResponse(ErrorCode.BAD_REQUEST, message);
    }

    @ExceptionHandler(BindException.class)
    public ResponseEntity<ApiResponse<Void>> handleBindException(BindException ex) {
        String message = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining("; "));
        auditLogService.recordException(ex, ErrorCode.BAD_REQUEST, message);
        return buildErrorResponse(ErrorCode.BAD_REQUEST, message);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiResponse<Void>> handleConstraintViolationException(ConstraintViolationException ex) {
        auditLogService.recordException(ex, ErrorCode.BAD_REQUEST, ex.getMessage());
        return buildErrorResponse(ErrorCode.BAD_REQUEST, ex.getMessage());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiResponse<Void>> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
        auditLogService.recordException(ex, ErrorCode.BAD_REQUEST, "request body is invalid");
        return buildErrorResponse(ErrorCode.BAD_REQUEST, "request body is invalid");
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ApiResponse<Void>> handleAuthenticationException(AuthenticationException ex) {
        auditLogService.recordException(ex, ErrorCode.UNAUTHORIZED, ErrorCode.UNAUTHORIZED.getMessage());
        return buildErrorResponse(ErrorCode.UNAUTHORIZED);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Void>> handleAccessDeniedException(AccessDeniedException ex) {
        auditLogService.recordException(ex, ErrorCode.FORBIDDEN, ErrorCode.FORBIDDEN.getMessage());
        return buildErrorResponse(ErrorCode.FORBIDDEN);
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNoResourceFoundException(NoResourceFoundException ex) {
        return buildErrorResponse(ErrorCode.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleException(Exception ex) {
        log.error("unexpected error", ex);
        auditLogService.recordException(ex, ErrorCode.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_SERVER_ERROR.getMessage());
        return buildErrorResponse(ErrorCode.INTERNAL_SERVER_ERROR);
    }

    private ResponseEntity<ApiResponse<Void>> buildErrorResponse(ErrorCode errorCode) {
        return buildErrorResponse(errorCode, errorCode.getMessage());
    }

    private ResponseEntity<ApiResponse<Void>> buildErrorResponse(ErrorCode errorCode, String message) {
        return ResponseEntity.status(resolveHttpStatus(errorCode))
                .body(ApiResponse.failed(errorCode, message));
    }

    private HttpStatus resolveHttpStatus(ErrorCode errorCode) {
        return switch (errorCode) {
            case SUCCESS -> HttpStatus.OK;
            case BAD_REQUEST, PASSWORD_ERROR, USERNAME_ALREADY_EXISTS, EMAIL_ALREADY_EXISTS, PHONE_ALREADY_EXISTS,
                    ROLE_NOT_FOUND, SELF_ROLE_REMOVAL_NOT_ALLOWED, COURSE_STATUS_INVALID, CHAPTER_COURSE_MISMATCH,
                    VIDEO_PROGRESS_INVALID, VIDEO_RESOURCE_REQUIRED, VIDEO_DURATION_INVALID, EXAM_EXPIRED,
                    QUESTION_ANSWER_INVALID, PAPER_QUESTION_INVALID, STUDY_ROOM_NOT_OPEN, STUDY_ROOM_STATE_INVALID,
                    STUDY_ROOM_TIMER_INVALID -> HttpStatus.BAD_REQUEST;
            case UNAUTHORIZED, TOKEN_INVALID -> HttpStatus.UNAUTHORIZED;
            case FORBIDDEN, USER_DISABLED, NO_COURSE_ACCESS_PERMISSION, COURSE_OWNER_REQUIRED, USER_NOT_ENROLLED,
                    COURSE_NOT_PUBLISHED, PAPER_NOT_PUBLISHED, STUDY_ROOM_MESSAGE_FORBIDDEN -> HttpStatus.FORBIDDEN;
            case NOT_FOUND, USER_NOT_FOUND, COURSE_NOT_FOUND, CHAPTER_NOT_FOUND, RESOURCE_NOT_FOUND,
                    QUESTION_NOT_FOUND, PAPER_NOT_FOUND, EXAM_RECORD_NOT_FOUND, WRONG_QUESTION_NOT_FOUND,
                    STUDY_ROOM_NOT_FOUND -> HttpStatus.NOT_FOUND;
            case CONFLICT, EXAM_ALREADY_SUBMITTED, PAPER_ATTEMPT_LIMIT_REACHED, STUDY_ROOM_FULL,
                    STUDY_ROOM_ALREADY_IN_OTHER_ROOM -> HttpStatus.CONFLICT;
            case AI_SERVICE_UNAVAILABLE, AI_RESPONSE_TIMEOUT, INTERNAL_SERVER_ERROR -> HttpStatus.INTERNAL_SERVER_ERROR;
        };
    }
}
