package com.example.learning.course.service;

import com.example.learning.course.dto.LearningStatsQueryDTO;
import com.example.learning.course.dto.VideoProgressReportDTO;
import com.example.learning.course.vo.CourseLearningProgressVO;
import com.example.learning.course.vo.LearningStatsVO;
import com.example.learning.course.vo.VideoProgressReportVO;

public interface LearningProgressService {

    VideoProgressReportVO reportVideoProgress(Long studentId, VideoProgressReportDTO reportDTO);

    CourseLearningProgressVO getCourseProgress(Long studentId, Long courseId);

    LearningStatsVO getLearningStats(Long studentId, LearningStatsQueryDTO queryDTO);
}
