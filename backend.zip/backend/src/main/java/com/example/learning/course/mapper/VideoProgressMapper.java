package com.example.learning.course.mapper;

import com.example.learning.course.entity.VideoProgressEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoProgressMapper extends JpaRepository<VideoProgressEntity, Long> {

    Optional<VideoProgressEntity> findByUserIdAndResourceIdAndDeletedFalse(Long userId, Long resourceId);

    List<VideoProgressEntity> findAllByUserIdAndCourseIdAndDeletedFalse(Long userId, Long courseId);

    List<VideoProgressEntity> findAllByUserIdAndResourceIdInAndDeletedFalse(Long userId, Collection<Long> resourceIds);
}
