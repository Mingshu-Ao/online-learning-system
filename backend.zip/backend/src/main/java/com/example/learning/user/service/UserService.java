package com.example.learning.user.service;

import com.example.learning.user.vo.UserProfileVO;

public interface UserService {

    UserProfileVO getCurrentUserProfile(Long currentUserId);
}
