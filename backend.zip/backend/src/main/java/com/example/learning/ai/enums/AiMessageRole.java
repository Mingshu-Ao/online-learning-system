package com.example.learning.ai.enums;

public enum AiMessageRole {
    USER,
    ASSISTANT
}
