package com.example.learning.studyroom.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.studyroom.enums.RoomRecordStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "room_record", uniqueConstraints = {
        @UniqueConstraint(name = "uk_room_record_session", columnNames = "session_token")
})
@EqualsAndHashCode(callSuper = true)
public class RoomRecordEntity extends BaseEntity {

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "seat_no", nullable = false)
    private Integer seatNo;

    @Column(name = "focus_minutes", nullable = false)
    private Integer focusMinutes;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "session_token", nullable = false, length = 64)
    private String sessionToken;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private RoomRecordStatus status;
}
