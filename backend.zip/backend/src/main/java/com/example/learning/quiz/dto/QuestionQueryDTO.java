package com.example.learning.quiz.dto;

import com.example.learning.quiz.enums.QuestionType;
import lombok.Data;

@Data
public class QuestionQueryDTO {

    private Long courseId;

    private Long chapterId;

    private QuestionType questionType;

    private String keyword;
}
