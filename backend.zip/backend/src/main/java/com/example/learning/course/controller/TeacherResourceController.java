package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.course.dto.ResourceUploadDTO;
import com.example.learning.course.service.TeacherCourseService;
import com.example.learning.course.vo.CourseResourceVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher/resources")
public class TeacherResourceController {

    private final TeacherCourseService teacherCourseService;

    @PostMapping("/upload")
    @PreAuthorize("hasAuthority('resource:upload')")
    public ApiResponse<CourseResourceVO> uploadMetadata(@Valid @RequestBody ResourceUploadDTO uploadDTO) {
        return ApiResponse.success(teacherCourseService.saveResourceMetadata(SecurityUtils.getCurrentUserId(), uploadDTO));
    }
}
