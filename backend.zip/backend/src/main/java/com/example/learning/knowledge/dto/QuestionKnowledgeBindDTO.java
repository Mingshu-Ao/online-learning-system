package com.example.learning.knowledge.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class QuestionKnowledgeBindDTO {

    @NotNull
    private Long knowledgePointId;
}
