package com.example.learning.course.storage;

public interface FileStorageService {

    StoredFileInfo prepareStorage(String originalFileName);
}
