package com.example.learning.quiz.enums;

public enum QuestionType {
    SINGLE_CHOICE,
    MULTIPLE_CHOICE,
    TRUE_FALSE,
    FILL_BLANK,
    SHORT_ANSWER;

    public boolean isObjective() {
        return this != SHORT_ANSWER;
    }

    public boolean isSubjective() {
        return this == SHORT_ANSWER;
    }

    public boolean requiresOptions() {
        return this == SINGLE_CHOICE || this == MULTIPLE_CHOICE;
    }
}
