package com.example.learning.common.enums;

import lombok.Getter;

@Getter
public enum ErrorCode {

    SUCCESS(0, "success"),
    BAD_REQUEST(40000, "bad request"),
    UNAUTHORIZED(40100, "unauthorized"),
    FORBIDDEN(40300, "forbidden"),
    NOT_FOUND(40400, "not found"),
    CONFLICT(40900, "conflict"),
    INTERNAL_SERVER_ERROR(50000, "internal server error"),

    USER_NOT_FOUND(10001, "user not found"),
    PASSWORD_ERROR(10002, "password error"),
    USER_DISABLED(10003, "user disabled"),
    USERNAME_ALREADY_EXISTS(10004, "username already exists"),
    EMAIL_ALREADY_EXISTS(10005, "email already exists"),
    PHONE_ALREADY_EXISTS(10006, "phone already exists"),
    ROLE_NOT_FOUND(10007, "role not found"),
    TOKEN_INVALID(10008, "token invalid"),
    SELF_ROLE_REMOVAL_NOT_ALLOWED(10009, "admin cannot remove own admin role"),

    COURSE_NOT_FOUND(20001, "course not found"),
    COURSE_NOT_PUBLISHED(20002, "course not published"),
    NO_COURSE_ACCESS_PERMISSION(20003, "no course access permission"),
    COURSE_OWNER_REQUIRED(20004, "course owner required"),
    COURSE_STATUS_INVALID(20005, "course status invalid"),
    CHAPTER_NOT_FOUND(20006, "chapter not found"),
    RESOURCE_NOT_FOUND(20007, "resource not found"),
    USER_NOT_ENROLLED(20008, "user not enrolled"),
    CHAPTER_COURSE_MISMATCH(20009, "chapter course mismatch"),
    VIDEO_PROGRESS_INVALID(20010, "video progress invalid"),
    VIDEO_RESOURCE_REQUIRED(20011, "video resource required"),
    VIDEO_DURATION_INVALID(20012, "video duration invalid"),

    QUESTION_NOT_FOUND(30001, "question not found"),
    PAPER_NOT_FOUND(30002, "paper not found"),
    PAPER_NOT_PUBLISHED(30003, "paper not published"),
    EXAM_RECORD_NOT_FOUND(30004, "exam record not found"),
    EXAM_EXPIRED(30005, "exam expired"),
    EXAM_ALREADY_SUBMITTED(30006, "exam already submitted"),
    QUESTION_ANSWER_INVALID(30007, "question answer invalid"),
    WRONG_QUESTION_NOT_FOUND(30008, "wrong question not found"),
    PAPER_ATTEMPT_LIMIT_REACHED(30009, "paper attempt limit reached"),
    PAPER_QUESTION_INVALID(30010, "paper question invalid"),

    STUDY_ROOM_NOT_FOUND(40001, "study room not found"),
    STUDY_ROOM_NOT_OPEN(40002, "study room not open"),
    STUDY_ROOM_FULL(40003, "study room full"),
    STUDY_ROOM_ALREADY_IN_OTHER_ROOM(40004, "study room already in other room"),
    STUDY_ROOM_STATE_INVALID(40005, "study room state invalid"),
    STUDY_ROOM_TIMER_INVALID(40006, "study room timer invalid"),
    STUDY_ROOM_MESSAGE_FORBIDDEN(40007, "study room message forbidden"),

    AI_SERVICE_UNAVAILABLE(50001, "ai service unavailable"),
    AI_RESPONSE_TIMEOUT(50002, "ai response timeout");

    private final int code;
    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
