package com.example.learning.quiz.service;

import com.example.learning.quiz.dto.PaperCreateDTO;
import com.example.learning.quiz.dto.QuestionQueryDTO;
import com.example.learning.quiz.dto.QuestionUpsertDTO;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.QuestionVO;
import java.util.List;

public interface TeacherQuizService {

    QuestionVO createQuestion(Long teacherId, QuestionUpsertDTO upsertDTO);

    QuestionVO updateQuestion(Long teacherId, Long questionId, QuestionUpsertDTO upsertDTO);

    List<QuestionVO> listQuestions(Long teacherId, QuestionQueryDTO queryDTO);

    PaperDetailVO createPaper(Long teacherId, PaperCreateDTO createDTO);
}
