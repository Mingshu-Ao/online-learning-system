package com.example.learning.quiz.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.quiz.dto.PaperCreateDTO;
import com.example.learning.quiz.dto.PaperQuestionCreateDTO;
import com.example.learning.quiz.dto.QuestionOptionDTO;
import com.example.learning.quiz.dto.QuestionQueryDTO;
import com.example.learning.quiz.dto.QuestionUpsertDTO;
import com.example.learning.quiz.entity.PaperEntity;
import com.example.learning.quiz.entity.PaperQuestionEntity;
import com.example.learning.quiz.entity.QuestionEntity;
import com.example.learning.quiz.entity.QuestionOptionEntity;
import com.example.learning.quiz.enums.QuestionType;
import com.example.learning.quiz.mapper.PaperMapper;
import com.example.learning.quiz.mapper.PaperQuestionMapper;
import com.example.learning.quiz.mapper.QuestionMapper;
import com.example.learning.quiz.mapper.QuestionOptionMapper;
import com.example.learning.quiz.service.TeacherQuizService;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.PaperQuestionVO;
import com.example.learning.quiz.vo.QuestionOptionVO;
import com.example.learning.quiz.vo.QuestionVO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.BooleanNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.TextNode;
import jakarta.persistence.criteria.Predicate;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class TeacherQuizServiceImpl implements TeacherQuizService {

    private final QuestionMapper questionMapper;
    private final QuestionOptionMapper questionOptionMapper;
    private final PaperMapper paperMapper;
    private final PaperQuestionMapper paperQuestionMapper;
    private final CourseMapper courseMapper;
    private final CourseChapterMapper courseChapterMapper;
    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public QuestionVO createQuestion(Long teacherId, QuestionUpsertDTO upsertDTO) {
        CourseEntity course = getOwnedCourse(teacherId, upsertDTO.getCourseId());
        validateChapter(upsertDTO.getChapterId(), course.getId());
        NormalizedQuestion normalized = normalizeQuestion(upsertDTO);

        QuestionEntity question = new QuestionEntity();
        applyQuestion(question, teacherId, upsertDTO, normalized);
        QuestionEntity savedQuestion = questionMapper.save(question);
        List<QuestionOptionEntity> savedOptions = replaceOptions(savedQuestion.getId(), normalized.options());
        return toQuestionVO(savedQuestion, savedOptions);
    }

    @Override
    @Transactional
    public QuestionVO updateQuestion(Long teacherId, Long questionId, QuestionUpsertDTO upsertDTO) {
        QuestionEntity question = questionMapper.findByIdAndDeletedFalse(questionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.QUESTION_NOT_FOUND));
        if (!Objects.equals(question.getTeacherId(), teacherId)) {
            throw new BusinessException(ErrorCode.COURSE_OWNER_REQUIRED);
        }
        CourseEntity course = getOwnedCourse(teacherId, upsertDTO.getCourseId());
        validateChapter(upsertDTO.getChapterId(), course.getId());
        NormalizedQuestion normalized = normalizeQuestion(upsertDTO);

        applyQuestion(question, teacherId, upsertDTO, normalized);
        QuestionEntity savedQuestion = questionMapper.save(question);
        List<QuestionOptionEntity> savedOptions = replaceOptions(savedQuestion.getId(), normalized.options());
        return toQuestionVO(savedQuestion, savedOptions);
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuestionVO> listQuestions(Long teacherId, QuestionQueryDTO queryDTO) {
        List<QuestionEntity> questions = questionMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            predicates.add(cb.equal(root.get("teacherId"), teacherId));
            if (queryDTO != null && queryDTO.getCourseId() != null) {
                predicates.add(cb.equal(root.get("courseId"), queryDTO.getCourseId()));
            }
            if (queryDTO != null && queryDTO.getChapterId() != null) {
                predicates.add(cb.equal(root.get("chapterId"), queryDTO.getChapterId()));
            }
            if (queryDTO != null && queryDTO.getQuestionType() != null) {
                predicates.add(cb.equal(root.get("questionType"), queryDTO.getQuestionType()));
            }
            if (queryDTO != null && queryDTO.getKeyword() != null && !queryDTO.getKeyword().trim().isEmpty()) {
                predicates.add(cb.like(root.get("stem"), "%" + queryDTO.getKeyword().trim() + "%"));
            }
            query.orderBy(cb.desc(root.get("updatedAt")), cb.desc(root.get("id")));
            return cb.and(predicates.toArray(Predicate[]::new));
        });
        if (questions.isEmpty()) {
            return List.of();
        }

        List<Long> questionIds = questions.stream().map(QuestionEntity::getId).toList();
        Map<Long, List<QuestionOptionEntity>> optionMap = questionOptionMapper
                .findAllByQuestionIdInAndDeletedFalseOrderByQuestionIdAscSortOrderAsc(questionIds)
                .stream()
                .collect(Collectors.groupingBy(QuestionOptionEntity::getQuestionId, LinkedHashMap::new, Collectors.toList()));

        return questions.stream()
                .map(question -> toQuestionVO(question, optionMap.getOrDefault(question.getId(), List.of())))
                .toList();
    }

    @Override
    @Transactional
    public PaperDetailVO createPaper(Long teacherId, PaperCreateDTO createDTO) {
        CourseEntity course = getOwnedCourse(teacherId, createDTO.getCourseId());
        validatePaperTime(createDTO.getStartTime(), createDTO.getEndTime());

        List<PaperQuestionCreateDTO> requestedQuestions = createDTO.getQuestions();
        Set<Long> questionIds = requestedQuestions.stream().map(PaperQuestionCreateDTO::getQuestionId).collect(Collectors.toCollection(LinkedHashSet::new));
        if (questionIds.size() != requestedQuestions.size()) {
            throw new BusinessException(ErrorCode.PAPER_QUESTION_INVALID, "paper question cannot be duplicated");
        }

        List<QuestionEntity> questions = questionMapper.findAllByIdInAndDeletedFalse(List.copyOf(questionIds));
        if (questions.size() != questionIds.size()) {
            throw new BusinessException(ErrorCode.QUESTION_NOT_FOUND, "one or more questions do not exist");
        }
        Map<Long, QuestionEntity> questionMap = questions.stream().collect(Collectors.toMap(QuestionEntity::getId, item -> item));
        for (QuestionEntity question : questions) {
            if (!Objects.equals(question.getCourseId(), course.getId())) {
                throw new BusinessException(ErrorCode.PAPER_QUESTION_INVALID, "paper questions must belong to the same course");
            }
        }

        Map<Long, List<QuestionOptionEntity>> optionMap = questionOptionMapper
                .findAllByQuestionIdInAndDeletedFalseOrderByQuestionIdAscSortOrderAsc(List.copyOf(questionIds))
                .stream()
                .collect(Collectors.groupingBy(QuestionOptionEntity::getQuestionId, LinkedHashMap::new, Collectors.toList()));

        BigDecimal totalScore = requestedQuestions.stream()
                .map(PaperQuestionCreateDTO::getScore)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (createDTO.getPassScore().compareTo(totalScore) > 0) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "passScore cannot exceed totalScore");
        }

        PaperEntity paper = new PaperEntity();
        paper.setTitle(createDTO.getTitle().trim());
        paper.setCourseId(course.getId());
        paper.setTeacherId(teacherId);
        paper.setTotalScore(totalScore);
        paper.setPassScore(createDTO.getPassScore());
        paper.setDurationMinutes(createDTO.getDurationMinutes());
        paper.setAllowRedo(createDTO.getAllowRedo());
        paper.setMaxAttempts(resolveMaxAttempts(createDTO.getAllowRedo(), createDTO.getMaxAttempts()));
        paper.setStartTime(createDTO.getStartTime());
        paper.setEndTime(createDTO.getEndTime());
        paper.setPublished(createDTO.getPublished() == null ? Boolean.TRUE : createDTO.getPublished());
        PaperEntity savedPaper = paperMapper.save(paper);

        List<PaperQuestionEntity> paperQuestions = new ArrayList<>();
        for (int i = 0; i < requestedQuestions.size(); i++) {
            PaperQuestionCreateDTO requested = requestedQuestions.get(i);
            QuestionEntity question = questionMap.get(requested.getQuestionId());
            PaperQuestionEntity paperQuestion = new PaperQuestionEntity();
            paperQuestion.setPaperId(savedPaper.getId());
            paperQuestion.setQuestionId(question.getId());
            paperQuestion.setChapterId(question.getChapterId());
            paperQuestion.setSortOrder(i + 1);
            paperQuestion.setScore(requested.getScore());
            paperQuestion.setQuestionStem(question.getStem());
            paperQuestion.setQuestionType(question.getQuestionType());
            paperQuestion.setOptionSnapshot(writeJson(toOptionVOs(optionMap.getOrDefault(question.getId(), List.of()))));
            paperQuestion.setStandardAnswer(question.getStandardAnswer());
            paperQuestion.setAnalysis(question.getAnalysis());
            paperQuestion.setDifficulty(question.getDifficulty());
            paperQuestion.setKnowledgePoint(question.getKnowledgePoint());
            paperQuestion.setPartialCreditEnabled(Boolean.TRUE.equals(question.getPartialCreditEnabled()));
            paperQuestions.add(paperQuestion);
        }
        List<PaperQuestionEntity> savedPaperQuestions = paperQuestionMapper.saveAll(paperQuestions);
        return toPaperDetailVO(savedPaper, savedPaperQuestions);
    }

    private void applyQuestion(QuestionEntity question,
                               Long teacherId,
                               QuestionUpsertDTO upsertDTO,
                               NormalizedQuestion normalized) {
        question.setCourseId(upsertDTO.getCourseId());
        question.setChapterId(upsertDTO.getChapterId());
        question.setTeacherId(teacherId);
        question.setStem(upsertDTO.getStem().trim());
        question.setQuestionType(upsertDTO.getQuestionType());
        question.setStandardAnswer(writeJson(normalized.standardAnswer()));
        question.setAnalysis(blankToNull(upsertDTO.getAnalysis()));
        question.setDifficulty(blankToNull(upsertDTO.getDifficulty()));
        question.setKnowledgePoint(blankToNull(upsertDTO.getKnowledgePoint()));
        question.setPartialCreditEnabled(Boolean.TRUE.equals(normalized.partialCreditEnabled()));
    }

    private NormalizedQuestion normalizeQuestion(QuestionUpsertDTO upsertDTO) {
        QuestionType questionType = upsertDTO.getQuestionType();
        List<QuestionOptionDTO> options = upsertDTO.getOptions() == null ? List.of() : upsertDTO.getOptions();
        validateOptionKeys(options);

        Set<String> optionKeys = options.stream()
                .map(QuestionOptionDTO::getOptionKey)
                .map(String::trim)
                .collect(Collectors.toCollection(LinkedHashSet::new));
        if (questionType.requiresOptions() && optionKeys.size() < 2) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "choice questions require at least two options");
        }

        boolean partialCreditEnabled = questionType == QuestionType.MULTIPLE_CHOICE && Boolean.TRUE.equals(upsertDTO.getPartialCreditEnabled());
        JsonNode normalizedAnswer = normalizeAnswerNode(questionType, upsertDTO.getStandardAnswer(), optionKeys);
        return new NormalizedQuestion(normalizedAnswer, options, partialCreditEnabled);
    }

    private JsonNode normalizeAnswerNode(QuestionType questionType, JsonNode standardAnswer, Set<String> optionKeys) {
        return switch (questionType) {
            case SINGLE_CHOICE -> {
                String answer = normalizeTextValue(standardAnswer);
                ensureOptionMatch(answer, optionKeys);
                yield TextNode.valueOf(answer);
            }
            case MULTIPLE_CHOICE -> {
                if (!standardAnswer.isArray() || standardAnswer.isEmpty()) {
                    throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "multiple choice answer must be a non-empty array");
                }
                Set<String> answers = new LinkedHashSet<>();
                standardAnswer.forEach(item -> {
                    String value = normalizeTextValue(item);
                    ensureOptionMatch(value, optionKeys);
                    answers.add(value);
                });
                ArrayNode normalized = JsonNodeFactory.instance.arrayNode();
                answers.stream().sorted().forEach(normalized::add);
                yield normalized;
            }
            case TRUE_FALSE -> BooleanNode.valueOf(normalizeBooleanValue(standardAnswer));
            case FILL_BLANK -> normalizeBlankAnswer(standardAnswer);
            case SHORT_ANSWER -> normalizeShortAnswer(standardAnswer);
        };
    }

    private ArrayNode normalizeBlankAnswer(JsonNode standardAnswer) {
        ArrayNode normalized = JsonNodeFactory.instance.arrayNode();
        if (standardAnswer.isArray()) {
            if (standardAnswer.isEmpty()) {
                throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "fill blank answer cannot be empty");
            }
            standardAnswer.forEach(item -> normalized.add(normalizeBlankText(item)));
        } else {
            normalized.add(normalizeBlankText(standardAnswer));
        }
        return normalized;
    }

    private JsonNode normalizeShortAnswer(JsonNode standardAnswer) {
        if (standardAnswer.isArray()) {
            ArrayNode normalized = JsonNodeFactory.instance.arrayNode();
            standardAnswer.forEach(item -> normalized.add(normalizeTextValue(item)));
            return normalized;
        }
        return TextNode.valueOf(normalizeTextValue(standardAnswer));
    }

    private void validateOptionKeys(List<QuestionOptionDTO> options) {
        Map<String, Long> duplicated = options.stream()
                .collect(Collectors.groupingBy(item -> item.getOptionKey().trim(), LinkedHashMap::new, Collectors.counting()));
        boolean hasDuplicate = duplicated.values().stream().anyMatch(count -> count > 1);
        if (hasDuplicate) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "option keys cannot be duplicated");
        }
    }

    private void ensureOptionMatch(String answer, Set<String> optionKeys) {
        if (!optionKeys.contains(answer)) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "standard answer must match option keys");
        }
    }

    private boolean normalizeBooleanValue(JsonNode node) {
        if (node.isBoolean()) {
            return node.asBoolean();
        }
        if (node.isTextual()) {
            String text = node.asText().trim().toLowerCase(Locale.ROOT);
            if ("true".equals(text) || "t".equals(text) || "1".equals(text) || "yes".equals(text)) {
                return true;
            }
            if ("false".equals(text) || "f".equals(text) || "0".equals(text) || "no".equals(text)) {
                return false;
            }
        }
        throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "true/false answer must be boolean-like");
    }

    private String normalizeBlankText(JsonNode node) {
        String text = normalizeTextValue(node);
        if (text.isEmpty()) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "blank answer cannot be empty");
        }
        return text;
    }

    private String normalizeTextValue(JsonNode node) {
        if (node == null || node.isNull() || (!node.isTextual() && !node.isNumber() && !node.isBoolean())) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "answer format is invalid");
        }
        String value = node.asText().trim();
        if (value.isEmpty()) {
            throw new BusinessException(ErrorCode.QUESTION_ANSWER_INVALID, "answer content cannot be blank");
        }
        return value;
    }

    private List<QuestionOptionEntity> replaceOptions(Long questionId, List<QuestionOptionDTO> options) {
        List<QuestionOptionEntity> existing = questionOptionMapper.findAllByQuestionIdAndDeletedFalseOrderBySortOrderAsc(questionId);
        if (!existing.isEmpty()) {
            existing.forEach(item -> item.setDeleted(Boolean.TRUE));
            questionOptionMapper.saveAll(existing);
        }
        if (options.isEmpty()) {
            return List.of();
        }
        List<QuestionOptionEntity> entities = new ArrayList<>();
        for (int i = 0; i < options.size(); i++) {
            QuestionOptionDTO option = options.get(i);
            QuestionOptionEntity entity = new QuestionOptionEntity();
            entity.setQuestionId(questionId);
            entity.setOptionKey(option.getOptionKey().trim());
            entity.setOptionContent(option.getContent().trim());
            entity.setSortOrder(i + 1);
            entities.add(entity);
        }
        return questionOptionMapper.saveAll(entities);
    }

    private CourseEntity getOwnedCourse(Long teacherId, Long courseId) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (!Objects.equals(course.getTeacherId(), teacherId)) {
            throw new BusinessException(ErrorCode.COURSE_OWNER_REQUIRED);
        }
        return course;
    }

    private void validateChapter(Long chapterId, Long courseId) {
        if (chapterId == null) {
            return;
        }
        CourseChapterEntity chapter = courseChapterMapper.findByIdAndDeletedFalse(chapterId)
                .orElseThrow(() -> new BusinessException(ErrorCode.CHAPTER_NOT_FOUND));
        if (!Objects.equals(chapter.getCourseId(), courseId)) {
            throw new BusinessException(ErrorCode.CHAPTER_COURSE_MISMATCH);
        }
    }

    private void validatePaperTime(LocalDateTime startTime, LocalDateTime endTime) {
        if (!endTime.isAfter(startTime)) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "endTime must be after startTime");
        }
    }

    private int resolveMaxAttempts(Boolean allowRedo, Integer maxAttempts) {
        if (!Boolean.TRUE.equals(allowRedo)) {
            return 1;
        }
        return maxAttempts == null ? 2 : maxAttempts;
    }

    private QuestionVO toQuestionVO(QuestionEntity question, List<QuestionOptionEntity> optionEntities) {
        return QuestionVO.builder()
                .id(question.getId())
                .courseId(question.getCourseId())
                .chapterId(question.getChapterId())
                .stem(question.getStem())
                .questionType(question.getQuestionType().name())
                .standardAnswer(readJson(question.getStandardAnswer()))
                .analysis(question.getAnalysis())
                .difficulty(question.getDifficulty())
                .knowledgePoint(question.getKnowledgePoint())
                .partialCreditEnabled(question.getPartialCreditEnabled())
                .options(toOptionVOs(optionEntities))
                .build();
    }

    private PaperDetailVO toPaperDetailVO(PaperEntity paper, Collection<PaperQuestionEntity> paperQuestions) {
        List<PaperQuestionVO> questions = paperQuestions.stream()
                .sorted(Comparator.comparing(PaperQuestionEntity::getSortOrder))
                .map(item -> PaperQuestionVO.builder()
                        .questionId(item.getQuestionId())
                        .stem(item.getQuestionStem())
                        .questionType(item.getQuestionType().name())
                        .score(item.getScore())
                        .partialCreditEnabled(item.getPartialCreditEnabled())
                        .options(readOptionVOs(item.getOptionSnapshot()))
                        .build())
                .toList();
        return PaperDetailVO.builder()
                .id(paper.getId())
                .title(paper.getTitle())
                .courseId(paper.getCourseId())
                .totalScore(paper.getTotalScore())
                .passScore(paper.getPassScore())
                .durationMinutes(paper.getDurationMinutes())
                .allowRedo(paper.getAllowRedo())
                .maxAttempts(paper.getMaxAttempts())
                .startTime(paper.getStartTime())
                .endTime(paper.getEndTime())
                .published(paper.getPublished())
                .questions(questions)
                .build();
    }

    private List<QuestionOptionVO> toOptionVOs(List<QuestionOptionEntity> optionEntities) {
        return optionEntities.stream()
                .map(item -> QuestionOptionVO.builder()
                        .optionKey(item.getOptionKey())
                        .content(item.getOptionContent())
                        .build())
                .toList();
    }

    private List<QuestionOptionVO> readOptionVOs(String json) {
        try {
            if (json == null || json.isBlank()) {
                return List.of();
            }
            QuestionOptionVO[] options = objectMapper.readValue(json, QuestionOptionVO[].class);
            return List.of(options);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "paper option snapshot is invalid");
        }
    }

    private JsonNode readJson(String json) {
        try {
            return objectMapper.readTree(json);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "stored json payload is invalid");
        }
    }

    private String writeJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "json serialization failed");
        }
    }

    private String blankToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private record NormalizedQuestion(JsonNode standardAnswer,
                                      List<QuestionOptionDTO> options,
                                      Boolean partialCreditEnabled) {
    }
}
