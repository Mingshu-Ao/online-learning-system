package com.example.learning.ai.service;

import com.example.learning.ai.dto.AiAskRequestDTO;
import com.example.learning.ai.vo.AiAssistantResponseVO;
import com.example.learning.ai.vo.AiConversationDetailVO;
import com.example.learning.ai.vo.AiConversationSummaryVO;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface AiAssistantService {

    AiAssistantResponseVO askQuestion(Long userId, AiAskRequestDTO requestDTO);

    AiAssistantResponseVO solveImage(Long userId, Long courseId, MultipartFile image);

    List<AiConversationSummaryVO> listConversations(Long userId);

    AiConversationDetailVO getConversation(Long userId, Long conversationId);
}
