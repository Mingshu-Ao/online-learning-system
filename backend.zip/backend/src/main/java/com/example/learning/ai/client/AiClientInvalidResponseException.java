package com.example.learning.ai.client;

public class AiClientInvalidResponseException extends AiClientException {

    public AiClientInvalidResponseException(String message) {
        super(message);
    }

    public AiClientInvalidResponseException(String message, Throwable cause) {
        super(message, cause);
    }
}
