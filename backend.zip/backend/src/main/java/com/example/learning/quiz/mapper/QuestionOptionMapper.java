package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.QuestionOptionEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuestionOptionMapper extends JpaRepository<QuestionOptionEntity, Long> {

    List<QuestionOptionEntity> findAllByQuestionIdAndDeletedFalseOrderBySortOrderAsc(Long questionId);

    List<QuestionOptionEntity> findAllByQuestionIdInAndDeletedFalseOrderByQuestionIdAscSortOrderAsc(List<Long> questionIds);
}
