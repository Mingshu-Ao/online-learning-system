package com.example.learning.user.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.audit.AdminOperationAudit;
import com.example.learning.common.vo.PageResultVO;
import com.example.learning.security.SecurityUtils;
import com.example.learning.user.dto.AssignRolesDTO;
import com.example.learning.user.dto.ResetPasswordDTO;
import com.example.learning.user.dto.UpdateUserStatusDTO;
import com.example.learning.user.dto.UserQueryDTO;
import com.example.learning.user.service.AdminUserService;
import com.example.learning.user.vo.UserListItemVO;
import com.example.learning.user.vo.UserProfileVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/users")
public class AdminUserController {

    private final AdminUserService adminUserService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('user:read')")
    public ApiResponse<PageResultVO<UserListItemVO>> listUsers(@Valid UserQueryDTO queryDTO) {
        return ApiResponse.success(adminUserService.listUsers(queryDTO));
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('user:disable')")
    @AdminOperationAudit(action = "USER_STATUS_UPDATE", targetType = "USER", targetId = "#id", summary = "#updateUserStatusDTO.status")
    public ApiResponse<Void> updateUserStatus(@PathVariable Long id,
                                              @Valid @RequestBody UpdateUserStatusDTO updateUserStatusDTO) {
        adminUserService.updateUserStatus(id, updateUserStatusDTO);
        return ApiResponse.success(null);
    }

    @PutMapping("/{id}/reset-password")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('user:reset-password')")
    @AdminOperationAudit(action = "USER_PASSWORD_RESET", targetType = "USER", targetId = "#id", summary = "'password reset'")
    public ApiResponse<Void> resetPassword(@PathVariable Long id,
                                           @Valid @RequestBody ResetPasswordDTO resetPasswordDTO) {
        adminUserService.resetPassword(id, resetPasswordDTO);
        return ApiResponse.success(null);
    }

    @PutMapping("/{id}/roles")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('user:assign-role')")
    @AdminOperationAudit(action = "USER_ROLE_ASSIGN", targetType = "USER", targetId = "#id", summary = "#assignRolesDTO.roleIds")
    public ApiResponse<UserProfileVO> assignRoles(@PathVariable Long id,
                                                  @Valid @RequestBody AssignRolesDTO assignRolesDTO) {
        return ApiResponse.success(adminUserService.assignRoles(SecurityUtils.getCurrentUserId(), id, assignRolesDTO));
    }
}
