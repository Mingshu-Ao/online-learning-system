package com.example.learning.knowledge.vo;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class KnowledgeResourceBindingVO {
    String resourceType;
    Long resourceId;
    String resourceTitle;
}
