package com.example.learning.course.vo;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseDetailVO {

    private Long id;
    private String title;
    private String summary;
    private String coverUrl;
    private String category;
    private String difficulty;
    private Long teacherId;
    private String teacherName;
    private Long studentCount;
    private String status;
    private String reviewComment;
    private List<CourseChapterVO> chapters;
}
