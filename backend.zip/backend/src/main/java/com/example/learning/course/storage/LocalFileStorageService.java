package com.example.learning.course.storage;

import java.time.LocalDate;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class LocalFileStorageService implements FileStorageService {

    @Override
    public StoredFileInfo prepareStorage(String originalFileName) {
        String sanitizedName = StringUtils.hasText(originalFileName) ? originalFileName.trim().replace(" ", "-") : "resource.bin";
        String storagePath = "resources/" + LocalDate.now() + "/" + UUID.randomUUID() + "-" + sanitizedName;
        return new StoredFileInfo(storagePath, "/local-storage/" + storagePath);
    }
}
