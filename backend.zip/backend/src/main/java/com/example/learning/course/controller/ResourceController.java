package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.course.service.ResourceAccessService;
import com.example.learning.course.vo.ResourceAccessVO;
import com.example.learning.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/resources")
public class ResourceController {

    private final ResourceAccessService resourceAccessService;

    @GetMapping("/{resourceId}/access-url")
    public ApiResponse<ResourceAccessVO> getAccessUrl(@PathVariable Long resourceId) {
        return ApiResponse.success(resourceAccessService.getResourceAccessUrl(SecurityUtils.getCurrentUserId(), resourceId));
    }
}
