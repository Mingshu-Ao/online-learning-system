package com.example.learning.quiz.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.quiz.dto.StudentExamSubmitDTO;
import com.example.learning.quiz.dto.WrongQuestionQueryDTO;
import com.example.learning.quiz.service.StudentExamService;
import com.example.learning.quiz.vo.ExamResultVO;
import com.example.learning.quiz.vo.ExamStartVO;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.WrongQuestionVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student")
public class StudentExamController {

    private final StudentExamService studentExamService;

    @GetMapping("/papers/{paperId}")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<PaperDetailVO> getPaper(@PathVariable Long paperId) {
        return ApiResponse.success(studentExamService.getPaper(SecurityUtils.getCurrentUserId(), paperId));
    }

    @PostMapping("/exams/{paperId}/start")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<ExamStartVO> startExam(@PathVariable Long paperId) {
        return ApiResponse.success(studentExamService.startExam(SecurityUtils.getCurrentUserId(), paperId));
    }

    @PostMapping("/exams/{examRecordId}/submit")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<ExamResultVO> submitExam(@PathVariable Long examRecordId,
                                                @Valid @RequestBody StudentExamSubmitDTO submitDTO) {
        return ApiResponse.success(studentExamService.submitExam(SecurityUtils.getCurrentUserId(), examRecordId, submitDTO));
    }

    @GetMapping("/exams/{examRecordId}/result")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<ExamResultVO> getExamResult(@PathVariable Long examRecordId) {
        return ApiResponse.success(studentExamService.getExamResult(SecurityUtils.getCurrentUserId(), examRecordId));
    }

    @GetMapping("/wrong-questions")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<List<WrongQuestionVO>> listWrongQuestions(@Valid WrongQuestionQueryDTO queryDTO) {
        return ApiResponse.success(studentExamService.listWrongQuestions(SecurityUtils.getCurrentUserId(), queryDTO));
    }

    @PostMapping("/wrong-questions/{id}/redo")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<WrongQuestionVO> redoWrongQuestion(@PathVariable Long id) {
        return ApiResponse.success(studentExamService.redoWrongQuestion(SecurityUtils.getCurrentUserId(), id));
    }

    @PutMapping("/wrong-questions/{id}/mastered")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<WrongQuestionVO> markWrongQuestionMastered(@PathVariable Long id) {
        return ApiResponse.success(studentExamService.markWrongQuestionMastered(SecurityUtils.getCurrentUserId(), id));
    }
}
