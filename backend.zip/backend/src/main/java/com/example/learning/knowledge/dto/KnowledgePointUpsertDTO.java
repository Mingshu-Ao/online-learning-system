package com.example.learning.knowledge.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class KnowledgePointUpsertDTO {

    @NotBlank
    private String name;

    private String description;
}
