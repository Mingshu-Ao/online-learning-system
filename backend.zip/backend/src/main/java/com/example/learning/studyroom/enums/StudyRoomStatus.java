package com.example.learning.studyroom.enums;

public enum StudyRoomStatus {
    OPEN,
    CLOSED
}
