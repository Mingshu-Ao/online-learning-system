package com.example.learning.user.mapper;

import com.example.learning.user.entity.PermissionEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionMapper extends JpaRepository<PermissionEntity, Long> {

    Optional<PermissionEntity> findByCodeAndDeletedFalse(String code);

    List<PermissionEntity> findAllByIdInAndDeletedFalse(Collection<Long> ids);
}
