package com.example.learning.ai.client;

public class AiClientTimeoutException extends AiClientException {

    public AiClientTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}
