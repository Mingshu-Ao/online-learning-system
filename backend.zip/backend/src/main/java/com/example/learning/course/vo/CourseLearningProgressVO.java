package com.example.learning.course.vo;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseLearningProgressVO {

    private Long courseId;
    private Long totalVideoCount;
    private Long completedVideoCount;
    private Long totalDurationSeconds;
    private Long totalEffectiveStudySeconds;
    private Double completionPercent;
    private Boolean completed;
    private Long resumeResourceId;
    private Long resumeChapterId;
    private Long resumePosition;
    private LocalDateTime lastStudyAt;
    private List<VideoProgressItemVO> videos;
}
