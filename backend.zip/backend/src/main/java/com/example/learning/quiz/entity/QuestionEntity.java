package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.quiz.enums.QuestionType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "question")
@EqualsAndHashCode(callSuper = true)
public class QuestionEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "chapter_id")
    private Long chapterId;

    @Column(name = "teacher_id", nullable = false)
    private Long teacherId;

    @Lob
    @Column(name = "stem", nullable = false)
    private String stem;

    @Enumerated(EnumType.STRING)
    @Column(name = "question_type", nullable = false, length = 32)
    private QuestionType questionType;

    @Lob
    @Column(name = "standard_answer", nullable = false)
    private String standardAnswer;

    @Lob
    @Column(name = "analysis")
    private String analysis;

    @Column(name = "difficulty", length = 32)
    private String difficulty;

    @Column(name = "knowledge_point", length = 255)
    private String knowledgePoint;

    @Column(name = "partial_credit_enabled", nullable = false)
    private Boolean partialCreditEnabled;
}
