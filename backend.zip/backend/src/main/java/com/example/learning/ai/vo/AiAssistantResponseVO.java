package com.example.learning.ai.vo;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AiAssistantResponseVO {
    Long conversationId;
    String questionText;
    List<String> knowledgePoints;
    String difficulty;
    List<String> solutionSteps;
    String mistakeAnalysis;
    List<AiRecommendationVO> recommendations;
    Boolean degraded;
    String message;
}
