package com.example.learning.knowledge.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.knowledge.enums.KnowledgeResourceType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "learning_recommendation")
@EqualsAndHashCode(callSuper = true)
public class LearningRecommendationEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "batch_no", nullable = false, length = 64)
    private String batchNo;

    @Column(name = "knowledge_point_id")
    private Long knowledgePointId;

    @Column(name = "knowledge_point_name", length = 128)
    private String knowledgePointName;

    @Enumerated(EnumType.STRING)
    @Column(name = "resource_type", nullable = false, length = 32)
    private KnowledgeResourceType resourceType;

    @Column(name = "resource_id", nullable = false)
    private Long resourceId;

    @Column(name = "resource_title", nullable = false, length = 255)
    private String resourceTitle;

    @Lob
    @Column(name = "reason", nullable = false)
    private String reason;

    @Column(name = "sort_order", nullable = false)
    private Integer sortOrder;

    @Column(name = "default_recommendation", nullable = false)
    private Boolean defaultRecommendation;
}
