package com.example.learning.studyroom.mapper;

import com.example.learning.studyroom.entity.StudyRoomEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudyRoomMapper extends JpaRepository<StudyRoomEntity, Long> {

    Optional<StudyRoomEntity> findByIdAndDeletedFalse(Long id);

    List<StudyRoomEntity> findAllByDeletedFalseOrderByIdAsc();
}
