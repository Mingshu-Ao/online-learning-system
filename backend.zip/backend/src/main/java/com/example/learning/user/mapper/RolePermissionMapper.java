package com.example.learning.user.mapper;

import com.example.learning.user.entity.RolePermissionEntity;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolePermissionMapper extends JpaRepository<RolePermissionEntity, Long> {

    List<RolePermissionEntity> findAllByRoleIdInAndDeletedFalse(Collection<Long> roleIds);
}
