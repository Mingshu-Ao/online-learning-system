package com.example.learning.course.mapper;

import com.example.learning.course.entity.StudyRecordEntity;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StudyRecordMapper extends JpaRepository<StudyRecordEntity, Long> {

    List<StudyRecordEntity> findAllByDeletedFalseAndCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    @Query("""
            select coalesce(sum(s.trustedIncrementSeconds), 0)
            from StudyRecordEntity s
            where s.deleted = false
              and s.createdAt between :start and :end
            """)
    long sumTrustedIncrementSecondsBetween(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}
