package com.example.learning.studyroom.service;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.studyroom.enums.UserRoomState;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Component;

@Component
public class StudyRoomStateMachine {

    private static final Map<UserRoomState, Set<UserRoomState>> ALLOWED_TRANSITIONS = new EnumMap<>(UserRoomState.class);

    static {
        ALLOWED_TRANSITIONS.put(UserRoomState.FOCUSING, EnumSet.of(UserRoomState.BREAK, UserRoomState.AWAY,
                UserRoomState.DISCONNECTED, UserRoomState.LEFT));
        ALLOWED_TRANSITIONS.put(UserRoomState.BREAK, EnumSet.of(UserRoomState.FOCUSING, UserRoomState.AWAY,
                UserRoomState.DISCONNECTED, UserRoomState.LEFT));
        ALLOWED_TRANSITIONS.put(UserRoomState.AWAY, EnumSet.of(UserRoomState.FOCUSING, UserRoomState.BREAK,
                UserRoomState.DISCONNECTED, UserRoomState.LEFT));
        ALLOWED_TRANSITIONS.put(UserRoomState.DISCONNECTED, EnumSet.of(UserRoomState.FOCUSING, UserRoomState.BREAK,
                UserRoomState.AWAY, UserRoomState.LEFT));
        ALLOWED_TRANSITIONS.put(UserRoomState.LEFT, EnumSet.noneOf(UserRoomState.class));
    }

    public UserRoomState initialState() {
        return UserRoomState.FOCUSING;
    }

    public void assertTransition(UserRoomState currentState, UserRoomState targetState) {
        if (currentState == null || targetState == null) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_STATE_INVALID, "state cannot be null");
        }
        if (currentState == targetState) {
            return;
        }
        Set<UserRoomState> allowed = ALLOWED_TRANSITIONS.getOrDefault(currentState, EnumSet.noneOf(UserRoomState.class));
        if (!allowed.contains(targetState)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_STATE_INVALID,
                    "cannot transition from " + currentState + " to " + targetState);
        }
    }
}
