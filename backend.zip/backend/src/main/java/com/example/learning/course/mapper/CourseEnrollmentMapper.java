package com.example.learning.course.mapper;

import com.example.learning.course.entity.CourseEnrollmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseEnrollmentMapper extends JpaRepository<CourseEnrollmentEntity, Long> {

    boolean existsByCourseIdAndUserIdAndDeletedFalse(Long courseId, Long userId);
}
