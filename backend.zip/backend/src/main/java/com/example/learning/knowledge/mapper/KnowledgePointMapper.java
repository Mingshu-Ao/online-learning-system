package com.example.learning.knowledge.mapper;

import com.example.learning.knowledge.entity.KnowledgePointEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KnowledgePointMapper extends JpaRepository<KnowledgePointEntity, Long> {

    Optional<KnowledgePointEntity> findByIdAndDeletedFalse(Long id);

    Optional<KnowledgePointEntity> findByCourseIdAndNameAndDeletedFalse(Long courseId, String name);

    List<KnowledgePointEntity> findAllByCourseIdAndDeletedFalseOrderByNameAsc(Long courseId);

    List<KnowledgePointEntity> findAllByIdInAndDeletedFalse(Collection<Long> ids);
}
