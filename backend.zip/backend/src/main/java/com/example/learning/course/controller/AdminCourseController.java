package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.audit.AdminOperationAudit;
import com.example.learning.course.dto.CourseReviewDTO;
import com.example.learning.course.service.AdminCourseService;
import com.example.learning.course.vo.CourseDetailVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/courses")
public class AdminCourseController {

    private final AdminCourseService adminCourseService;

    @PostMapping("/{id}/review")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('course:review')")
    @AdminOperationAudit(action = "COURSE_REVIEW", targetType = "COURSE", targetId = "#id", summary = "#reviewDTO.action")
    public ApiResponse<CourseDetailVO> reviewCourse(@PathVariable Long id,
                                                    @Valid @RequestBody CourseReviewDTO reviewDTO) {
        return ApiResponse.success(adminCourseService.reviewCourse(id, reviewDTO));
    }
}
