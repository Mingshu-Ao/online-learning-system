package com.example.learning.admin.vo;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AdminDailyStatisticsItemVO {

    private LocalDate date;
    private long newUsers;
    private long dailyActiveUsers;
    private long aiCallCount;
    private long learningDurationSeconds;
}
