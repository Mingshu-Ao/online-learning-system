package com.example.learning.websocket;

import com.example.learning.studyroom.vo.StudyRoomWsEnvelopeVO;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

@Slf4j
@Service
@RequiredArgsConstructor
public class InMemoryStudyRoomBroadcastService implements StudyRoomBroadcastService {

    private final ObjectMapper objectMapper;
    private final Map<String, SessionBinding> sessions = new ConcurrentHashMap<>();
    private final Map<Long, Set<String>> sessionsByUser = new ConcurrentHashMap<>();

    @Override
    public void registerSession(Long userId, WebSocketSession session, Long currentRoomId) {
        SessionBinding binding = new SessionBinding(userId, currentRoomId, session);
        sessions.put(session.getId(), binding);
        sessionsByUser.computeIfAbsent(userId, key -> ConcurrentHashMap.newKeySet()).add(session.getId());
    }

    @Override
    public void unregisterSession(WebSocketSession session) {
        SessionBinding binding = sessions.remove(session.getId());
        if (binding == null) {
            return;
        }
        Set<String> userSessions = sessionsByUser.get(binding.userId());
        if (userSessions != null) {
            userSessions.remove(session.getId());
            if (userSessions.isEmpty()) {
                sessionsByUser.remove(binding.userId());
            }
        }
    }

    @Override
    public void bindUserToRoom(Long userId, Long roomId) {
        updateUserRoom(userId, roomId);
    }

    @Override
    public void unbindUserFromRoom(Long userId) {
        updateUserRoom(userId, null);
    }

    @Override
    public void broadcastToRoom(Long roomId, StudyRoomWsEnvelopeVO message) {
        sessions.values().stream()
                .filter(binding -> roomId.equals(binding.roomId()))
                .forEach(binding -> send(binding.session(), message));
    }

    @Override
    public void sendToUser(Long userId, StudyRoomWsEnvelopeVO message) {
        sessions.values().stream()
                .filter(binding -> userId.equals(binding.userId()))
                .forEach(binding -> send(binding.session(), message));
    }

    @Override
    public boolean hasActiveSession(Long userId) {
        Set<String> userSessions = sessionsByUser.get(userId);
        return userSessions != null && !userSessions.isEmpty();
    }

    private void updateUserRoom(Long userId, Long roomId) {
        Set<String> userSessions = sessionsByUser.get(userId);
        if (userSessions == null) {
            return;
        }
        for (String sessionId : userSessions) {
            SessionBinding binding = sessions.get(sessionId);
            if (binding != null) {
                sessions.put(sessionId, new SessionBinding(binding.userId(), roomId, binding.session()));
            }
        }
    }

    private void send(WebSocketSession session, StudyRoomWsEnvelopeVO message) {
        if (session == null || !session.isOpen()) {
            return;
        }
        try {
            session.sendMessage(new TextMessage(objectMapper.writeValueAsString(message)));
        } catch (Exception ex) {
            log.warn("failed to send study-room websocket message to session {}", session.getId(), ex);
        }
    }

    private record SessionBinding(Long userId, Long roomId, WebSocketSession session) {
    }
}
