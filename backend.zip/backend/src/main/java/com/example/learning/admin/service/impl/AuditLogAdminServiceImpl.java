package com.example.learning.admin.service.impl;

import com.example.learning.admin.dto.ErrorLogQueryDTO;
import com.example.learning.admin.dto.LoginLogQueryDTO;
import com.example.learning.admin.dto.OperationLogQueryDTO;
import com.example.learning.admin.dto.ResourceAccessLogQueryDTO;
import com.example.learning.admin.entity.LoginLogEntity;
import com.example.learning.admin.entity.OperationLogEntity;
import com.example.learning.admin.entity.ResourceAccessLogEntity;
import com.example.learning.admin.entity.SystemErrorLogEntity;
import com.example.learning.admin.mapper.LoginLogMapper;
import com.example.learning.admin.mapper.OperationLogMapper;
import com.example.learning.admin.mapper.ResourceAccessLogMapper;
import com.example.learning.admin.mapper.SystemErrorLogMapper;
import com.example.learning.admin.service.AuditLogAdminService;
import com.example.learning.admin.vo.LoginLogVO;
import com.example.learning.admin.vo.OperationLogVO;
import com.example.learning.admin.vo.ResourceAccessLogVO;
import com.example.learning.admin.vo.SystemErrorLogVO;
import com.example.learning.common.vo.PageResultVO;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class AuditLogAdminServiceImpl implements AuditLogAdminService {

    private final LoginLogMapper loginLogMapper;
    private final OperationLogMapper operationLogMapper;
    private final ResourceAccessLogMapper resourceAccessLogMapper;
    private final SystemErrorLogMapper systemErrorLogMapper;

    @Override
    public PageResultVO<LoginLogVO> listLoginLogs(LoginLogQueryDTO queryDTO) {
        Page<LoginLogEntity> page = loginLogMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            if (StringUtils.hasText(queryDTO.getUsername())) {
                predicates.add(cb.like(root.get("username"), "%" + queryDTO.getUsername().trim() + "%"));
            }
            if (queryDTO.getSuccess() != null) {
                predicates.add(cb.equal(root.get("success"), queryDTO.getSuccess()));
            }
            if (queryDTO.getStartTime() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), queryDTO.getStartTime()));
            }
            if (queryDTO.getEndTime() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), queryDTO.getEndTime()));
            }
            return cb.and(predicates.toArray(Predicate[]::new));
        }, pageRequest(queryDTO.getPageNum(), queryDTO.getPageSize()));
        return PageResultVO.<LoginLogVO>builder()
                .total(page.getTotalElements())
                .records(page.getContent().stream().map(entity -> LoginLogVO.builder()
                        .id(entity.getId())
                        .userId(entity.getUserId())
                        .username(entity.getUsername())
                        .success(entity.getSuccess())
                        .failureReason(entity.getFailureReason())
                        .requestPath(entity.getRequestPath())
                        .ipAddress(entity.getIpAddress())
                        .userAgent(entity.getUserAgent())
                        .createdAt(entity.getCreatedAt())
                        .build()).toList())
                .build();
    }

    @Override
    public PageResultVO<OperationLogVO> listOperationLogs(OperationLogQueryDTO queryDTO) {
        Page<OperationLogEntity> page = operationLogMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            if (StringUtils.hasText(queryDTO.getOperatorUsername())) {
                predicates.add(cb.like(root.get("operatorUsername"), "%" + queryDTO.getOperatorUsername().trim() + "%"));
            }
            if (StringUtils.hasText(queryDTO.getAction())) {
                predicates.add(cb.like(root.get("action"), "%" + queryDTO.getAction().trim() + "%"));
            }
            if (queryDTO.getSuccess() != null) {
                predicates.add(cb.equal(root.get("success"), queryDTO.getSuccess()));
            }
            if (queryDTO.getStartTime() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), queryDTO.getStartTime()));
            }
            if (queryDTO.getEndTime() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), queryDTO.getEndTime()));
            }
            return cb.and(predicates.toArray(Predicate[]::new));
        }, pageRequest(queryDTO.getPageNum(), queryDTO.getPageSize()));
        return PageResultVO.<OperationLogVO>builder()
                .total(page.getTotalElements())
                .records(page.getContent().stream().map(entity -> OperationLogVO.builder()
                        .id(entity.getId())
                        .operatorUserId(entity.getOperatorUserId())
                        .operatorUsername(entity.getOperatorUsername())
                        .action(entity.getAction())
                        .targetType(entity.getTargetType())
                        .targetId(entity.getTargetId())
                        .httpMethod(entity.getHttpMethod())
                        .requestPath(entity.getRequestPath())
                        .success(entity.getSuccess())
                        .requestSummary(entity.getRequestSummary())
                        .errorMessage(entity.getErrorMessage())
                        .durationMs(entity.getDurationMs())
                        .ipAddress(entity.getIpAddress())
                        .userAgent(entity.getUserAgent())
                        .createdAt(entity.getCreatedAt())
                        .build()).toList())
                .build();
    }

    @Override
    public PageResultVO<ResourceAccessLogVO> listResourceAccessLogs(ResourceAccessLogQueryDTO queryDTO) {
        Page<ResourceAccessLogEntity> page = resourceAccessLogMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            if (queryDTO.getUserId() != null) {
                predicates.add(cb.equal(root.get("userId"), queryDTO.getUserId()));
            }
            if (queryDTO.getCourseId() != null) {
                predicates.add(cb.equal(root.get("courseId"), queryDTO.getCourseId()));
            }
            if (queryDTO.getResourceId() != null) {
                predicates.add(cb.equal(root.get("resourceId"), queryDTO.getResourceId()));
            }
            if (queryDTO.getStartTime() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), queryDTO.getStartTime()));
            }
            if (queryDTO.getEndTime() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), queryDTO.getEndTime()));
            }
            return cb.and(predicates.toArray(Predicate[]::new));
        }, pageRequest(queryDTO.getPageNum(), queryDTO.getPageSize()));
        return PageResultVO.<ResourceAccessLogVO>builder()
                .total(page.getTotalElements())
                .records(page.getContent().stream().map(entity -> ResourceAccessLogVO.builder()
                        .id(entity.getId())
                        .userId(entity.getUserId())
                        .courseId(entity.getCourseId())
                        .resourceId(entity.getResourceId())
                        .resourceType(entity.getResourceType())
                        .requestPath(entity.getRequestPath())
                        .ipAddress(entity.getIpAddress())
                        .userAgent(entity.getUserAgent())
                        .createdAt(entity.getCreatedAt())
                        .build()).toList())
                .build();
    }

    @Override
    public PageResultVO<SystemErrorLogVO> listErrorLogs(ErrorLogQueryDTO queryDTO) {
        Page<SystemErrorLogEntity> page = systemErrorLogMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            if (queryDTO.getErrorCode() != null) {
                predicates.add(cb.equal(root.get("errorCode"), queryDTO.getErrorCode()));
            }
            if (StringUtils.hasText(queryDTO.getRequestPath())) {
                predicates.add(cb.like(root.get("requestPath"), "%" + queryDTO.getRequestPath().trim() + "%"));
            }
            if (queryDTO.getStartTime() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), queryDTO.getStartTime()));
            }
            if (queryDTO.getEndTime() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), queryDTO.getEndTime()));
            }
            return cb.and(predicates.toArray(Predicate[]::new));
        }, pageRequest(queryDTO.getPageNum(), queryDTO.getPageSize()));
        return PageResultVO.<SystemErrorLogVO>builder()
                .total(page.getTotalElements())
                .records(page.getContent().stream().map(entity -> SystemErrorLogVO.builder()
                        .id(entity.getId())
                        .userId(entity.getUserId())
                        .errorCode(entity.getErrorCode())
                        .exceptionClass(entity.getExceptionClass())
                        .errorMessage(entity.getErrorMessage())
                        .httpMethod(entity.getHttpMethod())
                        .requestPath(entity.getRequestPath())
                        .requestSummary(entity.getRequestSummary())
                        .ipAddress(entity.getIpAddress())
                        .userAgent(entity.getUserAgent())
                        .createdAt(entity.getCreatedAt())
                        .build()).toList())
                .build();
    }

    private PageRequest pageRequest(int pageNum, int pageSize) {
        return PageRequest.of(pageNum - 1, pageSize, Sort.by(Sort.Direction.DESC, "createdAt"));
    }
}
