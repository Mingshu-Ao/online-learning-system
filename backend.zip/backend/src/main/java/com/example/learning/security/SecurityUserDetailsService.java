package com.example.learning.security;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.user.entity.PermissionEntity;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.RolePermissionEntity;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.entity.UserRoleEntity;
import com.example.learning.user.mapper.PermissionMapper;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.RolePermissionMapper;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SecurityUserDetailsService implements UserDetailsService {

    private final UserMapper userMapper;
    private final UserRoleMapper userRoleMapper;
    private final RoleMapper roleMapper;
    private final RolePermissionMapper rolePermissionMapper;
    private final PermissionMapper permissionMapper;

    @Override
    public SecurityUser loadUserByUsername(String username) throws UsernameNotFoundException {
        UserEntity user = userMapper.findByUsernameAndDeletedFalse(username)
                .orElseThrow(() -> new UsernameNotFoundException("user not found"));
        return buildSecurityUser(user);
    }

    public SecurityUser loadUserById(Long userId) {
        UserEntity user = userMapper.findByIdAndDeletedFalse(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        return buildSecurityUser(user);
    }

    public SecurityUser buildSecurityUser(UserEntity user) {
        return SecurityUser.builder()
                .id(user.getId())
                .username(user.getUsername())
                .password(user.getPasswordHash())
                .nickname(user.getNickname())
                .status(user.getStatus())
                .tokenVersion(user.getTokenVersion())
                .authorities(buildAuthorities(user.getId()))
                .build();
    }

    private Collection<SimpleGrantedAuthority> buildAuthorities(Long userId) {
        List<UserRoleEntity> userRoles = userRoleMapper.findAllByUserIdAndDeletedFalse(userId);
        if (userRoles.isEmpty()) {
            return List.of();
        }
        List<Long> roleIds = userRoles.stream().map(UserRoleEntity::getRoleId).distinct().toList();
        List<RoleEntity> roles = roleMapper.findAllByIdInAndDeletedFalse(roleIds);
        Set<SimpleGrantedAuthority> authorities = new LinkedHashSet<>();
        roles.forEach(role -> authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getCode())));

        List<RolePermissionEntity> rolePermissions = rolePermissionMapper.findAllByRoleIdInAndDeletedFalse(roleIds);
        if (rolePermissions.isEmpty()) {
            return authorities;
        }
        List<Long> permissionIds = rolePermissions.stream().map(RolePermissionEntity::getPermissionId).distinct().toList();
        List<PermissionEntity> permissions = permissionMapper.findAllByIdInAndDeletedFalse(permissionIds);
        authorities.addAll(permissions.stream()
                .map(PermissionEntity::getCode)
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toCollection(LinkedHashSet::new)));
        return authorities;
    }
}
