package com.example.learning.studyroom.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.security.SecurityUtils;
import com.example.learning.studyroom.service.StudyRoomService;
import com.example.learning.studyroom.vo.StudyRoomJoinVO;
import com.example.learning.studyroom.vo.StudyRoomListItemVO;
import com.example.learning.studyroom.vo.StudyRoomSnapshotVO;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/study-rooms")
public class StudyRoomController {

    private final StudyRoomService studyRoomService;

    @GetMapping
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<List<StudyRoomListItemVO>> listRooms() {
        return ApiResponse.success(studyRoomService.listRooms());
    }

    @PostMapping("/{roomId}/join")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<StudyRoomJoinVO> joinRoom(@PathVariable Long roomId) {
        return ApiResponse.success(studyRoomService.joinRoom(SecurityUtils.getCurrentUserId(), roomId));
    }

    @PostMapping("/{roomId}/leave")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<Void> leaveRoom(@PathVariable Long roomId) {
        studyRoomService.leaveRoom(SecurityUtils.getCurrentUserId(), roomId);
        return ApiResponse.success(null);
    }

    @GetMapping("/{roomId}/snapshot")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<StudyRoomSnapshotVO> getSnapshot(@PathVariable Long roomId) {
        return ApiResponse.success(studyRoomService.getSnapshot(roomId));
    }
}
