package com.example.learning.ai.config;

import java.time.Duration;
import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "app.ai")
public class AiServiceProperties {

    private String baseUrl = "http://localhost:8000";
    private Duration connectTimeout = Duration.ofSeconds(3);
    private Duration readTimeout = Duration.ofSeconds(30);
    private int textRequestsPerMinute = 10;
    private int imageRequestsPerMinute = 3;
    private long maxImageSizeBytes = 5L * 1024L * 1024L;
    private List<String> allowedImageContentTypes = List.of("image/jpeg", "image/png", "image/webp");
    private List<String> allowedImageExtensions = List.of(".jpg", ".jpeg", ".png", ".webp");
    private String degradedMessage = "AI 助教暂时繁忙，请稍后重试，或先查看课程资源和错题解析。";
}
