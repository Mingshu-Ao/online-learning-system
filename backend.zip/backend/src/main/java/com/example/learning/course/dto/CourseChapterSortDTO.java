package com.example.learning.course.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
public class CourseChapterSortDTO {

    @Valid
    @NotEmpty(message = "chapters cannot be empty")
    private List<CourseChapterSortItemDTO> chapters;
}
