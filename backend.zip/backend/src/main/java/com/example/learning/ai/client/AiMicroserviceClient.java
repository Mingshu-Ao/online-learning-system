package com.example.learning.ai.client;

import com.example.learning.ai.model.AiAnswerPayload;
import org.springframework.web.multipart.MultipartFile;

public interface AiMicroserviceClient {

    AiAnswerPayload ask(Long userId, Long courseId, String question);

    AiAnswerPayload solveImage(Long userId, Long courseId, MultipartFile image);
}
