package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.PaperEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaperMapper extends JpaRepository<PaperEntity, Long> {

    Optional<PaperEntity> findByIdAndDeletedFalse(Long id);
}
