package com.example.learning.studyroom.mapper;

import com.example.learning.studyroom.entity.RoomCheckinEntity;
import java.time.LocalDate;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomCheckinMapper extends JpaRepository<RoomCheckinEntity, Long> {

    Optional<RoomCheckinEntity> findByRoomIdAndUserIdAndCheckinDateAndDeletedFalse(Long roomId, Long userId, LocalDate checkinDate);
}
