package com.example.learning.quiz.service;

import com.example.learning.quiz.dto.StudentExamSubmitDTO;
import com.example.learning.quiz.dto.WrongQuestionQueryDTO;
import com.example.learning.quiz.vo.ExamResultVO;
import com.example.learning.quiz.vo.ExamStartVO;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.WrongQuestionVO;
import java.util.List;

public interface StudentExamService {

    PaperDetailVO getPaper(Long studentId, Long paperId);

    ExamStartVO startExam(Long studentId, Long paperId);

    ExamResultVO submitExam(Long studentId, Long examRecordId, StudentExamSubmitDTO submitDTO);

    ExamResultVO getExamResult(Long studentId, Long examRecordId);

    List<WrongQuestionVO> listWrongQuestions(Long studentId, WrongQuestionQueryDTO queryDTO);

    WrongQuestionVO redoWrongQuestion(Long studentId, Long wrongQuestionId);

    WrongQuestionVO markWrongQuestionMastered(Long studentId, Long wrongQuestionId);
}
