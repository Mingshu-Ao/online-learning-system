package com.example.learning.course.mapper;

import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.ResourceType;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseResourceMapper extends JpaRepository<CourseResourceEntity, Long> {

    Optional<CourseResourceEntity> findByIdAndDeletedFalse(Long id);

    List<CourseResourceEntity> findAllByCourseIdAndDeletedFalse(Long courseId);

    List<CourseResourceEntity> findAllByCourseIdAndResourceTypeAndDeletedFalse(Long courseId, ResourceType resourceType);

    List<CourseResourceEntity> findAllByChapterIdInAndDeletedFalse(Collection<Long> chapterIds);
}
