package com.example.learning.studyroom.vo;

import com.example.learning.studyroom.enums.StudyRoomMessageType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StudyRoomWsEnvelopeVO {

    private StudyRoomMessageType type;
    private Long roomId;
    private Long senderId;
    private Long timestamp;
    private Object payload;
}
