package com.example.learning.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SystemStatusVO {

    private String serviceName;
    private String version;
    private String status;
}

