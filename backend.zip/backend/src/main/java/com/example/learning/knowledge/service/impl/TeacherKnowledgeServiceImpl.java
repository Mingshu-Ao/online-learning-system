package com.example.learning.knowledge.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.knowledge.dto.KnowledgePointUpsertDTO;
import com.example.learning.knowledge.dto.KnowledgeRelationUpdateDTO;
import com.example.learning.knowledge.dto.KnowledgeResourceBindingDTO;
import com.example.learning.knowledge.dto.QuestionKnowledgeBindDTO;
import com.example.learning.knowledge.entity.KnowledgePointEntity;
import com.example.learning.knowledge.entity.KnowledgeRelationEntity;
import com.example.learning.knowledge.entity.KnowledgeResourceEntity;
import com.example.learning.knowledge.enums.KnowledgeResourceType;
import com.example.learning.knowledge.mapper.KnowledgePointMapper;
import com.example.learning.knowledge.mapper.KnowledgeRelationMapper;
import com.example.learning.knowledge.mapper.KnowledgeResourceMapper;
import com.example.learning.knowledge.service.TeacherKnowledgeService;
import com.example.learning.knowledge.vo.KnowledgePointVO;
import com.example.learning.knowledge.vo.KnowledgeResourceBindingVO;
import com.example.learning.knowledge.vo.QuestionKnowledgeBindingVO;
import com.example.learning.quiz.entity.QuestionEntity;
import com.example.learning.quiz.mapper.QuestionMapper;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class TeacherKnowledgeServiceImpl implements TeacherKnowledgeService {

    private final KnowledgePointMapper knowledgePointMapper;
    private final KnowledgeRelationMapper knowledgeRelationMapper;
    private final KnowledgeResourceMapper knowledgeResourceMapper;
    private final CourseMapper courseMapper;
    private final CourseChapterMapper courseChapterMapper;
    private final CourseResourceMapper courseResourceMapper;
    private final QuestionMapper questionMapper;

    @Override
    @Transactional
    public KnowledgePointVO createKnowledgePoint(Long teacherId, Long courseId, KnowledgePointUpsertDTO upsertDTO) {
        getOwnedCourse(teacherId, courseId);
        ensureKnowledgePointNameAvailable(courseId, upsertDTO.getName(), null);
        KnowledgePointEntity entity = new KnowledgePointEntity();
        entity.setCourseId(courseId);
        entity.setTeacherId(teacherId);
        entity.setName(upsertDTO.getName().trim());
        entity.setDescription(blankToNull(upsertDTO.getDescription()));
        return toKnowledgePointVO(saveKnowledgePoint(entity));
    }

    @Override
    @Transactional
    public KnowledgePointVO updateKnowledgePoint(Long teacherId, Long knowledgePointId, KnowledgePointUpsertDTO upsertDTO) {
        KnowledgePointEntity entity = getOwnedKnowledgePoint(teacherId, knowledgePointId);
        ensureKnowledgePointNameAvailable(entity.getCourseId(), upsertDTO.getName(), entity.getId());
        entity.setName(upsertDTO.getName().trim());
        entity.setDescription(blankToNull(upsertDTO.getDescription()));
        KnowledgePointEntity saved = saveKnowledgePoint(entity);
        syncQuestionKnowledgePointNames(saved);
        return toKnowledgePointVO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<KnowledgePointVO> listKnowledgePoints(Long teacherId, Long courseId) {
        getOwnedCourse(teacherId, courseId);
        List<KnowledgePointEntity> points = knowledgePointMapper.findAllByCourseIdAndDeletedFalseOrderByNameAsc(courseId);
        if (points.isEmpty()) {
            return List.of();
        }
        return toKnowledgePointVOs(points);
    }

    @Override
    @Transactional
    public KnowledgePointVO updatePrerequisites(Long teacherId, Long knowledgePointId, KnowledgeRelationUpdateDTO updateDTO) {
        KnowledgePointEntity knowledgePoint = getOwnedKnowledgePoint(teacherId, knowledgePointId);
        Set<Long> prerequisiteIds = deduplicateIds(updateDTO.getPrerequisiteIds());
        if (prerequisiteIds.contains(knowledgePointId)) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "knowledge point cannot depend on itself");
        }
        List<KnowledgePointEntity> prerequisitePoints = prerequisiteIds.isEmpty()
                ? List.of()
                : knowledgePointMapper.findAllByIdInAndDeletedFalse(prerequisiteIds);
        if (prerequisitePoints.size() != prerequisiteIds.size()) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "one or more prerequisite knowledge points do not exist");
        }
        if (prerequisitePoints.stream().anyMatch(item -> !Objects.equals(item.getCourseId(), knowledgePoint.getCourseId()))) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "prerequisite knowledge points must belong to the same course");
        }
        assertNoCycle(knowledgePoint.getCourseId(), knowledgePointId, prerequisiteIds);

        List<KnowledgeRelationEntity> existingRelations = knowledgeRelationMapper.findAllByKnowledgePointIdAndDeletedFalse(knowledgePointId);
        softDelete(existingRelations);
        List<KnowledgeRelationEntity> relations = prerequisiteIds.stream()
                .map(prerequisiteId -> {
                    KnowledgeRelationEntity relation = new KnowledgeRelationEntity();
                    relation.setCourseId(knowledgePoint.getCourseId());
                    relation.setKnowledgePointId(knowledgePointId);
                    relation.setPrerequisiteId(prerequisiteId);
                    return relation;
                })
                .toList();
        knowledgeRelationMapper.saveAll(relations);
        return toKnowledgePointVO(knowledgePoint);
    }

    @Override
    @Transactional
    public KnowledgePointVO updateResources(Long teacherId, Long knowledgePointId, KnowledgeResourceBindingDTO bindingDTO) {
        KnowledgePointEntity knowledgePoint = getOwnedKnowledgePoint(teacherId, knowledgePointId);
        Set<Long> chapterIds = deduplicateIds(bindingDTO.getChapterIds());
        Set<Long> resourceIds = deduplicateIds(bindingDTO.getCourseResourceIds());

        List<CourseChapterEntity> chapters = chapterIds.isEmpty() ? List.of() : courseChapterMapper.findAllByIdInAndDeletedFalse(chapterIds);
        if (chapters.size() != chapterIds.size()) {
            throw new BusinessException(ErrorCode.CHAPTER_NOT_FOUND, "one or more chapters do not exist");
        }
        if (chapters.stream().anyMatch(item -> !Objects.equals(item.getCourseId(), knowledgePoint.getCourseId()))) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "chapters must belong to the same course");
        }

        List<CourseResourceEntity> resources = resourceIds.isEmpty() ? List.of() : courseResourceMapper.findAllById(resourceIds);
        Map<Long, CourseResourceEntity> resourceMap = resources.stream()
                .filter(resource -> !Boolean.TRUE.equals(resource.getDeleted()))
                .collect(Collectors.toMap(CourseResourceEntity::getId, item -> item));
        if (resourceMap.size() != resourceIds.size()) {
            throw new BusinessException(ErrorCode.RESOURCE_NOT_FOUND, "one or more resources do not exist");
        }
        if (resourceMap.values().stream().anyMatch(item -> !Objects.equals(item.getCourseId(), knowledgePoint.getCourseId()))) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "resources must belong to the same course");
        }

        List<KnowledgeResourceEntity> existing = knowledgeResourceMapper.findAllByKnowledgePointIdAndDeletedFalse(knowledgePointId);
        List<KnowledgeResourceEntity> writableExisting = existing.stream()
                .filter(item -> item.getResourceType() != KnowledgeResourceType.QUESTION)
                .toList();
        softDelete(writableExisting);

        List<KnowledgeResourceEntity> toSave = new ArrayList<>();
        chapterIds.forEach(chapterId -> toSave.add(newKnowledgeResource(knowledgePoint.getCourseId(), knowledgePointId,
                KnowledgeResourceType.CHAPTER, chapterId)));
        resourceMap.values().forEach(resource -> toSave.add(newKnowledgeResource(knowledgePoint.getCourseId(), knowledgePointId,
                resolveKnowledgeResourceType(resource.getResourceType()), resource.getId())));
        knowledgeResourceMapper.saveAll(toSave);
        return toKnowledgePointVO(knowledgePoint);
    }

    @Override
    @Transactional
    public QuestionKnowledgeBindingVO bindQuestionKnowledgePoint(Long teacherId, Long questionId, QuestionKnowledgeBindDTO bindDTO) {
        QuestionEntity question = questionMapper.findByIdAndDeletedFalse(questionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.QUESTION_NOT_FOUND));
        getOwnedCourse(teacherId, question.getCourseId());
        KnowledgePointEntity knowledgePoint = getOwnedKnowledgePoint(teacherId, bindDTO.getKnowledgePointId());
        if (!Objects.equals(question.getCourseId(), knowledgePoint.getCourseId())) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "question and knowledge point must belong to the same course");
        }

        List<KnowledgeResourceEntity> previousBindings = knowledgeResourceMapper
                .findAllByResourceTypeAndResourceIdAndDeletedFalse(KnowledgeResourceType.QUESTION, questionId);
        softDelete(previousBindings);

        question.setKnowledgePoint(knowledgePoint.getName());
        questionMapper.save(question);

        KnowledgeResourceEntity binding = newKnowledgeResource(knowledgePoint.getCourseId(), knowledgePoint.getId(),
                KnowledgeResourceType.QUESTION, questionId);
        knowledgeResourceMapper.save(binding);
        return QuestionKnowledgeBindingVO.builder()
                .questionId(questionId)
                .knowledgePointId(knowledgePoint.getId())
                .knowledgePointName(knowledgePoint.getName())
                .build();
    }

    private KnowledgePointEntity saveKnowledgePoint(KnowledgePointEntity entity) {
        try {
            return knowledgePointMapper.save(entity);
        } catch (DataIntegrityViolationException ex) {
            throw new BusinessException(ErrorCode.CONFLICT, "knowledge point name already exists in this course");
        }
    }

    private void ensureKnowledgePointNameAvailable(Long courseId, String name, Long currentId) {
        knowledgePointMapper.findByCourseIdAndNameAndDeletedFalse(courseId, name.trim())
                .filter(existing -> !Objects.equals(existing.getId(), currentId))
                .ifPresent(existing -> {
                    throw new BusinessException(ErrorCode.CONFLICT, "knowledge point name already exists in this course");
                });
    }

    private void assertNoCycle(Long courseId, Long knowledgePointId, Set<Long> newPrerequisiteIds) {
        List<KnowledgeRelationEntity> relations = knowledgeRelationMapper.findAllByCourseIdAndDeletedFalse(courseId);
        Map<Long, Set<Long>> adjacency = new HashMap<>();
        relations.forEach(relation -> adjacency.computeIfAbsent(relation.getKnowledgePointId(), key -> new LinkedHashSet<>())
                .add(relation.getPrerequisiteId()));
        adjacency.put(knowledgePointId, new LinkedHashSet<>(newPrerequisiteIds));

        Set<Long> allNodes = new LinkedHashSet<>(adjacency.keySet());
        adjacency.values().forEach(allNodes::addAll);
        Map<Long, VisitState> states = new HashMap<>();
        for (Long node : allNodes) {
            if (states.get(node) == VisitState.VISITING) {
                throw new BusinessException(ErrorCode.BAD_REQUEST, "knowledge point dependency contains a cycle");
            }
            if (states.get(node) == null && hasCycle(node, adjacency, states)) {
                throw new BusinessException(ErrorCode.BAD_REQUEST, "knowledge point dependency contains a cycle");
            }
        }
    }

    private boolean hasCycle(Long node, Map<Long, Set<Long>> adjacency, Map<Long, VisitState> states) {
        VisitState state = states.get(node);
        if (state == VisitState.VISITING) {
            return true;
        }
        if (state == VisitState.VISITED) {
            return false;
        }
        states.put(node, VisitState.VISITING);
        for (Long next : adjacency.getOrDefault(node, Set.of())) {
            if (hasCycle(next, adjacency, states)) {
                return true;
            }
        }
        states.put(node, VisitState.VISITED);
        return false;
    }

    private void syncQuestionKnowledgePointNames(KnowledgePointEntity knowledgePoint) {
        List<KnowledgeResourceEntity> bindings = knowledgeResourceMapper.findAllByKnowledgePointIdAndDeletedFalse(knowledgePoint.getId()).stream()
                .filter(item -> item.getResourceType() == KnowledgeResourceType.QUESTION)
                .toList();
        if (bindings.isEmpty()) {
            return;
        }
        List<QuestionEntity> questions = questionMapper.findAllByIdInAndDeletedFalse(bindings.stream()
                .map(KnowledgeResourceEntity::getResourceId)
                .toList());
        questions.forEach(question -> question.setKnowledgePoint(knowledgePoint.getName()));
        questionMapper.saveAll(questions);
    }

    private CourseEntity getOwnedCourse(Long teacherId, Long courseId) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (!Objects.equals(course.getTeacherId(), teacherId)) {
            throw new BusinessException(ErrorCode.COURSE_OWNER_REQUIRED);
        }
        return course;
    }

    private KnowledgePointEntity getOwnedKnowledgePoint(Long teacherId, Long knowledgePointId) {
        KnowledgePointEntity knowledgePoint = knowledgePointMapper.findByIdAndDeletedFalse(knowledgePointId)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "knowledge point not found"));
        getOwnedCourse(teacherId, knowledgePoint.getCourseId());
        return knowledgePoint;
    }

    private KnowledgeResourceEntity newKnowledgeResource(Long courseId, Long knowledgePointId,
                                                         KnowledgeResourceType resourceType, Long resourceId) {
        KnowledgeResourceEntity entity = new KnowledgeResourceEntity();
        entity.setCourseId(courseId);
        entity.setKnowledgePointId(knowledgePointId);
        entity.setResourceType(resourceType);
        entity.setResourceId(resourceId);
        return entity;
    }

    private KnowledgeResourceType resolveKnowledgeResourceType(ResourceType resourceType) {
        return resourceType == ResourceType.VIDEO ? KnowledgeResourceType.VIDEO : KnowledgeResourceType.DOCUMENT;
    }

    private List<KnowledgePointVO> toKnowledgePointVOs(List<KnowledgePointEntity> points) {
        List<Long> knowledgePointIds = points.stream().map(KnowledgePointEntity::getId).toList();
        Map<Long, List<Long>> prerequisites = knowledgeRelationMapper.findAllByKnowledgePointIdInAndDeletedFalse(knowledgePointIds).stream()
                .collect(Collectors.groupingBy(KnowledgeRelationEntity::getKnowledgePointId,
                        Collectors.mapping(KnowledgeRelationEntity::getPrerequisiteId, Collectors.toList())));
        Map<Long, List<KnowledgeResourceEntity>> bindings = knowledgeResourceMapper.findAllByKnowledgePointIdInAndDeletedFalse(knowledgePointIds).stream()
                .collect(Collectors.groupingBy(KnowledgeResourceEntity::getKnowledgePointId));
        Map<ResourceKey, String> titles = resolveBindingTitles(bindings.values().stream().flatMap(Collection::stream).toList());
        return points.stream()
                .sorted(Comparator.comparing(KnowledgePointEntity::getName))
                .map(point -> KnowledgePointVO.builder()
                        .knowledgePointId(point.getId())
                        .courseId(point.getCourseId())
                        .name(point.getName())
                        .description(point.getDescription())
                        .prerequisiteIds(prerequisites.getOrDefault(point.getId(), List.of()).stream().sorted().toList())
                        .bindings(bindings.getOrDefault(point.getId(), List.of()).stream()
                                .sorted(Comparator.comparing(KnowledgeResourceEntity::getResourceType).thenComparing(KnowledgeResourceEntity::getResourceId))
                                .map(binding -> KnowledgeResourceBindingVO.builder()
                                        .resourceType(binding.getResourceType().name())
                                        .resourceId(binding.getResourceId())
                                        .resourceTitle(titles.getOrDefault(new ResourceKey(binding.getResourceType(), binding.getResourceId()),
                                                binding.getResourceType().name() + "-" + binding.getResourceId()))
                                        .build())
                                .toList())
                        .build())
                .toList();
    }

    private KnowledgePointVO toKnowledgePointVO(KnowledgePointEntity point) {
        return toKnowledgePointVOs(List.of(point)).get(0);
    }

    private Map<ResourceKey, String> resolveBindingTitles(List<KnowledgeResourceEntity> bindings) {
        Map<ResourceKey, String> titles = new HashMap<>();
        Set<Long> chapterIds = new LinkedHashSet<>();
        Set<Long> resourceIds = new LinkedHashSet<>();
        Set<Long> questionIds = new LinkedHashSet<>();
        for (KnowledgeResourceEntity binding : bindings) {
            switch (binding.getResourceType()) {
                case CHAPTER -> chapterIds.add(binding.getResourceId());
                case VIDEO, DOCUMENT -> resourceIds.add(binding.getResourceId());
                case QUESTION -> questionIds.add(binding.getResourceId());
            }
        }
        courseChapterMapper.findAllByIdInAndDeletedFalse(chapterIds)
                .forEach(chapter -> titles.put(new ResourceKey(KnowledgeResourceType.CHAPTER, chapter.getId()), chapter.getTitle()));
        courseResourceMapper.findAllById(resourceIds).stream()
                .filter(resource -> !Boolean.TRUE.equals(resource.getDeleted()))
                .forEach(resource -> titles.put(new ResourceKey(resolveKnowledgeResourceType(resource.getResourceType()), resource.getId()), resource.getTitle()));
        questionMapper.findAllByIdInAndDeletedFalse(questionIds.stream().toList())
                .forEach(question -> titles.put(new ResourceKey(KnowledgeResourceType.QUESTION, question.getId()), abbreviate(question.getStem(), 80)));
        return titles;
    }

    private void softDelete(List<? extends com.example.learning.entity.BaseEntity> entities) {
        if (entities.isEmpty()) {
            return;
        }
        entities.forEach(entity -> entity.setDeleted(Boolean.TRUE));
        if (entities.get(0) instanceof KnowledgeRelationEntity) {
            knowledgeRelationMapper.saveAll(entities.stream().map(item -> (KnowledgeRelationEntity) item).toList());
            return;
        }
        if (entities.get(0) instanceof KnowledgeResourceEntity) {
            knowledgeResourceMapper.saveAll(entities.stream().map(item -> (KnowledgeResourceEntity) item).toList());
        }
    }

    private Set<Long> deduplicateIds(List<Long> ids) {
        return ids == null ? Set.of() : ids.stream().filter(Objects::nonNull).collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private String abbreviate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }

    private String blankToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private enum VisitState {
        VISITING,
        VISITED
    }

    private record ResourceKey(KnowledgeResourceType resourceType, Long resourceId) {
    }
}
