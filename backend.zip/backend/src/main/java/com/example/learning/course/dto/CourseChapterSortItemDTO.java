package com.example.learning.course.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CourseChapterSortItemDTO {

    @NotNull(message = "chapterId is required")
    private Long chapterId;

    @NotNull(message = "sortOrder is required")
    private Integer sortOrder;
}
