package com.example.learning.studyroom.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.studyroom.enums.SeatStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "study_room_seat", uniqueConstraints = {
        @UniqueConstraint(name = "uk_study_room_seat_no", columnNames = {"room_id", "seat_no"})
})
@EqualsAndHashCode(callSuper = true)
public class StudyRoomSeatEntity extends BaseEntity {

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Column(name = "seat_no", nullable = false)
    private Integer seatNo;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private SeatStatus status;
}
