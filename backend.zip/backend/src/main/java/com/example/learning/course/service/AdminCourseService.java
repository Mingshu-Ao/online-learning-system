package com.example.learning.course.service;

import com.example.learning.course.dto.CourseReviewDTO;
import com.example.learning.course.vo.CourseDetailVO;

public interface AdminCourseService {

    CourseDetailVO reviewCourse(Long courseId, CourseReviewDTO reviewDTO);
}
