package com.example.learning.admin.controller;

import com.example.learning.admin.dto.ErrorLogQueryDTO;
import com.example.learning.admin.dto.LoginLogQueryDTO;
import com.example.learning.admin.dto.OperationLogQueryDTO;
import com.example.learning.admin.dto.ResourceAccessLogQueryDTO;
import com.example.learning.admin.service.AuditLogAdminService;
import com.example.learning.admin.vo.LoginLogVO;
import com.example.learning.admin.vo.OperationLogVO;
import com.example.learning.admin.vo.ResourceAccessLogVO;
import com.example.learning.admin.vo.SystemErrorLogVO;
import com.example.learning.common.response.ApiResponse;
import com.example.learning.common.vo.PageResultVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/logs")
public class AdminAuditLogController {

    private final AuditLogAdminService auditLogAdminService;

    @GetMapping("/login")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('audit:read')")
    public ApiResponse<PageResultVO<LoginLogVO>> listLoginLogs(@Valid LoginLogQueryDTO queryDTO) {
        return ApiResponse.success(auditLogAdminService.listLoginLogs(queryDTO));
    }

    @GetMapping("/operation")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('audit:read')")
    public ApiResponse<PageResultVO<OperationLogVO>> listOperationLogs(@Valid OperationLogQueryDTO queryDTO) {
        return ApiResponse.success(auditLogAdminService.listOperationLogs(queryDTO));
    }

    @GetMapping("/resource-access")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('audit:read')")
    public ApiResponse<PageResultVO<ResourceAccessLogVO>> listResourceAccessLogs(@Valid ResourceAccessLogQueryDTO queryDTO) {
        return ApiResponse.success(auditLogAdminService.listResourceAccessLogs(queryDTO));
    }

    @GetMapping("/errors")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('audit:read')")
    public ApiResponse<PageResultVO<SystemErrorLogVO>> listErrorLogs(@Valid ErrorLogQueryDTO queryDTO) {
        return ApiResponse.success(auditLogAdminService.listErrorLogs(queryDTO));
    }
}
