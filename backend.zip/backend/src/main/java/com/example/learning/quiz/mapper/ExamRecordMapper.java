package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.ExamRecordEntity;
import com.example.learning.quiz.enums.ExamRecordStatus;
import jakarta.persistence.LockModeType;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

public interface ExamRecordMapper extends JpaRepository<ExamRecordEntity, Long> {

    Optional<ExamRecordEntity> findByIdAndDeletedFalse(Long id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<ExamRecordEntity> findWithLockByIdAndDeletedFalse(Long id);

    Optional<ExamRecordEntity> findFirstByPaperIdAndUserIdAndStatusAndDeletedFalseOrderByAttemptNoDesc(Long paperId,
                                                                                                        Long userId,
                                                                                                        ExamRecordStatus status);

    long countByPaperIdAndUserIdAndDeletedFalse(Long paperId, Long userId);
}
