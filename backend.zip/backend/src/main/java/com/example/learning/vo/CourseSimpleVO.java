package com.example.learning.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseSimpleVO {

    private Long id;
    private String title;
    private String summary;
    private String teacherName;
    private String difficulty;
}

