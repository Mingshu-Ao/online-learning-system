package com.example.learning.course.enums;

public enum CourseReviewAction {
    APPROVE,
    REJECT,
    OFFLINE
}
