package com.example.learning.studyroom.realtime;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.studyroom.enums.UserRoomState;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class RedisStudyRoomRealtimeStore implements StudyRoomRealtimeStore {

    private static final Duration LOCK_TTL = Duration.ofSeconds(5);
    private static final Duration DISCONNECT_TTL = Duration.ofSeconds(45);

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    @Override
    public Optional<RoomMembership> findMembership(Long userId) {
        return readMembership(StudyRoomRedisKeys.currentRoom(userId));
    }

    @Override
    public RoomMembership joinRoom(Long roomId, Long userId, String nickname, List<Integer> availableSeatNos) {
        return withLocks(userId, roomId, () -> doJoinRoom(roomId, userId, nickname, availableSeatNos));
    }

    @Override
    public void leaveRoom(Long roomId, Long userId) {
        withLocks(userId, roomId, () -> {
            Optional<RoomMembership> membership = findMembership(userId);
            if (membership.isEmpty()) {
                return null;
            }
            RoomMembership current = membership.get();
            if (!roomId.equals(current.roomId())) {
                throw new BusinessException(ErrorCode.STUDY_ROOM_ALREADY_IN_OTHER_ROOM);
            }
            clearMembership(current);
            return null;
        });
    }

    @Override
    public RoomMembership changeState(Long roomId, Long userId, UserRoomState targetState) {
        return withLocks(userId, roomId, () -> {
            RoomMembership membership = requireMembership(roomId, userId);
            RoomMembership updated = new RoomMembership(roomId, userId, membership.seatNo(), membership.nickname(), targetState);
            saveMembership(updated);
            return updated;
        });
    }

    @Override
    public RoomMembership markDisconnected(Long roomId, Long userId, UserRoomState fallbackState, LocalDateTime expireAt) {
        return withLocks(userId, roomId, () -> {
            RoomMembership membership = requireMembership(roomId, userId);
            RoomMembership updated = new RoomMembership(roomId, userId, membership.seatNo(), membership.nickname(), UserRoomState.DISCONNECTED);
            saveMembership(updated);
            DisconnectMarker marker = new DisconnectMarker(roomId, userId, fallbackState, expireAt);
            writeJson(StudyRoomRedisKeys.disconnect(userId), marker, DISCONNECT_TTL);
            redisTemplate.opsForZSet().add(StudyRoomRedisKeys.disconnectIndex(), roomId + ":" + userId,
                    expireAt.toInstant(ZoneOffset.UTC).toEpochMilli());
            return updated;
        });
    }

    @Override
    public RoomMembership reconnect(Long roomId, Long userId) {
        return withLocks(userId, roomId, () -> {
            RoomMembership membership = requireMembership(roomId, userId);
            DisconnectMarker marker = readJson(StudyRoomRedisKeys.disconnect(userId), DisconnectMarker.class)
                    .orElse(new DisconnectMarker(roomId, userId, UserRoomState.FOCUSING, LocalDateTime.now()));
            RoomMembership updated = new RoomMembership(roomId, userId, membership.seatNo(), membership.nickname(), marker.previousState());
            saveMembership(updated);
            redisTemplate.delete(StudyRoomRedisKeys.disconnect(userId));
            redisTemplate.opsForZSet().remove(StudyRoomRedisKeys.disconnectIndex(), roomId + ":" + userId);
            return updated;
        });
    }

    @Override
    public RoomSnapshot snapshotRoom(Long roomId, List<Integer> allSeatNos) {
        Map<Object, Object> onlineEntries = redisTemplate.opsForHash().entries(StudyRoomRedisKeys.online(roomId));
        List<RoomMemberSnapshot> members = new ArrayList<>();
        for (Object value : onlineEntries.values()) {
            RoomMembership membership = readValue(String.valueOf(value), RoomMembership.class);
            members.add(new RoomMemberSnapshot(membership.userId(), membership.nickname(), membership.seatNo(), membership.state()));
        }
        members.sort(Comparator.comparing(RoomMemberSnapshot::seatNo));
        return new RoomSnapshot(roomId, members.size(), members);
    }

    @Override
    public TimerInfo startTimer(Long roomId, Long userId, int durationMinutes, LocalDateTime now) {
        return withLocks(userId, roomId, () -> {
            requireMembership(roomId, userId);
            Optional<TimerInfo> existing = getTimer(roomId, userId);
            if (existing.isPresent()) {
                return existing.get();
            }
            TimerInfo timerInfo = new TimerInfo(UUID.randomUUID().toString(), durationMinutes, now, now.plusMinutes(durationMinutes));
            writeJson(StudyRoomRedisKeys.userTimer(roomId, userId), timerInfo, null);
            return timerInfo;
        });
    }

    @Override
    public Optional<TimerInfo> getTimer(Long roomId, Long userId) {
        return readJson(StudyRoomRedisKeys.userTimer(roomId, userId), TimerInfo.class);
    }

    @Override
    public Optional<TimerInfo> finishTimer(Long roomId, Long userId, String sessionToken) {
        return withLocks(userId, roomId, () -> {
            Optional<TimerInfo> existing = getTimer(roomId, userId);
            if (existing.isEmpty()) {
                return Optional.<TimerInfo>empty();
            }
            TimerInfo timerInfo = existing.get();
            if (!timerInfo.sessionToken().equals(sessionToken)) {
                throw new BusinessException(ErrorCode.STUDY_ROOM_TIMER_INVALID, "timer session token mismatch");
            }
            redisTemplate.delete(StudyRoomRedisKeys.userTimer(roomId, userId));
            return Optional.of(timerInfo);
        });
    }

    @Override
    public List<ExpiredDisconnect> findExpiredDisconnects(LocalDateTime now) {
        long nowScore = now.toInstant(ZoneOffset.UTC).toEpochMilli();
        var values = redisTemplate.opsForZSet().rangeByScore(StudyRoomRedisKeys.disconnectIndex(), 0, nowScore);
        if (values == null || values.isEmpty()) {
            return List.of();
        }
        List<ExpiredDisconnect> expired = new ArrayList<>();
        for (String value : values) {
            String[] tokens = value.split(":");
            if (tokens.length == 2) {
                expired.add(new ExpiredDisconnect(Long.valueOf(tokens[0]), Long.valueOf(tokens[1])));
            }
        }
        return expired;
    }

    @Override
    public void clearExpiredDisconnect(Long roomId, Long userId) {
        redisTemplate.delete(StudyRoomRedisKeys.disconnect(userId));
        redisTemplate.opsForZSet().remove(StudyRoomRedisKeys.disconnectIndex(), roomId + ":" + userId);
    }

    private RoomMembership doJoinRoom(Long roomId, Long userId, String nickname, List<Integer> availableSeatNos) {
        Optional<RoomMembership> existing = findMembership(userId);
        if (existing.isPresent()) {
            RoomMembership membership = existing.get();
            if (roomId.equals(membership.roomId())) {
                return membership;
            }
            throw new BusinessException(ErrorCode.STUDY_ROOM_ALREADY_IN_OTHER_ROOM);
        }
        Map<Object, Object> occupiedSeats = redisTemplate.opsForHash().entries(StudyRoomRedisKeys.seats(roomId));
        int seatNo = availableSeatNos.stream()
                .filter(candidate -> !occupiedSeats.containsKey(String.valueOf(candidate)))
                .findFirst()
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_FULL));
        RoomMembership membership = new RoomMembership(roomId, userId, seatNo, nickname, UserRoomState.FOCUSING);
        saveMembership(membership);
        redisTemplate.opsForHash().put(StudyRoomRedisKeys.seats(roomId), String.valueOf(seatNo), String.valueOf(userId));
        return membership;
    }

    private RoomMembership requireMembership(Long roomId, Long userId) {
        RoomMembership membership = findMembership(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN, "user is not in any room"));
        if (!roomId.equals(membership.roomId())) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN, "user is not in target room");
        }
        return membership;
    }

    private void saveMembership(RoomMembership membership) {
        String payload = writeValue(membership);
        redisTemplate.opsForHash().put(StudyRoomRedisKeys.online(membership.roomId()), String.valueOf(membership.userId()), payload);
        redisTemplate.opsForValue().set(StudyRoomRedisKeys.userState(membership.roomId(), membership.userId()), membership.state().name());
        redisTemplate.opsForValue().set(StudyRoomRedisKeys.currentRoom(membership.userId()), payload);
    }

    private void clearMembership(RoomMembership membership) {
        redisTemplate.opsForHash().delete(StudyRoomRedisKeys.online(membership.roomId()), String.valueOf(membership.userId()));
        redisTemplate.opsForHash().delete(StudyRoomRedisKeys.seats(membership.roomId()), String.valueOf(membership.seatNo()));
        redisTemplate.delete(StudyRoomRedisKeys.userState(membership.roomId(), membership.userId()));
        redisTemplate.delete(StudyRoomRedisKeys.userTimer(membership.roomId(), membership.userId()));
        redisTemplate.delete(StudyRoomRedisKeys.currentRoom(membership.userId()));
        redisTemplate.delete(StudyRoomRedisKeys.disconnect(membership.userId()));
        redisTemplate.opsForZSet().remove(StudyRoomRedisKeys.disconnectIndex(), membership.roomId() + ":" + membership.userId());
    }

    private Optional<RoomMembership> readMembership(String key) {
        return readJson(key, RoomMembership.class);
    }

    private <T> Optional<T> readJson(String key, Class<T> type) {
        String payload = redisTemplate.opsForValue().get(key);
        if (payload == null || payload.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(readValue(payload, type));
    }

    private <T> T readValue(String payload, Class<T> type) {
        try {
            return objectMapper.readValue(payload, type);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "study room redis payload is invalid");
        }
    }

    private String writeValue(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "study room redis serialization failed");
        }
    }

    private void writeJson(String key, Object value, Duration ttl) {
        String payload = writeValue(value);
        if (ttl == null) {
            redisTemplate.opsForValue().set(key, payload);
        } else {
            redisTemplate.opsForValue().set(key, payload, ttl);
        }
    }

    private <T> T withLocks(Long userId, Long roomId, Supplier<T> supplier) {
        String userLockToken = acquireLock(StudyRoomRedisKeys.userLock(userId));
        String roomLockToken = acquireLock(StudyRoomRedisKeys.roomLock(roomId));
        try {
            return supplier.get();
        } finally {
            releaseLock(StudyRoomRedisKeys.roomLock(roomId), roomLockToken);
            releaseLock(StudyRoomRedisKeys.userLock(userId), userLockToken);
        }
    }

    private String acquireLock(String key) {
        String token = UUID.randomUUID().toString();
        Boolean acquired = redisTemplate.opsForValue().setIfAbsent(key, token, LOCK_TTL);
        if (Boolean.TRUE.equals(acquired)) {
            return token;
        }
        throw new BusinessException(ErrorCode.CONFLICT, "study room operation is busy, please retry");
    }

    private void releaseLock(String key, String token) {
        String currentToken = redisTemplate.opsForValue().get(key);
        if (token.equals(currentToken)) {
            redisTemplate.delete(key);
        }
    }

    private record DisconnectMarker(Long roomId,
                                    Long userId,
                                    UserRoomState previousState,
                                    LocalDateTime expireAt) {
    }
}
