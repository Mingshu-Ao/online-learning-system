package com.example.learning.studyroom.realtime;

import com.example.learning.studyroom.enums.UserRoomState;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface StudyRoomRealtimeStore {

    Optional<RoomMembership> findMembership(Long userId);

    RoomMembership joinRoom(Long roomId, Long userId, String nickname, List<Integer> availableSeatNos);

    void leaveRoom(Long roomId, Long userId);

    RoomMembership changeState(Long roomId, Long userId, UserRoomState targetState);

    RoomMembership markDisconnected(Long roomId, Long userId, UserRoomState fallbackState, LocalDateTime expireAt);

    RoomMembership reconnect(Long roomId, Long userId);

    RoomSnapshot snapshotRoom(Long roomId, List<Integer> allSeatNos);

    TimerInfo startTimer(Long roomId, Long userId, int durationMinutes, LocalDateTime now);

    Optional<TimerInfo> getTimer(Long roomId, Long userId);

    Optional<TimerInfo> finishTimer(Long roomId, Long userId, String sessionToken);

    List<ExpiredDisconnect> findExpiredDisconnects(LocalDateTime now);

    void clearExpiredDisconnect(Long roomId, Long userId);

    record RoomMembership(Long roomId,
                          Long userId,
                          Integer seatNo,
                          String nickname,
                          UserRoomState state) {
    }

    record RoomMemberSnapshot(Long userId,
                              String nickname,
                              Integer seatNo,
                              UserRoomState state) {
    }

    record RoomSnapshot(Long roomId,
                        long onlineCount,
                        List<RoomMemberSnapshot> members) {
    }

    record TimerInfo(String sessionToken,
                     int durationMinutes,
                     LocalDateTime startTime,
                     LocalDateTime endTime) {
    }

    record ExpiredDisconnect(Long roomId,
                             Long userId) {
    }
}
