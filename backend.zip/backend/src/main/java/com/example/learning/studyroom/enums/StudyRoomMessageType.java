package com.example.learning.studyroom.enums;

public enum StudyRoomMessageType {
    ROOM_JOIN,
    ROOM_LEAVE,
    ROOM_USER_STATE_CHANGE,
    ROOM_TIMER_START,
    ROOM_TIMER_PAUSE,
    ROOM_TIMER_FINISH,
    ROOM_HEARTBEAT,
    ROOM_RECONNECT,
    ROOM_ERROR
}
