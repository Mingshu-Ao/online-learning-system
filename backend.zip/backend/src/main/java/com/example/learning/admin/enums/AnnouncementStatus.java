package com.example.learning.admin.enums;

public enum AnnouncementStatus {
    DRAFT,
    PUBLISHED,
    OFFLINE
}
