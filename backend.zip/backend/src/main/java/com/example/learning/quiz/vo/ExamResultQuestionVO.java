package com.example.learning.quiz.vo;

import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExamResultQuestionVO {

    private Long questionId;
    private String stem;
    private String questionType;
    private BigDecimal fullScore;
    private BigDecimal awardedScore;
    private Boolean correct;
    private Boolean needsManualReview;
    private JsonNode userAnswer;
    private JsonNode standardAnswer;
    private String analysis;
    private List<QuestionOptionVO> options;
}
