package com.example.learning.course.dto;

import com.example.learning.course.enums.ResourceAccessType;
import com.example.learning.course.enums.ResourceType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ResourceUploadDTO {

    @NotNull(message = "courseId is required")
    private Long courseId;

    @NotNull(message = "chapterId is required")
    private Long chapterId;

    @NotBlank(message = "title is required")
    @Size(max = 128, message = "title length must be less than or equal to 128")
    private String title;

    @NotNull(message = "resourceType is required")
    private ResourceType resourceType;

    @NotNull(message = "accessType is required")
    private ResourceAccessType accessType;

    @NotBlank(message = "originalFileName is required")
    @Size(max = 255, message = "originalFileName length must be less than or equal to 255")
    private String originalFileName;

    @Size(max = 128, message = "mimeType length must be less than or equal to 128")
    private String mimeType;

    @NotNull(message = "fileSize is required")
    private Long fileSize;

    private Long durationSeconds;

    @Size(max = 255, message = "coverUrl length must be less than or equal to 255")
    private String coverUrl;
}
