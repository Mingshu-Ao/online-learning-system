package com.example.learning.service.impl;

import com.example.learning.service.SystemService;
import com.example.learning.vo.SystemStatusVO;
import org.springframework.stereotype.Service;

@Service
public class SystemServiceImpl implements SystemService {

    @Override
    public SystemStatusVO getSystemStatus() {
        return SystemStatusVO.builder()
                .serviceName("online-learning-backend")
                .version("0.0.1-SNAPSHOT")
                .status("UP")
                .build();
    }
}

