package com.example.learning.course.entity;

import com.example.learning.course.enums.CourseStatus;
import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "course")
@EqualsAndHashCode(callSuper = true)
public class CourseEntity extends BaseEntity {

    @Column(name = "title", nullable = false, length = 128)
    private String title;

    @Column(name = "summary", length = 500)
    private String summary;

    @Column(name = "cover_url", length = 255)
    private String coverUrl;

    @Column(name = "category", length = 64)
    private String category;

    @Column(name = "difficulty", length = 32)
    private String difficulty;

    @Column(name = "teacher_id", nullable = false)
    private Long teacherId;

    @Column(name = "teacher_name", nullable = false, length = 64)
    private String teacherName;

    @Column(name = "student_count", nullable = false)
    private Long studentCount;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private CourseStatus status;

    @Column(name = "review_comment", length = 500)
    private String reviewComment;
}
