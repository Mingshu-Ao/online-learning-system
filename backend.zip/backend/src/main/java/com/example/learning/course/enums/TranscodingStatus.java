package com.example.learning.course.enums;

public enum TranscodingStatus {
    NOT_REQUIRED,
    PENDING
}
