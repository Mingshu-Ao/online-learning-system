package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.common.vo.PageResultVO;
import com.example.learning.course.dto.CourseListQueryDTO;
import com.example.learning.course.service.CoursePublicService;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.course.vo.CourseListItemVO;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/courses")
public class CourseController {

    private final CoursePublicService coursePublicService;

    @GetMapping
    public ApiResponse<PageResultVO<CourseListItemVO>> listCourses(@Valid CourseListQueryDTO queryDTO) {
        return ApiResponse.success(coursePublicService.listPublishedCourses(queryDTO));
    }

    @GetMapping("/{id}")
    public ApiResponse<CourseDetailVO> getCourseDetail(@PathVariable Long id) {
        return ApiResponse.success(coursePublicService.getPublishedCourseDetail(id));
    }

    @GetMapping("/{courseId}/chapters")
    public ApiResponse<List<CourseChapterVO>> listCourseChapters(@PathVariable Long courseId) {
        return ApiResponse.success(coursePublicService.listPublishedCourseChapters(courseId));
    }
}
