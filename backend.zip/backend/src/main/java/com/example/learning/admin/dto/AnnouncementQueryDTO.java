package com.example.learning.admin.dto;

import com.example.learning.admin.enums.AnnouncementStatus;
import com.example.learning.admin.enums.AnnouncementVisibility;
import com.example.learning.common.dto.PageRequestDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AnnouncementQueryDTO extends PageRequestDTO {

    private String keyword;

    private AnnouncementStatus status;

    private AnnouncementVisibility visibility;
}
