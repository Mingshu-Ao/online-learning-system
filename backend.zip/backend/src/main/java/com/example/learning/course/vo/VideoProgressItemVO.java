package com.example.learning.course.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class VideoProgressItemVO {

    private Long resourceId;
    private Long chapterId;
    private String resourceTitle;
    private Long durationSeconds;
    private Long currentPosition;
    private Long effectiveStudySeconds;
    private Double progressPercent;
    private Boolean completed;
    private LocalDateTime lastStudyAt;
}
