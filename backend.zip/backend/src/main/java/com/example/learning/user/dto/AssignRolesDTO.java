package com.example.learning.user.dto;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
public class AssignRolesDTO {

    @NotEmpty(message = "roleIds cannot be empty")
    private List<Long> roleIds;
}
