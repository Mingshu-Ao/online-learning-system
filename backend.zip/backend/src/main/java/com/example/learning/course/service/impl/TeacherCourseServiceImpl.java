package com.example.learning.course.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.dto.CourseChapterCreateDTO;
import com.example.learning.course.dto.CourseChapterSortDTO;
import com.example.learning.course.dto.CourseChapterUpdateDTO;
import com.example.learning.course.dto.CourseCreateDTO;
import com.example.learning.course.dto.CourseUpdateDTO;
import com.example.learning.course.dto.ResourceUploadDTO;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.enums.TranscodingStatus;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.service.TeacherCourseService;
import com.example.learning.course.storage.FileStorageService;
import com.example.learning.course.storage.StoredFileInfo;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.course.vo.CourseResourceVO;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.mapper.UserMapper;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class TeacherCourseServiceImpl implements TeacherCourseService {

    private final CourseMapper courseMapper;
    private final CourseChapterMapper courseChapterMapper;
    private final CourseResourceMapper courseResourceMapper;
    private final UserMapper userMapper;
    private final FileStorageService fileStorageService;

    @Override
    @Transactional
    public CourseDetailVO createCourse(Long teacherId, CourseCreateDTO createDTO) {
        UserEntity teacher = getUser(teacherId);
        CourseEntity course = new CourseEntity();
        course.setTitle(createDTO.getTitle().trim());
        course.setSummary(trimToNull(createDTO.getSummary()));
        course.setCoverUrl(trimToNull(createDTO.getCoverUrl()));
        course.setCategory(trimToNull(createDTO.getCategory()));
        course.setDifficulty(trimToNull(createDTO.getDifficulty()));
        course.setTeacherId(teacherId);
        course.setTeacherName(resolveDisplayName(teacher));
        course.setStudentCount(0L);
        course.setStatus(CourseStatus.DRAFT);
        CourseEntity saved = courseMapper.save(course);
        return buildCourseDetail(saved);
    }

    @Override
    @Transactional
    public CourseDetailVO updateCourse(Long teacherId, Long courseId, CourseUpdateDTO updateDTO) {
        CourseEntity course = getOwnedCourse(teacherId, courseId);
        validateEditableCourseStatus(course);
        course.setTitle(updateDTO.getTitle().trim());
        course.setSummary(trimToNull(updateDTO.getSummary()));
        course.setCoverUrl(trimToNull(updateDTO.getCoverUrl()));
        course.setCategory(trimToNull(updateDTO.getCategory()));
        course.setDifficulty(trimToNull(updateDTO.getDifficulty()));
        if (course.getStatus() == CourseStatus.REJECTED || course.getStatus() == CourseStatus.OFFLINE) {
            course.setStatus(CourseStatus.DRAFT);
            course.setReviewComment(null);
        }
        CourseEntity saved = courseMapper.save(course);
        return buildCourseDetail(saved);
    }

    @Override
    @Transactional
    public CourseDetailVO submitReview(Long teacherId, Long courseId) {
        CourseEntity course = getOwnedCourse(teacherId, courseId);
        if (!(course.getStatus() == CourseStatus.DRAFT || course.getStatus() == CourseStatus.REJECTED || course.getStatus() == CourseStatus.OFFLINE)) {
            throw new BusinessException(ErrorCode.COURSE_STATUS_INVALID, "course cannot be submitted for review in current status");
        }
        course.setStatus(CourseStatus.PENDING);
        CourseEntity saved = courseMapper.save(course);
        return buildCourseDetail(saved);
    }

    @Override
    @Transactional
    public CourseChapterVO createChapter(Long teacherId, Long courseId, CourseChapterCreateDTO createDTO) {
        CourseEntity course = getOwnedCourse(teacherId, courseId);
        validateEditableCourseStatus(course);
        validateParentChapter(courseId, createDTO.getParentId());

        CourseChapterEntity chapter = new CourseChapterEntity();
        chapter.setCourseId(courseId);
        chapter.setParentId(createDTO.getParentId());
        chapter.setTitle(createDTO.getTitle().trim());
        chapter.setSortOrder(createDTO.getSortOrder());
        CourseChapterEntity saved = courseChapterMapper.save(chapter);
        return buildCourseChapter(saved);
    }

    @Override
    @Transactional
    public CourseChapterVO updateChapter(Long teacherId, Long chapterId, CourseChapterUpdateDTO updateDTO) {
        CourseChapterEntity chapter = courseChapterMapper.findByIdAndDeletedFalse(chapterId)
                .orElseThrow(() -> new BusinessException(ErrorCode.CHAPTER_NOT_FOUND));
        CourseEntity course = getOwnedCourse(teacherId, chapter.getCourseId());
        validateEditableCourseStatus(course);
        validateParentChapter(course.getId(), updateDTO.getParentId());

        chapter.setParentId(updateDTO.getParentId());
        chapter.setTitle(updateDTO.getTitle().trim());
        chapter.setSortOrder(updateDTO.getSortOrder());
        CourseChapterEntity saved = courseChapterMapper.save(chapter);
        return buildCourseChapter(saved);
    }

    @Override
    @Transactional
    public List<CourseChapterVO> sortChapters(Long teacherId, Long courseId, CourseChapterSortDTO sortDTO) {
        CourseEntity course = getOwnedCourse(teacherId, courseId);
        validateEditableCourseStatus(course);
        List<Long> chapterIds = sortDTO.getChapters().stream().map(item -> item.getChapterId()).toList();
        Set<Long> distinctIds = new HashSet<>(chapterIds);
        if (distinctIds.size() != chapterIds.size()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "chapterIds cannot contain duplicates");
        }
        List<CourseChapterEntity> chapters = courseChapterMapper.findAllByIdInAndDeletedFalse(chapterIds);
        if (chapters.size() != chapterIds.size()) {
            throw new BusinessException(ErrorCode.CHAPTER_NOT_FOUND);
        }
        for (CourseChapterEntity chapter : chapters) {
            if (!courseId.equals(chapter.getCourseId())) {
                throw new BusinessException(ErrorCode.CHAPTER_COURSE_MISMATCH);
            }
            Integer sortOrder = sortDTO.getChapters().stream()
                    .filter(item -> item.getChapterId().equals(chapter.getId()))
                    .findFirst()
                    .orElseThrow(() -> new BusinessException(ErrorCode.CHAPTER_NOT_FOUND))
                    .getSortOrder();
            chapter.setSortOrder(sortOrder);
        }
        courseChapterMapper.saveAll(chapters);
        return courseChapterMapper.findAllByCourseIdAndDeletedFalseOrderBySortOrderAscIdAsc(courseId)
                .stream()
                .map(this::buildCourseChapter)
                .toList();
    }

    @Override
    @Transactional
    public CourseResourceVO saveResourceMetadata(Long teacherId, ResourceUploadDTO uploadDTO) {
        CourseEntity course = getOwnedCourse(teacherId, uploadDTO.getCourseId());
        validateEditableCourseStatus(course);
        CourseChapterEntity chapter = courseChapterMapper.findByIdAndDeletedFalse(uploadDTO.getChapterId())
                .orElseThrow(() -> new BusinessException(ErrorCode.CHAPTER_NOT_FOUND));
        if (!course.getId().equals(chapter.getCourseId())) {
            throw new BusinessException(ErrorCode.CHAPTER_COURSE_MISMATCH);
        }

        StoredFileInfo storedFileInfo = fileStorageService.prepareStorage(uploadDTO.getOriginalFileName());
        CourseResourceEntity resource = new CourseResourceEntity();
        resource.setCourseId(course.getId());
        resource.setChapterId(chapter.getId());
        resource.setTitle(uploadDTO.getTitle().trim());
        resource.setResourceType(uploadDTO.getResourceType());
        resource.setAccessType(uploadDTO.getAccessType());
        resource.setOriginalFileName(uploadDTO.getOriginalFileName().trim());
        resource.setStoragePath(storedFileInfo.storagePath());
        resource.setFileUrl(storedFileInfo.accessUrl());
        resource.setMimeType(trimToNull(uploadDTO.getMimeType()));
        resource.setFileSize(uploadDTO.getFileSize());
        resource.setDurationSeconds(uploadDTO.getDurationSeconds());
        resource.setTranscodingStatus(uploadDTO.getResourceType() == ResourceType.VIDEO ? TranscodingStatus.PENDING : TranscodingStatus.NOT_REQUIRED);
        resource.setCoverUrl(trimToNull(uploadDTO.getCoverUrl()));
        CourseResourceEntity saved = courseResourceMapper.save(resource);
        return buildCourseResource(saved);
    }

    private CourseEntity getOwnedCourse(Long teacherId, Long courseId) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (!teacherId.equals(course.getTeacherId())) {
            throw new BusinessException(ErrorCode.COURSE_OWNER_REQUIRED);
        }
        return course;
    }

    private UserEntity getUser(Long userId) {
        return userMapper.findByIdAndDeletedFalse(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
    }

    private String resolveDisplayName(UserEntity user) {
        return StringUtils.hasText(user.getNickname()) ? user.getNickname() : user.getUsername();
    }

    private void validateEditableCourseStatus(CourseEntity course) {
        if (course.getStatus() == CourseStatus.PENDING || course.getStatus() == CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_STATUS_INVALID, "course cannot be edited in current status");
        }
    }

    private void validateParentChapter(Long courseId, Long parentId) {
        if (parentId == null) {
            return;
        }
        CourseChapterEntity parent = courseChapterMapper.findByIdAndDeletedFalse(parentId)
                .orElseThrow(() -> new BusinessException(ErrorCode.CHAPTER_NOT_FOUND));
        if (!courseId.equals(parent.getCourseId())) {
            throw new BusinessException(ErrorCode.CHAPTER_COURSE_MISMATCH);
        }
    }

    private CourseChapterVO buildCourseChapter(CourseChapterEntity chapter) {
        return CourseChapterVO.builder()
                .id(chapter.getId())
                .courseId(chapter.getCourseId())
                .parentId(chapter.getParentId())
                .title(chapter.getTitle())
                .sortOrder(chapter.getSortOrder())
                .resources(List.of())
                .build();
    }

    private CourseDetailVO buildCourseDetail(CourseEntity course) {
        return CourseDetailVO.builder()
                .id(course.getId())
                .title(course.getTitle())
                .summary(course.getSummary())
                .coverUrl(course.getCoverUrl())
                .category(course.getCategory())
                .difficulty(course.getDifficulty())
                .teacherId(course.getTeacherId())
                .teacherName(course.getTeacherName())
                .studentCount(course.getStudentCount())
                .status(course.getStatus().name())
                .reviewComment(course.getReviewComment())
                .chapters(List.of())
                .build();
    }

    private CourseResourceVO buildCourseResource(CourseResourceEntity resource) {
        return CourseResourceVO.builder()
                .id(resource.getId())
                .courseId(resource.getCourseId())
                .chapterId(resource.getChapterId())
                .title(resource.getTitle())
                .resourceType(resource.getResourceType().name())
                .accessType(resource.getAccessType().name())
                .fileUrl(resource.getFileUrl())
                .originalFileName(resource.getOriginalFileName())
                .mimeType(resource.getMimeType())
                .fileSize(resource.getFileSize())
                .durationSeconds(resource.getDurationSeconds())
                .transcodingStatus(resource.getTranscodingStatus().name())
                .coverUrl(resource.getCoverUrl())
                .build();
    }

    private String trimToNull(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return value.trim();
    }
}
