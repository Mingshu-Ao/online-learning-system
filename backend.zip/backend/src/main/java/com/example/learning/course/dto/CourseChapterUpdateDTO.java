package com.example.learning.course.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CourseChapterUpdateDTO {

    private Long parentId;

    @NotBlank(message = "title is required")
    @Size(max = 128, message = "title length must be less than or equal to 128")
    private String title;

    @NotNull(message = "sortOrder is required")
    private Integer sortOrder;
}
