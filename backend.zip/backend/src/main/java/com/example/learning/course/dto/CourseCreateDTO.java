package com.example.learning.course.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CourseCreateDTO {

    @NotBlank(message = "title is required")
    @Size(max = 128, message = "title length must be less than or equal to 128")
    private String title;

    @Size(max = 500, message = "summary length must be less than or equal to 500")
    private String summary;

    @Size(max = 255, message = "coverUrl length must be less than or equal to 255")
    private String coverUrl;

    @Size(max = 64, message = "category length must be less than or equal to 64")
    private String category;

    @Size(max = 32, message = "difficulty length must be less than or equal to 32")
    private String difficulty;
}
