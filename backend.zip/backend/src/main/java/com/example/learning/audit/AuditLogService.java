package com.example.learning.audit;

import com.example.learning.common.enums.ErrorCode;

public interface AuditLogService {

    void recordLogin(Long userId, String username, boolean success, String failureReason);

    void recordOperation(OperationLogCommand command);

    void recordResourceAccess(Long userId, Long courseId, Long resourceId, String resourceType);

    void recordException(Throwable throwable, ErrorCode errorCode, String errorMessage);

    record OperationLogCommand(Long operatorUserId,
                               String operatorUsername,
                               String action,
                               String targetType,
                               String targetId,
                               String requestSummary,
                               boolean success,
                               String errorMessage,
                               long durationMs,
                               String requestPath,
                               String httpMethod,
                               String ipAddress,
                               String userAgent) {
    }
}
