package com.example.learning.knowledge.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.knowledge.dto.KnowledgePointUpsertDTO;
import com.example.learning.knowledge.dto.KnowledgeRelationUpdateDTO;
import com.example.learning.knowledge.dto.KnowledgeResourceBindingDTO;
import com.example.learning.knowledge.dto.QuestionKnowledgeBindDTO;
import com.example.learning.knowledge.service.TeacherKnowledgeService;
import com.example.learning.knowledge.vo.KnowledgePointVO;
import com.example.learning.knowledge.vo.QuestionKnowledgeBindingVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher")
public class TeacherKnowledgeController {

    private final TeacherKnowledgeService teacherKnowledgeService;

    @PostMapping("/courses/{courseId}/knowledge-points")
    @PreAuthorize("hasAuthority('knowledge:create')")
    public ApiResponse<KnowledgePointVO> createKnowledgePoint(@PathVariable Long courseId,
                                                              @Valid @RequestBody KnowledgePointUpsertDTO upsertDTO) {
        return ApiResponse.success(teacherKnowledgeService.createKnowledgePoint(SecurityUtils.getCurrentUserId(), courseId, upsertDTO));
    }

    @PutMapping("/knowledge-points/{knowledgePointId}")
    @PreAuthorize("hasAuthority('knowledge:update')")
    public ApiResponse<KnowledgePointVO> updateKnowledgePoint(@PathVariable Long knowledgePointId,
                                                              @Valid @RequestBody KnowledgePointUpsertDTO upsertDTO) {
        return ApiResponse.success(teacherKnowledgeService.updateKnowledgePoint(SecurityUtils.getCurrentUserId(), knowledgePointId, upsertDTO));
    }

    @GetMapping("/courses/{courseId}/knowledge-points")
    @PreAuthorize("hasAuthority('knowledge:read')")
    public ApiResponse<List<KnowledgePointVO>> listKnowledgePoints(@PathVariable Long courseId) {
        return ApiResponse.success(teacherKnowledgeService.listKnowledgePoints(SecurityUtils.getCurrentUserId(), courseId));
    }

    @PutMapping("/knowledge-points/{knowledgePointId}/prerequisites")
    @PreAuthorize("hasAuthority('knowledge:update')")
    public ApiResponse<KnowledgePointVO> updatePrerequisites(@PathVariable Long knowledgePointId,
                                                             @Valid @RequestBody KnowledgeRelationUpdateDTO updateDTO) {
        return ApiResponse.success(teacherKnowledgeService.updatePrerequisites(SecurityUtils.getCurrentUserId(), knowledgePointId, updateDTO));
    }

    @PutMapping("/knowledge-points/{knowledgePointId}/resources")
    @PreAuthorize("hasAuthority('knowledge:update')")
    public ApiResponse<KnowledgePointVO> updateResources(@PathVariable Long knowledgePointId,
                                                         @Valid @RequestBody KnowledgeResourceBindingDTO bindingDTO) {
        return ApiResponse.success(teacherKnowledgeService.updateResources(SecurityUtils.getCurrentUserId(), knowledgePointId, bindingDTO));
    }

    @PutMapping("/questions/{questionId}/knowledge-point")
    @PreAuthorize("hasAuthority('knowledge:update')")
    public ApiResponse<QuestionKnowledgeBindingVO> bindQuestionKnowledgePoint(@PathVariable Long questionId,
                                                                              @Valid @RequestBody QuestionKnowledgeBindDTO bindDTO) {
        return ApiResponse.success(teacherKnowledgeService.bindQuestionKnowledgePoint(SecurityUtils.getCurrentUserId(), questionId, bindDTO));
    }
}
