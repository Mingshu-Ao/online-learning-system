package com.example.learning.knowledge.service;

import com.example.learning.knowledge.vo.LearningRecommendationVO;

public interface LearningRecommendationService {

    LearningRecommendationVO generateRecommendations(Long userId, Long courseId);
}
