package com.example.learning.knowledge.vo;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class QuestionKnowledgeBindingVO {
    Long questionId;
    Long knowledgePointId;
    String knowledgePointName;
}
