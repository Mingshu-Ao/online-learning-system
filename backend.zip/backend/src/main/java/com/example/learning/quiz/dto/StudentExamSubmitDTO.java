package com.example.learning.quiz.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import lombok.Data;

@Data
public class StudentExamSubmitDTO {

    @Valid
    @NotEmpty(message = "answers cannot be empty")
    private List<ExamAnswerItemDTO> answers;
}
