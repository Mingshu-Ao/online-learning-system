package com.example.learning.user.dto;

import com.example.learning.user.enums.UserStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateUserStatusDTO {

    @NotNull(message = "status is required")
    private UserStatus status;
}
