package com.example.learning.quiz.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExamStartVO {

    private Long examRecordId;
    private Long paperId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
}
