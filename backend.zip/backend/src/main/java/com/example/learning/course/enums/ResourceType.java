package com.example.learning.course.enums;

public enum ResourceType {
    VIDEO,
    PDF,
    PPT,
    IMAGE,
    LINK
}
