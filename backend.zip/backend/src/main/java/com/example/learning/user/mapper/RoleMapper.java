package com.example.learning.user.mapper;

import com.example.learning.user.entity.RoleEntity;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleMapper extends JpaRepository<RoleEntity, Long> {

    Optional<RoleEntity> findByCodeAndDeletedFalse(String code);

    List<RoleEntity> findAllByIdInAndDeletedFalse(Collection<Long> ids);
}
