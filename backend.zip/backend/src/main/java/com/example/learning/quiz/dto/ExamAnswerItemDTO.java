package com.example.learning.quiz.dto;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ExamAnswerItemDTO {

    @NotNull(message = "questionId cannot be null")
    private Long questionId;

    private JsonNode answer;
}
