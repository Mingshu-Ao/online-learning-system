package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.PaperQuestionEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaperQuestionMapper extends JpaRepository<PaperQuestionEntity, Long> {

    List<PaperQuestionEntity> findAllByPaperIdAndDeletedFalseOrderBySortOrderAsc(Long paperId);
}
