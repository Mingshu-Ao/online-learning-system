package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "paper")
@EqualsAndHashCode(callSuper = true)
public class PaperEntity extends BaseEntity {

    @Column(name = "title", nullable = false, length = 128)
    private String title;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "teacher_id", nullable = false)
    private Long teacherId;

    @Column(name = "total_score", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalScore;

    @Column(name = "pass_score", nullable = false, precision = 10, scale = 2)
    private BigDecimal passScore;

    @Column(name = "duration_minutes", nullable = false)
    private Integer durationMinutes;

    @Column(name = "allow_redo", nullable = false)
    private Boolean allowRedo;

    @Column(name = "max_attempts", nullable = false)
    private Integer maxAttempts;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "published", nullable = false)
    private Boolean published;
}
