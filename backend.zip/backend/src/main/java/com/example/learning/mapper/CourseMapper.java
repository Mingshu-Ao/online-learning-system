package com.example.learning.mapper;

import com.example.learning.dto.CourseQueryDTO;
import com.example.learning.entity.CourseEntity;
import java.util.List;

public interface CourseMapper {

    List<CourseEntity> selectPublicCourses(CourseQueryDTO queryDTO);
}

