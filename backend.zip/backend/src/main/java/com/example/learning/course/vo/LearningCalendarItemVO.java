package com.example.learning.course.vo;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LearningCalendarItemVO {

    private LocalDate date;
    private Long studySeconds;
    private Boolean active;
}
