package com.example.learning.studyroom.enums;

public enum UserRoomState {
    FOCUSING,
    BREAK,
    AWAY,
    DISCONNECTED,
    LEFT
}
