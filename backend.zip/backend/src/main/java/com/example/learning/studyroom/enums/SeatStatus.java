package com.example.learning.studyroom.enums;

public enum SeatStatus {
    EMPTY,
    OCCUPIED,
    LOCKED
}
