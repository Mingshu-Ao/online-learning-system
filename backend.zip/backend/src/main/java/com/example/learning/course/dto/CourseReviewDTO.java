package com.example.learning.course.dto;

import com.example.learning.course.enums.CourseReviewAction;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CourseReviewDTO {

    @NotNull(message = "action is required")
    private CourseReviewAction action;

    @Size(max = 500, message = "reviewComment length must be less than or equal to 500")
    private String reviewComment;
}
