package com.example.learning.knowledge.vo;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class WeakKnowledgePointVO {
    Long knowledgePointId;
    String knowledgePointName;
    Integer wrongCount;
}
