package com.example.learning.studyroom.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.studyroom.entity.RoomCheckinEntity;
import com.example.learning.studyroom.entity.RoomRecordEntity;
import com.example.learning.studyroom.entity.StudyRoomEntity;
import com.example.learning.studyroom.entity.StudyRoomSeatEntity;
import com.example.learning.studyroom.enums.RoomRecordStatus;
import com.example.learning.studyroom.enums.SeatStatus;
import com.example.learning.studyroom.enums.StudyRoomMessageType;
import com.example.learning.studyroom.enums.StudyRoomStatus;
import com.example.learning.studyroom.enums.UserRoomState;
import com.example.learning.studyroom.mapper.RoomCheckinMapper;
import com.example.learning.studyroom.mapper.RoomRecordMapper;
import com.example.learning.studyroom.mapper.StudyRoomMapper;
import com.example.learning.studyroom.mapper.StudyRoomSeatMapper;
import com.example.learning.studyroom.realtime.StudyRoomRealtimeStore;
import com.example.learning.studyroom.service.StudyRoomService;
import com.example.learning.studyroom.service.StudyRoomStateMachine;
import com.example.learning.studyroom.vo.StudyRoomJoinVO;
import com.example.learning.studyroom.vo.StudyRoomListItemVO;
import com.example.learning.studyroom.vo.StudyRoomSeatVO;
import com.example.learning.studyroom.vo.StudyRoomSnapshotVO;
import com.example.learning.studyroom.vo.StudyRoomWsEnvelopeVO;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.websocket.StudyRoomBroadcastService;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class StudyRoomServiceImpl implements StudyRoomService {

    private static final List<Integer> ALLOWED_TIMER_MINUTES = List.of(25, 45, 60);

    private final StudyRoomMapper studyRoomMapper;
    private final StudyRoomSeatMapper studyRoomSeatMapper;
    private final RoomRecordMapper roomRecordMapper;
    private final RoomCheckinMapper roomCheckinMapper;
    private final UserMapper userMapper;
    private final StudyRoomRealtimeStore realtimeStore;
    private final StudyRoomStateMachine stateMachine;
    private final StudyRoomBroadcastService broadcastService;
    private final Clock clock;

    @Override
    @Transactional
    public List<StudyRoomListItemVO> listRooms() {
        return studyRoomMapper.findAllByDeletedFalseOrderByIdAsc().stream()
                .map(room -> {
                    long onlineCount = realtimeStore.snapshotRoom(room.getId(), List.of()).onlineCount();
                    return StudyRoomListItemVO.builder()
                            .roomId(room.getId())
                            .roomName(room.getRoomName())
                            .capacity(room.getCapacity())
                            .currentOnlineCount(onlineCount)
                            .openTime(room.getOpenTime())
                            .closeTime(room.getCloseTime())
                            .status(resolveRuntimeStatus(room).name())
                            .build();
                })
                .toList();
    }

    @Override
    @Transactional
    public StudyRoomJoinVO joinRoom(Long userId, Long roomId) {
        StudyRoomEntity room = getOpenRoom(roomId);
        List<StudyRoomSeatEntity> seatEntities = ensureSeatDefinitions(room);
        List<Integer> availableSeatNos = seatEntities.stream()
                .filter(seat -> seat.getStatus() != SeatStatus.LOCKED)
                .map(StudyRoomSeatEntity::getSeatNo)
                .sorted()
                .toList();
        UserEntity user = userMapper.findByIdAndDeletedFalse(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));

        StudyRoomRealtimeStore.RoomMembership membership = realtimeStore.joinRoom(roomId, userId,
                user.getNickname() == null ? user.getUsername() : user.getNickname(), availableSeatNos);
        broadcastService.bindUserToRoom(userId, roomId);
        broadcastService.broadcastToRoom(roomId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_JOIN)
                .roomId(roomId)
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of(
                        "seatNo", membership.seatNo(),
                        "state", membership.state().name(),
                        "nickname", membership.nickname()))
                .build());
        return StudyRoomJoinVO.builder()
                .roomId(roomId)
                .seatNo(membership.seatNo())
                .state(membership.state().name())
                .build();
    }

    @Override
    @Transactional
    public void leaveRoom(Long userId, Long roomId) {
        Optional<StudyRoomRealtimeStore.RoomMembership> membership = realtimeStore.findMembership(userId);
        if (membership.isEmpty()) {
            return;
        }
        StudyRoomRealtimeStore.RoomMembership current = membership.get();
        if (!Objects.equals(current.roomId(), roomId)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_ALREADY_IN_OTHER_ROOM);
        }
        settleInterruptedTimer(current, LocalDateTime.now(clock));
        realtimeStore.leaveRoom(roomId, userId);
        broadcastService.unbindUserFromRoom(userId);
        broadcastService.broadcastToRoom(roomId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_LEAVE)
                .roomId(roomId)
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of("seatNo", current.seatNo(), "reason", "LEFT"))
                .build());
    }

    @Override
    @Transactional
    public StudyRoomSnapshotVO getSnapshot(Long roomId) {
        StudyRoomEntity room = studyRoomMapper.findByIdAndDeletedFalse(roomId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_NOT_FOUND));
        List<StudyRoomSeatEntity> seatEntities = ensureSeatDefinitions(room);
        StudyRoomRealtimeStore.RoomSnapshot snapshot = realtimeStore.snapshotRoom(roomId,
                seatEntities.stream().map(StudyRoomSeatEntity::getSeatNo).toList());
        Map<Integer, StudyRoomRealtimeStore.RoomMemberSnapshot> memberBySeat = new HashMap<>();
        snapshot.members().forEach(member -> memberBySeat.put(member.seatNo(), member));
        List<StudyRoomSeatVO> seats = seatEntities.stream()
                .sorted(Comparator.comparing(StudyRoomSeatEntity::getSeatNo))
                .map(seat -> {
                    StudyRoomRealtimeStore.RoomMemberSnapshot member = memberBySeat.get(seat.getSeatNo());
                    return StudyRoomSeatVO.builder()
                            .seatNo(seat.getSeatNo())
                            .userId(member == null ? null : member.userId())
                            .nickname(member == null ? null : member.nickname())
                            .state(member == null ? null : member.state().name())
                            .build();
                })
                .toList();
        return StudyRoomSnapshotVO.builder()
                .roomId(roomId)
                .onlineCount(snapshot.onlineCount())
                .seats(seats)
                .build();
    }

    @Override
    @Transactional
    public void changeUserState(Long userId, Long roomId, UserRoomState targetState) {
        StudyRoomRealtimeStore.RoomMembership current = realtimeStore.findMembership(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN));
        if (!Objects.equals(current.roomId(), roomId)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN);
        }
        stateMachine.assertTransition(current.state(), targetState);
        StudyRoomRealtimeStore.RoomMembership updated = realtimeStore.changeState(roomId, userId, targetState);
        broadcastService.broadcastToRoom(roomId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_USER_STATE_CHANGE)
                .roomId(roomId)
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of("state", updated.state().name(), "seatNo", updated.seatNo()))
                .build());
    }

    @Override
    @Transactional
    public void startTimer(Long userId, Long roomId, int durationMinutes) {
        if (!ALLOWED_TIMER_MINUTES.contains(durationMinutes)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_TIMER_INVALID, "durationMinutes must be one of 25, 45, 60");
        }
        StudyRoomRealtimeStore.RoomMembership current = realtimeStore.findMembership(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN));
        if (!Objects.equals(current.roomId(), roomId)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN);
        }
        if (current.state() != UserRoomState.FOCUSING) {
            stateMachine.assertTransition(current.state(), UserRoomState.FOCUSING);
            realtimeStore.changeState(roomId, userId, UserRoomState.FOCUSING);
        }
        StudyRoomRealtimeStore.TimerInfo timerInfo = realtimeStore.startTimer(roomId, userId, durationMinutes, LocalDateTime.now(clock));
        broadcastService.broadcastToRoom(roomId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_TIMER_START)
                .roomId(roomId)
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of(
                        "sessionToken", timerInfo.sessionToken(),
                        "durationMinutes", timerInfo.durationMinutes(),
                        "startTime", timerInfo.startTime(),
                        "endTime", timerInfo.endTime()))
                .build());
    }

    @Override
    @Transactional
    public void finishTimer(Long userId, Long roomId, String sessionToken) {
        StudyRoomRealtimeStore.RoomMembership membership = realtimeStore.findMembership(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN));
        if (!Objects.equals(membership.roomId(), roomId)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN);
        }
        Optional<StudyRoomRealtimeStore.TimerInfo> finished = realtimeStore.finishTimer(roomId, userId, sessionToken);
        if (finished.isEmpty()) {
            roomRecordMapper.findBySessionTokenAndDeletedFalse(sessionToken)
                    .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_TIMER_INVALID, "timer does not exist"));
            return;
        }
        StudyRoomRealtimeStore.TimerInfo timerInfo = finished.get();
        saveCompletedRecord(roomId, membership, timerInfo);
        broadcastService.broadcastToRoom(roomId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_TIMER_FINISH)
                .roomId(roomId)
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of(
                        "sessionToken", timerInfo.sessionToken(),
                        "focusMinutes", timerInfo.durationMinutes(),
                        "seatNo", membership.seatNo()))
                .build());
    }

    @Override
    @Transactional
    public void heartbeat(Long userId, Long roomId) {
        StudyRoomRealtimeStore.RoomMembership membership = realtimeStore.findMembership(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN));
        if (!Objects.equals(membership.roomId(), roomId)) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN);
        }
        if (membership.state() == UserRoomState.DISCONNECTED) {
            reconnect(userId, roomId);
        }
    }

    @Override
    @Transactional
    public void reconnect(Long userId, Long roomId) {
        StudyRoomRealtimeStore.RoomMembership restored = realtimeStore.reconnect(roomId, userId);
        broadcastService.bindUserToRoom(userId, roomId);
        broadcastService.broadcastToRoom(roomId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_RECONNECT)
                .roomId(roomId)
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of("state", restored.state().name(), "seatNo", restored.seatNo()))
                .build());
    }

    @Override
    public void handleSocketConnected(Long userId) {
        realtimeStore.findMembership(userId).ifPresent(membership -> broadcastService.bindUserToRoom(userId, membership.roomId()));
    }

    @Override
    @Transactional
    public void handleSocketDisconnected(Long userId) {
        Optional<StudyRoomRealtimeStore.RoomMembership> membership = realtimeStore.findMembership(userId);
        if (membership.isEmpty()) {
            return;
        }
        StudyRoomRealtimeStore.RoomMembership current = membership.get();
        if (current.state() == UserRoomState.DISCONNECTED || current.state() == UserRoomState.LEFT) {
            return;
        }
        StudyRoomRealtimeStore.RoomMembership disconnected = realtimeStore.markDisconnected(current.roomId(), userId,
                current.state(), LocalDateTime.now(clock).plusSeconds(45));
        broadcastService.broadcastToRoom(current.roomId(), StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_USER_STATE_CHANGE)
                .roomId(current.roomId())
                .senderId(userId)
                .timestamp(nowMillis())
                .payload(Map.of("state", disconnected.state().name(), "seatNo", disconnected.seatNo()))
                .build());
    }

    @Override
    @Scheduled(fixedDelay = 15000)
    @Transactional
    public void cleanupExpiredDisconnects() {
        try {
            LocalDateTime now = LocalDateTime.now(clock);
            for (StudyRoomRealtimeStore.ExpiredDisconnect expired : realtimeStore.findExpiredDisconnects(now)) {
                Optional<StudyRoomRealtimeStore.RoomMembership> membership = realtimeStore.findMembership(expired.userId());
                if (membership.isEmpty()) {
                    realtimeStore.clearExpiredDisconnect(expired.roomId(), expired.userId());
                    continue;
                }
                StudyRoomRealtimeStore.RoomMembership current = membership.get();
                if (current.state() != UserRoomState.DISCONNECTED) {
                    realtimeStore.clearExpiredDisconnect(expired.roomId(), expired.userId());
                    continue;
                }
                settleInterruptedTimer(current, now);
                realtimeStore.leaveRoom(expired.roomId(), expired.userId());
                broadcastService.unbindUserFromRoom(expired.userId());
                broadcastService.broadcastToRoom(expired.roomId(), StudyRoomWsEnvelopeVO.builder()
                        .type(StudyRoomMessageType.ROOM_LEAVE)
                        .roomId(expired.roomId())
                        .senderId(expired.userId())
                        .timestamp(nowMillis())
                        .payload(Map.of("seatNo", current.seatNo(), "reason", "DISCONNECT_TIMEOUT"))
                        .build());
            }
        } catch (Exception ex) {
            // Redis is the realtime source of truth for this module; when it is unavailable we degrade gracefully.
        }
    }

    private StudyRoomEntity getOpenRoom(Long roomId) {
        StudyRoomEntity room = studyRoomMapper.findByIdAndDeletedFalse(roomId)
                .orElseThrow(() -> new BusinessException(ErrorCode.STUDY_ROOM_NOT_FOUND));
        if (resolveRuntimeStatus(room) != StudyRoomStatus.OPEN) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_NOT_OPEN);
        }
        return room;
    }

    private StudyRoomStatus resolveRuntimeStatus(StudyRoomEntity room) {
        LocalDateTime now = LocalDateTime.now(clock);
        if (room.getStatus() != StudyRoomStatus.OPEN) {
            return StudyRoomStatus.CLOSED;
        }
        if (now.isBefore(room.getOpenTime()) || now.isAfter(room.getCloseTime())) {
            return StudyRoomStatus.CLOSED;
        }
        return StudyRoomStatus.OPEN;
    }

    private List<StudyRoomSeatEntity> ensureSeatDefinitions(StudyRoomEntity room) {
        List<StudyRoomSeatEntity> existing = studyRoomSeatMapper.findAllByRoomIdAndDeletedFalseOrderBySeatNoAsc(room.getId());
        if (existing.size() >= room.getCapacity()) {
            return existing;
        }
        Map<Integer, StudyRoomSeatEntity> bySeatNo = new HashMap<>();
        existing.forEach(seat -> bySeatNo.put(seat.getSeatNo(), seat));
        List<StudyRoomSeatEntity> toCreate = new ArrayList<>();
        for (int seatNo = 1; seatNo <= room.getCapacity(); seatNo++) {
            if (bySeatNo.containsKey(seatNo)) {
                continue;
            }
            StudyRoomSeatEntity seat = new StudyRoomSeatEntity();
            seat.setRoomId(room.getId());
            seat.setSeatNo(seatNo);
            seat.setStatus(SeatStatus.EMPTY);
            toCreate.add(seat);
        }
        if (!toCreate.isEmpty()) {
            studyRoomSeatMapper.saveAll(toCreate);
            existing = studyRoomSeatMapper.findAllByRoomIdAndDeletedFalseOrderBySeatNoAsc(room.getId());
        }
        return existing;
    }

    private void settleInterruptedTimer(StudyRoomRealtimeStore.RoomMembership membership, LocalDateTime now) {
        realtimeStore.getTimer(membership.roomId(), membership.userId())
                .ifPresent(timer -> saveInterruptedRecord(membership.roomId(), membership, timer, now));
    }

    private void saveCompletedRecord(Long roomId,
                                     StudyRoomRealtimeStore.RoomMembership membership,
                                     StudyRoomRealtimeStore.TimerInfo timerInfo) {
        RoomRecordEntity record = roomRecordMapper.findBySessionTokenAndDeletedFalse(timerInfo.sessionToken())
                .orElseGet(RoomRecordEntity::new);
        if (record.getId() == null) {
            record.setRoomId(roomId);
            record.setUserId(membership.userId());
            record.setSeatNo(membership.seatNo());
            record.setFocusMinutes(timerInfo.durationMinutes());
            record.setStartTime(timerInfo.startTime());
            record.setEndTime(timerInfo.endTime());
            record.setSessionToken(timerInfo.sessionToken());
            record.setStatus(RoomRecordStatus.COMPLETED);
            roomRecordMapper.save(record);
        }
        updateCheckin(roomId, membership.userId(), timerInfo.durationMinutes(), timerInfo.endTime());
    }

    private void saveInterruptedRecord(Long roomId,
                                       StudyRoomRealtimeStore.RoomMembership membership,
                                       StudyRoomRealtimeStore.TimerInfo timerInfo,
                                       LocalDateTime now) {
        if (roomRecordMapper.findBySessionTokenAndDeletedFalse(timerInfo.sessionToken()).isPresent()) {
            return;
        }
        long elapsedMinutes = Math.max(0L, Duration.between(timerInfo.startTime(), now.isAfter(timerInfo.endTime())
                ? timerInfo.endTime() : now).toMinutes());
        if (elapsedMinutes <= 0L) {
            return;
        }
        RoomRecordEntity record = new RoomRecordEntity();
        record.setRoomId(roomId);
        record.setUserId(membership.userId());
        record.setSeatNo(membership.seatNo());
        record.setFocusMinutes((int) elapsedMinutes);
        record.setStartTime(timerInfo.startTime());
        record.setEndTime(now.isAfter(timerInfo.endTime()) ? timerInfo.endTime() : now);
        record.setSessionToken(timerInfo.sessionToken());
        record.setStatus(RoomRecordStatus.INTERRUPTED);
        roomRecordMapper.save(record);
    }

    private void updateCheckin(Long roomId, Long userId, int focusMinutes, LocalDateTime checkinAt) {
        RoomCheckinEntity entity = roomCheckinMapper.findByRoomIdAndUserIdAndCheckinDateAndDeletedFalse(roomId, userId,
                        LocalDate.from(checkinAt))
                .orElseGet(RoomCheckinEntity::new);
        if (entity.getId() == null) {
            entity.setRoomId(roomId);
            entity.setUserId(userId);
            entity.setCheckinDate(LocalDate.from(checkinAt));
            entity.setTotalFocusMinutes(0);
            entity.setCompletedCount(0);
        }
        entity.setTotalFocusMinutes(entity.getTotalFocusMinutes() + focusMinutes);
        entity.setCompletedCount(entity.getCompletedCount() + 1);
        entity.setLastCheckinAt(checkinAt);
        roomCheckinMapper.save(entity);
    }

    private long nowMillis() {
        return clock.instant().toEpochMilli();
    }
}
