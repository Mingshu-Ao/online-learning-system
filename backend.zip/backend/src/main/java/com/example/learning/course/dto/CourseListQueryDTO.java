package com.example.learning.course.dto;

import com.example.learning.common.dto.PageRequestDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CourseListQueryDTO extends PageRequestDTO {

    private String keyword;
    private String category;
    private String difficulty;
}
