package com.example.learning.ai.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AiAskRequestDTO {

    @NotNull
    private Long courseId;

    @NotBlank
    private String question;
}
