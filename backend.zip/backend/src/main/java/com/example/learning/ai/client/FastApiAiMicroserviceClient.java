package com.example.learning.ai.client;

import com.example.learning.ai.config.AiServiceProperties;
import com.example.learning.ai.model.AiAnswerPayload;
import com.example.learning.ai.model.AiRecommendationPayload;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Component
@RequiredArgsConstructor
public class FastApiAiMicroserviceClient implements AiMicroserviceClient {

    private final @Qualifier("aiRestTemplate") RestTemplate restTemplate;
    private final AiServiceProperties aiServiceProperties;

    @Override
    public AiAnswerPayload ask(Long userId, Long courseId, String question) {
        try {
            AiResponse response = restTemplate.postForObject(aiServiceProperties.getBaseUrl() + "/ai/ask",
                    new AiAskRequest(userId, courseId, question), AiResponse.class);
            return mapResponse(response);
        } catch (ResourceAccessException ex) {
            throw new AiClientTimeoutException("ai service timed out", ex);
        } catch (RestClientException ex) {
            throw new AiClientUnavailableException("ai service is unavailable", ex);
        }
    }

    @Override
    public AiAnswerPayload solveImage(Long userId, Long courseId, MultipartFile image) {
        try {
            HttpHeaders partHeaders = new HttpHeaders();
            partHeaders.setContentType(MediaType.parseMediaType(Objects.requireNonNullElse(
                    image.getContentType(), MediaType.APPLICATION_OCTET_STREAM_VALUE)));
            partHeaders.setContentDisposition(ContentDisposition.formData()
                    .name("image")
                    .filename(Objects.requireNonNullElse(image.getOriginalFilename(), "question-image"))
                    .build());
            ByteArrayResource resource = new NamedByteArrayResource(image.getBytes(), image.getOriginalFilename());
            HttpEntity<ByteArrayResource> filePart = new HttpEntity<>(resource, partHeaders);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("user_id", userId);
            body.add("course_id", courseId);
            body.add("image", filePart);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
            AiResponse response = restTemplate.postForObject(aiServiceProperties.getBaseUrl() + "/ai/solve-image",
                    requestEntity, AiResponse.class);
            return mapResponse(response);
        } catch (IOException ex) {
            throw new AiClientUnavailableException("image payload could not be read", ex);
        } catch (ResourceAccessException ex) {
            throw new AiClientTimeoutException("ai service timed out", ex);
        } catch (RestClientException ex) {
            throw new AiClientUnavailableException("ai service is unavailable", ex);
        }
    }

    private AiAnswerPayload mapResponse(AiResponse response) {
        if (response == null) {
            throw new AiClientInvalidResponseException("ai response is empty");
        }
        AiAnswerPayload payload = new AiAnswerPayload();
        payload.setQuestionText(response.getQuestionText());
        payload.setKnowledgePoints(response.getKnowledgePoints() == null ? List.of() : response.getKnowledgePoints());
        payload.setDifficulty(response.getDifficulty());
        payload.setSolutionSteps(response.getSolutionSteps() == null ? List.of() : response.getSolutionSteps());
        payload.setMistakeAnalysis(response.getMistakeAnalysis());
        payload.setRecommendations(response.getRecommendations() == null ? List.of() : response.getRecommendations());
        if (!hasMeaningfulContent(payload)) {
            throw new AiClientInvalidResponseException("ai response does not contain meaningful content");
        }
        return payload;
    }

    private boolean hasMeaningfulContent(AiAnswerPayload payload) {
        return hasText(payload.getQuestionText())
                || !payload.getKnowledgePoints().isEmpty()
                || hasText(payload.getDifficulty())
                || !payload.getSolutionSteps().isEmpty()
                || hasText(payload.getMistakeAnalysis())
                || !payload.getRecommendations().isEmpty();
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    @Data
    private static class AiAskRequest {

        @JsonProperty("user_id")
        private final Long userId;

        @JsonProperty("course_id")
        private final Long courseId;

        private final String question;
    }

    @Data
    private static class AiResponse {

        @JsonProperty("question_text")
        private String questionText;

        @JsonProperty("knowledge_points")
        private List<String> knowledgePoints;

        private String difficulty;

        @JsonProperty("solution_steps")
        private List<String> solutionSteps;

        @JsonProperty("mistake_analysis")
        private String mistakeAnalysis;

        private List<AiRecommendationPayload> recommendations;
    }

    private static final class NamedByteArrayResource extends ByteArrayResource {

        private final String filename;

        private NamedByteArrayResource(byte[] byteArray, String filename) {
            super(byteArray);
            this.filename = filename;
        }

        @Override
        public String getFilename() {
            return filename == null || filename.isBlank() ? "question-image" : filename;
        }
    }
}
