package com.example.learning.user.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "user_role", uniqueConstraints = {
        @UniqueConstraint(name = "uk_user_role_pair", columnNames = {"user_id", "role_id"})
})
@EqualsAndHashCode(callSuper = true)
public class UserRoleEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "role_id", nullable = false)
    private Long roleId;
}
