package com.example.learning.course.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

@Data
public class VideoProgressReportDTO {

    @NotNull
    private Long courseId;

    @NotNull
    private Long chapterId;

    @NotNull
    private Long resourceId;

    @NotNull
    @PositiveOrZero
    private Long currentPosition;

    @NotNull
    @Positive
    private Long duration;

    @NotNull
    @DecimalMin(value = "0.5")
    @DecimalMax(value = "2.0")
    private Double playbackRate;

    @NotNull
    @Positive
    private Long clientTimestamp;
}
