package com.example.learning.user.mapper;

import com.example.learning.user.entity.UserRoleEntity;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRoleMapper extends JpaRepository<UserRoleEntity, Long> {

    List<UserRoleEntity> findAllByUserIdAndDeletedFalse(Long userId);

    List<UserRoleEntity> findAllByUserIdInAndDeletedFalse(Collection<Long> userIds);

    void deleteByUserId(Long userId);
}
