package com.example.learning.service.impl;

import com.example.learning.dto.CourseQueryDTO;
import com.example.learning.service.CourseService;
import com.example.learning.vo.CourseSimpleVO;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final com.example.learning.course.service.CoursePublicService coursePublicService;

    @Override
    public List<CourseSimpleVO> listPublicCourses(CourseQueryDTO queryDTO) {
        com.example.learning.course.dto.CourseListQueryDTO realQuery = new com.example.learning.course.dto.CourseListQueryDTO();
        realQuery.setKeyword(queryDTO.getKeyword());
        realQuery.setPageNum((int) queryDTO.getPageNum());
        realQuery.setPageSize((int) queryDTO.getPageSize());
        return coursePublicService.listPublishedCourses(realQuery)
                .getRecords()
                .stream()
                .map(item -> CourseSimpleVO.builder()
                        .id(item.getId())
                        .title(item.getTitle())
                        .summary(null)
                        .teacherName(item.getTeacherName())
                        .difficulty(item.getDifficulty())
                        .build())
                .toList();
    }
}
