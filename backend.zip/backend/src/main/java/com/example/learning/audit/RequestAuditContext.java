package com.example.learning.audit;

public record RequestAuditContext(String requestPath,
                                  String httpMethod,
                                  String ipAddress,
                                  String userAgent) {
}
