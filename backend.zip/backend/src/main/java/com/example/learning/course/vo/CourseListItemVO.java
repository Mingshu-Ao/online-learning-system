package com.example.learning.course.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseListItemVO {

    private Long id;
    private String title;
    private String coverUrl;
    private String teacherName;
    private String difficulty;
    private Long studentCount;
}
