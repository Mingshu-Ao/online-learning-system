package com.example.learning.course.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class VideoProgressReportVO {

    private Long resourceId;
    private Long currentPosition;
    private Long durationSeconds;
    private Long effectiveStudySeconds;
    private Double progressPercent;
    private Boolean completed;
}
