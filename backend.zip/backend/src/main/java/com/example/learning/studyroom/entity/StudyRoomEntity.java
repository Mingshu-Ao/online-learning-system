package com.example.learning.studyroom.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.studyroom.enums.StudyRoomStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "study_room")
@EqualsAndHashCode(callSuper = true)
public class StudyRoomEntity extends BaseEntity {

    @Column(name = "room_name", nullable = false, length = 128)
    private String roomName;

    @Column(name = "capacity", nullable = false)
    private Integer capacity;

    @Column(name = "course_id")
    private Long courseId;

    @Column(name = "open_time", nullable = false)
    private LocalDateTime openTime;

    @Column(name = "close_time", nullable = false)
    private LocalDateTime closeTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private StudyRoomStatus status;
}
