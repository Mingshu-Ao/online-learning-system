package com.example.learning.knowledge.mapper;

import com.example.learning.knowledge.entity.LearningRecommendationEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LearningRecommendationMapper extends JpaRepository<LearningRecommendationEntity, Long> {

    List<LearningRecommendationEntity> findAllByUserIdAndCourseIdAndBatchNoAndDeletedFalseOrderBySortOrderAsc(
            Long userId, Long courseId, String batchNo);
}
