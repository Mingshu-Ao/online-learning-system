package com.example.learning.knowledge.vo;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class LearningRecommendationItemVO {
    Long recommendationId;
    Long knowledgePointId;
    String knowledgePointName;
    String resourceType;
    Long resourceId;
    String resourceTitle;
    String reason;
    Boolean defaultRecommendation;
}
