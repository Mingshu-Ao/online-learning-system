package com.example.learning.quiz.vo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExamResultVO {

    private Long examRecordId;
    private Long paperId;
    private String status;
    private BigDecimal objectiveScore;
    private BigDecimal totalScore;
    private Boolean passed;
    private Boolean pendingReview;
    private LocalDateTime startTime;
    private LocalDateTime submitTime;
    private LocalDateTime deadlineTime;
    private List<ExamResultQuestionVO> questions;
}
