package com.example.learning.studyroom.dto;

import com.example.learning.studyroom.enums.StudyRoomMessageType;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

@Data
public class StudyRoomWsMessageDTO {

    private StudyRoomMessageType type;
    private Long roomId;
    private Long senderId;
    private Long timestamp;
    private JsonNode payload;
}
