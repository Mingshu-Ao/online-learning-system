package com.example.learning.studyroom.realtime;

final class StudyRoomRedisKeys {

    private StudyRoomRedisKeys() {
    }

    static String seats(Long roomId) {
        return "studyroom:" + roomId + ":seats";
    }

    static String online(Long roomId) {
        return "studyroom:" + roomId + ":online";
    }

    static String userState(Long roomId, Long userId) {
        return "studyroom:" + roomId + ":user:" + userId + ":state";
    }

    static String userTimer(Long roomId, Long userId) {
        return "studyroom:" + roomId + ":user:" + userId + ":timer";
    }

    static String currentRoom(Long userId) {
        return "studyroom:user:" + userId + ":current";
    }

    static String disconnect(Long userId) {
        return "studyroom:disconnect:" + userId;
    }

    static String disconnectIndex() {
        return "studyroom:disconnecting";
    }

    static String userLock(Long userId) {
        return "studyroom:lock:user:" + userId;
    }

    static String roomLock(Long roomId) {
        return "studyroom:lock:room:" + roomId;
    }
}
