package com.example.learning.user.enums;

public enum UserStatus {
    ENABLED,
    DISABLED
}
