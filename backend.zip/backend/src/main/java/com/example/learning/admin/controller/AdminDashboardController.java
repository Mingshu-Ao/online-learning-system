package com.example.learning.admin.controller;

import com.example.learning.admin.dto.AdminStatisticsQueryDTO;
import com.example.learning.admin.service.AdminDashboardService;
import com.example.learning.admin.vo.AdminDashboardVO;
import com.example.learning.admin.vo.AdminStatisticsVO;
import com.example.learning.common.response.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin")
public class AdminDashboardController {

    private final AdminDashboardService adminDashboardService;

    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('dashboard:read')")
    public ApiResponse<AdminDashboardVO> getDashboard() {
        return ApiResponse.success(adminDashboardService.getDashboard());
    }

    @GetMapping("/statistics")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('statistics:read')")
    public ApiResponse<AdminStatisticsVO> getStatistics(@Valid AdminStatisticsQueryDTO queryDTO) {
        return ApiResponse.success(adminDashboardService.getStatistics(queryDTO));
    }
}
