package com.example.learning.audit;

import com.example.learning.admin.entity.LoginLogEntity;
import com.example.learning.admin.entity.OperationLogEntity;
import com.example.learning.admin.entity.ResourceAccessLogEntity;
import com.example.learning.admin.entity.SystemErrorLogEntity;
import com.example.learning.admin.mapper.LoginLogMapper;
import com.example.learning.admin.mapper.OperationLogMapper;
import com.example.learning.admin.mapper.ResourceAccessLogMapper;
import com.example.learning.admin.mapper.SystemErrorLogMapper;
import com.example.learning.common.enums.ErrorCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogServiceImpl implements AuditLogService {

    private final LoginLogMapper loginLogMapper;
    private final OperationLogMapper operationLogMapper;
    private final ResourceAccessLogMapper resourceAccessLogMapper;
    private final SystemErrorLogMapper systemErrorLogMapper;
    private final AuditRequestContextExtractor requestContextExtractor;
    private final AuditSanitizer auditSanitizer;

    @Override
    public void recordLogin(Long userId, String username, boolean success, String failureReason) {
        try {
            RequestAuditContext context = requestContextExtractor.currentContext();
            LoginLogEntity entity = new LoginLogEntity();
            entity.setUserId(userId);
            entity.setUsername(truncate(username, 64));
            entity.setSuccess(success);
            entity.setFailureReason(truncate(failureReason, 255));
            entity.setRequestPath(defaultPath(context.requestPath()));
            entity.setIpAddress(truncate(context.ipAddress(), 64));
            entity.setUserAgent(truncate(context.userAgent(), 500));
            loginLogMapper.save(entity);
        } catch (Exception ex) {
            log.warn("failed to persist login log", ex);
        }
    }

    @Override
    public void recordOperation(OperationLogCommand command) {
        try {
            OperationLogEntity entity = new OperationLogEntity();
            entity.setOperatorUserId(command.operatorUserId());
            entity.setOperatorUsername(truncate(command.operatorUsername(), 64));
            entity.setAction(truncate(command.action(), 128));
            entity.setTargetType(truncate(command.targetType(), 64));
            entity.setTargetId(truncate(command.targetId(), 128));
            entity.setHttpMethod(truncate(command.httpMethod(), 16));
            entity.setRequestPath(truncate(command.requestPath(), 255));
            entity.setSuccess(command.success());
            entity.setRequestSummary(command.requestSummary());
            entity.setErrorMessage(truncate(command.errorMessage(), 500));
            entity.setDurationMs(command.durationMs());
            entity.setIpAddress(truncate(command.ipAddress(), 64));
            entity.setUserAgent(truncate(command.userAgent(), 500));
            operationLogMapper.save(entity);
        } catch (Exception ex) {
            log.warn("failed to persist operation log", ex);
        }
    }

    @Override
    public void recordResourceAccess(Long userId, Long courseId, Long resourceId, String resourceType) {
        try {
            RequestAuditContext context = requestContextExtractor.currentContext();
            ResourceAccessLogEntity entity = new ResourceAccessLogEntity();
            entity.setUserId(userId);
            entity.setCourseId(courseId);
            entity.setResourceId(resourceId);
            entity.setResourceType(truncate(resourceType, 32));
            entity.setRequestPath(defaultPath(context.requestPath()));
            entity.setIpAddress(truncate(context.ipAddress(), 64));
            entity.setUserAgent(truncate(context.userAgent(), 500));
            resourceAccessLogMapper.save(entity);
        } catch (Exception ex) {
            log.warn("failed to persist resource access log", ex);
        }
    }

    @Override
    public void recordException(Throwable throwable, ErrorCode errorCode, String errorMessage) {
        try {
            RequestAuditContext context = requestContextExtractor.currentContext();
            SystemErrorLogEntity entity = new SystemErrorLogEntity();
            entity.setUserId(resolveCurrentUserId());
            entity.setErrorCode(errorCode.getCode());
            entity.setExceptionClass(throwable.getClass().getName());
            entity.setErrorMessage(truncate(errorMessage, 500));
            entity.setHttpMethod(truncate(context.httpMethod(), 16));
            entity.setRequestPath(truncate(context.requestPath(), 255));
            entity.setRequestSummary(auditSanitizer.sanitize(requestContextExtractor.currentRequestBodySummary()));
            entity.setIpAddress(truncate(context.ipAddress(), 64));
            entity.setUserAgent(truncate(context.userAgent(), 500));
            systemErrorLogMapper.save(entity);
        } catch (Exception ex) {
            log.warn("failed to persist error log", ex);
        }
    }

    private Long resolveCurrentUserId() {
        try {
            return com.example.learning.security.SecurityUtils.getCurrentUserId();
        } catch (Exception ex) {
            return null;
        }
    }

    private String defaultPath(String value) {
        String path = truncate(value, 255);
        return path == null ? "/unknown" : path;
    }

    private String truncate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }
}
