package com.example.learning.ai.model;

import java.util.List;
import lombok.Data;

@Data
public class AiAnswerPayload {

    private String questionText;
    private List<String> knowledgePoints;
    private String difficulty;
    private List<String> solutionSteps;
    private String mistakeAnalysis;
    private List<AiRecommendationPayload> recommendations;
}
