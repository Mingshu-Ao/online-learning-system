package com.example.learning.ai.controller;

import com.example.learning.ai.dto.AiAskRequestDTO;
import com.example.learning.ai.service.AiAssistantService;
import com.example.learning.ai.vo.AiAssistantResponseVO;
import com.example.learning.ai.vo.AiConversationDetailVO;
import com.example.learning.ai.vo.AiConversationSummaryVO;
import com.example.learning.common.response.ApiResponse;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/ai")
public class StudentAiAssistantController {

    private final AiAssistantService aiAssistantService;

    @PostMapping("/ask")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<AiAssistantResponseVO> askQuestion(@Valid @RequestBody AiAskRequestDTO requestDTO) {
        return ApiResponse.success(aiAssistantService.askQuestion(SecurityUtils.getCurrentUserId(), requestDTO));
    }

    @PostMapping("/solve-image")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<AiAssistantResponseVO> solveImage(@RequestParam Long courseId,
                                                         @RequestParam MultipartFile image) {
        return ApiResponse.success(aiAssistantService.solveImage(SecurityUtils.getCurrentUserId(), courseId, image));
    }

    @GetMapping("/conversations")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<List<AiConversationSummaryVO>> listConversations() {
        return ApiResponse.success(aiAssistantService.listConversations(SecurityUtils.getCurrentUserId()));
    }

    @GetMapping("/conversations/{conversationId}")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<AiConversationDetailVO> getConversation(@PathVariable Long conversationId) {
        return ApiResponse.success(aiAssistantService.getConversation(SecurityUtils.getCurrentUserId(), conversationId));
    }
}
