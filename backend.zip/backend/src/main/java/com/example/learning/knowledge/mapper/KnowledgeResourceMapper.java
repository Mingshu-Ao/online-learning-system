package com.example.learning.knowledge.mapper;

import com.example.learning.knowledge.entity.KnowledgeResourceEntity;
import com.example.learning.knowledge.enums.KnowledgeResourceType;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KnowledgeResourceMapper extends JpaRepository<KnowledgeResourceEntity, Long> {

    List<KnowledgeResourceEntity> findAllByKnowledgePointIdInAndDeletedFalse(Collection<Long> knowledgePointIds);

    List<KnowledgeResourceEntity> findAllByKnowledgePointIdAndDeletedFalse(Long knowledgePointId);

    List<KnowledgeResourceEntity> findAllByResourceTypeAndResourceIdAndDeletedFalse(KnowledgeResourceType resourceType, Long resourceId);

    List<KnowledgeResourceEntity> findAllByResourceTypeAndResourceIdInAndDeletedFalse(KnowledgeResourceType resourceType, Collection<Long> resourceIds);
}
