package com.example.learning.admin.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OperationLogVO {

    private Long id;
    private Long operatorUserId;
    private String operatorUsername;
    private String action;
    private String targetType;
    private String targetId;
    private String httpMethod;
    private String requestPath;
    private Boolean success;
    private String requestSummary;
    private String errorMessage;
    private Long durationMs;
    private String ipAddress;
    private String userAgent;
    private LocalDateTime createdAt;
}
