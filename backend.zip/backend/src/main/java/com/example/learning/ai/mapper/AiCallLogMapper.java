package com.example.learning.ai.mapper;

import com.example.learning.ai.entity.AiCallLogEntity;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AiCallLogMapper extends JpaRepository<AiCallLogEntity, Long>, JpaSpecificationExecutor<AiCallLogEntity> {

    long countByDeletedFalseAndCreatedAtBetween(LocalDateTime start, LocalDateTime end);

    List<AiCallLogEntity> findAllByDeletedFalseAndCreatedAtBetween(LocalDateTime start, LocalDateTime end);
}
