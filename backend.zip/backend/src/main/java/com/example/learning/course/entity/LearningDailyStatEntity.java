package com.example.learning.course.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(
        name = "learning_daily_stat",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_learning_daily_stat_user_date", columnNames = {"user_id", "stat_date"})
        }
)
@EqualsAndHashCode(callSuper = true)
public class LearningDailyStatEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "stat_date", nullable = false)
    private LocalDate statDate;

    @Column(name = "total_study_seconds", nullable = false)
    private Long totalStudySeconds;

    @Column(name = "last_study_at", nullable = false)
    private LocalDateTime lastStudyAt;
}
