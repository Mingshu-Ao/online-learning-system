package com.example.learning.knowledge.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.knowledge.entity.KnowledgePointEntity;
import com.example.learning.knowledge.entity.KnowledgeRelationEntity;
import com.example.learning.knowledge.entity.KnowledgeResourceEntity;
import com.example.learning.knowledge.entity.LearningRecommendationEntity;
import com.example.learning.knowledge.enums.KnowledgeResourceType;
import com.example.learning.knowledge.mapper.KnowledgePointMapper;
import com.example.learning.knowledge.mapper.KnowledgeRelationMapper;
import com.example.learning.knowledge.mapper.KnowledgeResourceMapper;
import com.example.learning.knowledge.mapper.LearningRecommendationMapper;
import com.example.learning.knowledge.service.LearningRecommendationService;
import com.example.learning.knowledge.vo.LearningRecommendationItemVO;
import com.example.learning.knowledge.vo.LearningRecommendationVO;
import com.example.learning.knowledge.vo.WeakKnowledgePointVO;
import com.example.learning.quiz.entity.QuestionEntity;
import com.example.learning.quiz.entity.WrongQuestionEntity;
import com.example.learning.quiz.enums.WrongQuestionStatus;
import com.example.learning.quiz.mapper.QuestionMapper;
import com.example.learning.quiz.mapper.WrongQuestionMapper;
import jakarta.persistence.criteria.Predicate;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class LearningRecommendationServiceImpl implements LearningRecommendationService {

    private final CourseMapper courseMapper;
    private final CourseEnrollmentMapper courseEnrollmentMapper;
    private final KnowledgePointMapper knowledgePointMapper;
    private final KnowledgeRelationMapper knowledgeRelationMapper;
    private final KnowledgeResourceMapper knowledgeResourceMapper;
    private final LearningRecommendationMapper learningRecommendationMapper;
    private final WrongQuestionMapper wrongQuestionMapper;
    private final CourseChapterMapper courseChapterMapper;
    private final CourseResourceMapper courseResourceMapper;
    private final QuestionMapper questionMapper;
    private final Clock clock;

    @Override
    @Transactional
    public LearningRecommendationVO generateRecommendations(Long userId, Long courseId) {
        getAccessibleCourse(userId, courseId);
        List<KnowledgePointEntity> knowledgePoints = knowledgePointMapper.findAllByCourseIdAndDeletedFalseOrderByNameAsc(courseId);
        Map<Long, KnowledgePointEntity> knowledgePointMap = knowledgePoints.stream()
                .collect(Collectors.toMap(KnowledgePointEntity::getId, item -> item));
        List<WeakStat> weakStats = diagnoseWeakKnowledgePoints(userId, courseId, knowledgePoints);
        if (weakStats.isEmpty()) {
            return saveAndBuildDefaultRecommendations(userId, courseId);
        }

        List<WeakStat> prioritizedWeakStats = weakStats.stream()
                .sorted(Comparator.comparing(WeakStat::wrongCount).reversed().thenComparing(WeakStat::knowledgePointName))
                .limit(3)
                .toList();
        Map<Long, Integer> weakCountMap = prioritizedWeakStats.stream()
                .collect(Collectors.toMap(WeakStat::knowledgePointId, WeakStat::wrongCount));
        Set<Long> weakPointIds = prioritizedWeakStats.stream().map(WeakStat::knowledgePointId)
                .collect(Collectors.toCollection(LinkedHashSet::new));

        Map<Long, List<Long>> prerequisites = knowledgeRelationMapper.findAllByCourseIdAndDeletedFalse(courseId).stream()
                .collect(Collectors.groupingBy(KnowledgeRelationEntity::getKnowledgePointId,
                        Collectors.mapping(KnowledgeRelationEntity::getPrerequisiteId, Collectors.toList())));
        LinkedHashSet<Long> orderedKnowledgePointIds = new LinkedHashSet<>();
        for (Long weakPointId : weakPointIds) {
            appendKnowledgePath(weakPointId, prerequisites, orderedKnowledgePointIds, new LinkedHashSet<>());
        }

        List<KnowledgeResourceEntity> bindings = knowledgeResourceMapper.findAllByKnowledgePointIdInAndDeletedFalse(orderedKnowledgePointIds);
        List<ResourceDescriptor> descriptors = resolveDescriptors(courseId, bindings);
        List<ResourceDescriptor> sortedDescriptors = descriptors.stream()
                .sorted(Comparator.comparing(ResourceDescriptor::knowledgePointId)
                        .thenComparing(ResourceDescriptor::resourceType)
                        .thenComparing(ResourceDescriptor::resourceId))
                .toList();

        List<GeneratedRecommendation> generated = new ArrayList<>();
        Set<ResourceKey> deduplication = new LinkedHashSet<>();
        for (Long knowledgePointId : orderedKnowledgePointIds) {
            KnowledgePointEntity point = knowledgePointMap.get(knowledgePointId);
            if (point == null) {
                continue;
            }
            for (ResourceDescriptor descriptor : sortedDescriptors) {
                if (!Objects.equals(descriptor.knowledgePointId(), knowledgePointId)) {
                    continue;
                }
                ResourceKey key = new ResourceKey(descriptor.resourceType(), descriptor.resourceId());
                if (!deduplication.add(key)) {
                    continue;
                }
                boolean weak = weakCountMap.containsKey(knowledgePointId);
                String reason = weak
                        ? "你在“" + point.getName() + "”相关错题中累计出错 " + weakCountMap.get(knowledgePointId) + " 次，建议优先复习该资源。"
                        : "“" + point.getName() + "”是后续薄弱知识点的前置内容，建议先补齐基础。";
                generated.add(new GeneratedRecommendation(point.getId(), point.getName(), descriptor.resourceType(),
                        descriptor.resourceId(), descriptor.resourceTitle(), reason, false));
            }
        }

        if (generated.isEmpty()) {
            return saveAndBuildDefaultRecommendations(userId, courseId);
        }
        return saveRecommendations(userId, courseId, prioritizedWeakStats, generated);
    }

    private List<WeakStat> diagnoseWeakKnowledgePoints(Long userId, Long courseId, List<KnowledgePointEntity> knowledgePoints) {
        Map<String, Long> knowledgePointByName = knowledgePoints.stream()
                .collect(Collectors.toMap(KnowledgePointEntity::getName, KnowledgePointEntity::getId, (left, right) -> left, LinkedHashMap::new));
        List<WrongQuestionEntity> wrongQuestions = wrongQuestionMapper.findAllByUserIdAndDeletedFalseOrderByLastWrongAtDesc(userId).stream()
                .filter(item -> Objects.equals(item.getCourseId(), courseId))
                .filter(item -> item.getStatus() != WrongQuestionStatus.MASTERED)
                .toList();
        if (wrongQuestions.isEmpty()) {
            return List.of();
        }
        Set<Long> questionIds = wrongQuestions.stream().map(WrongQuestionEntity::getQuestionId).collect(Collectors.toSet());
        Map<Long, Long> knowledgePointByQuestionId = knowledgeResourceMapper
                .findAllByResourceTypeAndResourceIdInAndDeletedFalse(KnowledgeResourceType.QUESTION, questionIds).stream()
                .collect(Collectors.toMap(KnowledgeResourceEntity::getResourceId, KnowledgeResourceEntity::getKnowledgePointId,
                        (left, right) -> left, LinkedHashMap::new));

        Map<Long, Integer> wrongCountByKnowledgePoint = new HashMap<>();
        Map<Long, String> knowledgePointNames = knowledgePoints.stream()
                .collect(Collectors.toMap(KnowledgePointEntity::getId, KnowledgePointEntity::getName));
        for (WrongQuestionEntity wrongQuestion : wrongQuestions) {
            Long knowledgePointId = null;
            if (wrongQuestion.getKnowledgePoint() != null && !wrongQuestion.getKnowledgePoint().isBlank()) {
                knowledgePointId = knowledgePointByName.get(wrongQuestion.getKnowledgePoint());
            }
            if (knowledgePointId == null) {
                knowledgePointId = knowledgePointByQuestionId.get(wrongQuestion.getQuestionId());
            }
            if (knowledgePointId == null) {
                continue;
            }
            wrongCountByKnowledgePoint.merge(knowledgePointId, Math.max(1, wrongQuestion.getWrongCount()), Integer::sum);
        }
        return wrongCountByKnowledgePoint.entrySet().stream()
                .map(entry -> new WeakStat(entry.getKey(), knowledgePointNames.get(entry.getKey()), entry.getValue()))
                .toList();
    }

    private void appendKnowledgePath(Long knowledgePointId,
                                     Map<Long, List<Long>> prerequisites,
                                     LinkedHashSet<Long> orderedKnowledgePointIds,
                                     Set<Long> visiting) {
        if (!visiting.add(knowledgePointId)) {
            return;
        }
        for (Long prerequisiteId : prerequisites.getOrDefault(knowledgePointId, List.of())) {
            appendKnowledgePath(prerequisiteId, prerequisites, orderedKnowledgePointIds, visiting);
        }
        orderedKnowledgePointIds.add(knowledgePointId);
        visiting.remove(knowledgePointId);
    }

    private List<ResourceDescriptor> resolveDescriptors(Long courseId, List<KnowledgeResourceEntity> bindings) {
        if (bindings.isEmpty()) {
            return List.of();
        }
        Set<Long> chapterIds = new LinkedHashSet<>();
        Set<Long> resourceIds = new LinkedHashSet<>();
        Set<Long> questionIds = new LinkedHashSet<>();
        for (KnowledgeResourceEntity binding : bindings) {
            switch (binding.getResourceType()) {
                case CHAPTER -> chapterIds.add(binding.getResourceId());
                case VIDEO, DOCUMENT -> resourceIds.add(binding.getResourceId());
                case QUESTION -> questionIds.add(binding.getResourceId());
            }
        }

        Map<Long, CourseChapterEntity> chapterMap = courseChapterMapper.findAllByIdInAndDeletedFalse(chapterIds).stream()
                .filter(chapter -> Objects.equals(chapter.getCourseId(), courseId))
                .collect(Collectors.toMap(CourseChapterEntity::getId, item -> item));
        Map<Long, CourseResourceEntity> resourceMap = courseResourceMapper.findAllById(resourceIds).stream()
                .filter(resource -> !Boolean.TRUE.equals(resource.getDeleted()))
                .filter(resource -> Objects.equals(resource.getCourseId(), courseId))
                .collect(Collectors.toMap(CourseResourceEntity::getId, item -> item));
        List<QuestionEntity> questions = questionIds.isEmpty() ? List.of() : questionMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            predicates.add(root.get("id").in(questionIds));
            predicates.add(cb.equal(root.get("courseId"), courseId));
            return cb.and(predicates.toArray(Predicate[]::new));
        });
        Map<Long, QuestionEntity> questionMap = questions.stream().collect(Collectors.toMap(QuestionEntity::getId, item -> item));

        List<ResourceDescriptor> descriptors = new ArrayList<>();
        for (KnowledgeResourceEntity binding : bindings) {
            switch (binding.getResourceType()) {
                case CHAPTER -> {
                    CourseChapterEntity chapter = chapterMap.get(binding.getResourceId());
                    if (chapter != null) {
                        descriptors.add(new ResourceDescriptor(binding.getKnowledgePointId(), KnowledgeResourceType.CHAPTER,
                                chapter.getId(), chapter.getTitle()));
                    }
                }
                case VIDEO, DOCUMENT -> {
                    CourseResourceEntity resource = resourceMap.get(binding.getResourceId());
                    if (resource != null) {
                        KnowledgeResourceType resolvedType = resource.getResourceType() == ResourceType.VIDEO
                                ? KnowledgeResourceType.VIDEO : KnowledgeResourceType.DOCUMENT;
                        descriptors.add(new ResourceDescriptor(binding.getKnowledgePointId(), resolvedType,
                                resource.getId(), resource.getTitle()));
                    }
                }
                case QUESTION -> {
                    QuestionEntity question = questionMap.get(binding.getResourceId());
                    if (question != null) {
                        descriptors.add(new ResourceDescriptor(binding.getKnowledgePointId(), KnowledgeResourceType.QUESTION,
                                question.getId(), abbreviate(question.getStem(), 80)));
                    }
                }
            }
        }
        return descriptors;
    }

    private LearningRecommendationVO saveAndBuildDefaultRecommendations(Long userId, Long courseId) {
        List<GeneratedRecommendation> generated = buildDefaultRecommendations(courseId);
        return saveRecommendations(userId, courseId, List.of(), generated.isEmpty() ? List.of() : generated);
    }

    private List<GeneratedRecommendation> buildDefaultRecommendations(Long courseId) {
        List<GeneratedRecommendation> recommendations = new ArrayList<>();
        courseChapterMapper.findAllByCourseIdAndDeletedFalseOrderBySortOrderAscIdAsc(courseId).stream().findFirst()
                .ifPresent(chapter -> recommendations.add(new GeneratedRecommendation(null, null, KnowledgeResourceType.CHAPTER,
                        chapter.getId(), chapter.getTitle(), "学习数据不足，建议先从课程主线章节开始复习。", true)));
        courseResourceMapper.findAllByCourseIdAndDeletedFalse(courseId).stream()
                .filter(resource -> resource.getResourceType() == ResourceType.VIDEO)
                .sorted(Comparator.comparing(CourseResourceEntity::getId))
                .findFirst()
                .ifPresent(resource -> recommendations.add(new GeneratedRecommendation(null, null, KnowledgeResourceType.VIDEO,
                        resource.getId(), resource.getTitle(), "学习数据不足，建议先观看课程核心视频。", true)));
        courseResourceMapper.findAllByCourseIdAndDeletedFalse(courseId).stream()
                .filter(resource -> resource.getResourceType() != ResourceType.VIDEO)
                .sorted(Comparator.comparing(CourseResourceEntity::getId))
                .findFirst()
                .ifPresent(resource -> recommendations.add(new GeneratedRecommendation(null, null, KnowledgeResourceType.DOCUMENT,
                        resource.getId(), resource.getTitle(), "学习数据不足，建议先阅读课程配套文档。", true)));
        questionMapper.findAll((root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            predicates.add(cb.equal(root.get("courseId"), courseId));
            query.orderBy(cb.asc(root.get("id")));
            return cb.and(predicates.toArray(Predicate[]::new));
        }).stream().findFirst()
                .ifPresent(question -> recommendations.add(new GeneratedRecommendation(null, null, KnowledgeResourceType.QUESTION,
                        question.getId(), abbreviate(question.getStem(), 80), "学习数据不足，建议先做一道基础题热身。", true)));
        return recommendations;
    }

    private LearningRecommendationVO saveRecommendations(Long userId,
                                                         Long courseId,
                                                         List<WeakStat> weakStats,
                                                         List<GeneratedRecommendation> generated) {
        String batchNo = UUID.randomUUID().toString();
        LocalDateTime now = LocalDateTime.now(clock);
        List<LearningRecommendationEntity> entities = new ArrayList<>();
        for (int i = 0; i < generated.size(); i++) {
            GeneratedRecommendation recommendation = generated.get(i);
            LearningRecommendationEntity entity = new LearningRecommendationEntity();
            entity.setUserId(userId);
            entity.setCourseId(courseId);
            entity.setBatchNo(batchNo);
            entity.setKnowledgePointId(recommendation.knowledgePointId());
            entity.setKnowledgePointName(recommendation.knowledgePointName());
            entity.setResourceType(recommendation.resourceType());
            entity.setResourceId(recommendation.resourceId());
            entity.setResourceTitle(recommendation.resourceTitle());
            entity.setReason(recommendation.reason());
            entity.setSortOrder(i + 1);
            entity.setDefaultRecommendation(recommendation.defaultRecommendation());
            entities.add(entity);
        }
        List<LearningRecommendationEntity> saved = learningRecommendationMapper.saveAll(entities);
        boolean defaultRecommendation = saved.isEmpty() || saved.stream().allMatch(item -> Boolean.TRUE.equals(item.getDefaultRecommendation()));
        return LearningRecommendationVO.builder()
                .courseId(courseId)
                .batchNo(batchNo)
                .defaultRecommendation(defaultRecommendation)
                .generatedAt(now)
                .weakKnowledgePoints(weakStats.stream()
                        .map(item -> WeakKnowledgePointVO.builder()
                                .knowledgePointId(item.knowledgePointId())
                                .knowledgePointName(item.knowledgePointName())
                                .wrongCount(item.wrongCount())
                                .build())
                        .toList())
                .recommendations(saved.stream()
                        .map(item -> LearningRecommendationItemVO.builder()
                                .recommendationId(item.getId())
                                .knowledgePointId(item.getKnowledgePointId())
                                .knowledgePointName(item.getKnowledgePointName())
                                .resourceType(item.getResourceType().name())
                                .resourceId(item.getResourceId())
                                .resourceTitle(item.getResourceTitle())
                                .reason(item.getReason())
                                .defaultRecommendation(item.getDefaultRecommendation())
                                .build())
                        .toList())
                .build();
    }

    private CourseEntity getAccessibleCourse(Long userId, Long courseId) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (course.getStatus() != CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_NOT_PUBLISHED);
        }
        if (!courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(courseId, userId)) {
            throw new BusinessException(ErrorCode.USER_NOT_ENROLLED);
        }
        return course;
    }

    private String abbreviate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }

    private record WeakStat(Long knowledgePointId, String knowledgePointName, Integer wrongCount) {
    }

    private record ResourceDescriptor(Long knowledgePointId,
                                      KnowledgeResourceType resourceType,
                                      Long resourceId,
                                      String resourceTitle) {
    }

    private record GeneratedRecommendation(Long knowledgePointId,
                                           String knowledgePointName,
                                           KnowledgeResourceType resourceType,
                                           Long resourceId,
                                           String resourceTitle,
                                           String reason,
                                           boolean defaultRecommendation) {
    }

    private record ResourceKey(KnowledgeResourceType resourceType, Long resourceId) {
    }
}
