package com.example.learning.ai.mapper;

import com.example.learning.ai.entity.AiConversationEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AiConversationMapper extends JpaRepository<AiConversationEntity, Long> {

    List<AiConversationEntity> findAllByUserIdAndDeletedFalseOrderByLastMessageAtDescIdDesc(Long userId);

    Optional<AiConversationEntity> findByIdAndUserIdAndDeletedFalse(Long id, Long userId);
}
