package com.example.learning.knowledge.vo;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class KnowledgePointVO {
    Long knowledgePointId;
    Long courseId;
    String name;
    String description;
    List<Long> prerequisiteIds;
    List<KnowledgeResourceBindingVO> bindings;
}
