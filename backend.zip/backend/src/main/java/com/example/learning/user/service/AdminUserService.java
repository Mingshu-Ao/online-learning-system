package com.example.learning.user.service;

import com.example.learning.common.vo.PageResultVO;
import com.example.learning.user.dto.AssignRolesDTO;
import com.example.learning.user.dto.ResetPasswordDTO;
import com.example.learning.user.dto.UpdateUserStatusDTO;
import com.example.learning.user.dto.UserQueryDTO;
import com.example.learning.user.vo.UserListItemVO;
import com.example.learning.user.vo.UserProfileVO;

public interface AdminUserService {

    PageResultVO<UserListItemVO> listUsers(UserQueryDTO queryDTO);

    void updateUserStatus(Long userId, UpdateUserStatusDTO updateUserStatusDTO);

    void resetPassword(Long userId, ResetPasswordDTO resetPasswordDTO);

    UserProfileVO assignRoles(Long operatorUserId, Long userId, AssignRolesDTO assignRolesDTO);
}
