package com.example.learning.quiz.vo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaperDetailVO {

    private Long id;
    private String title;
    private Long courseId;
    private BigDecimal totalScore;
    private BigDecimal passScore;
    private Integer durationMinutes;
    private Boolean allowRedo;
    private Integer maxAttempts;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Boolean published;
    private List<PaperQuestionVO> questions;
}
