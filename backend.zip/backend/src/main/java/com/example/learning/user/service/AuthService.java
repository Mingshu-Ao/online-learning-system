package com.example.learning.user.service;

import com.example.learning.user.dto.AuthLoginDTO;
import com.example.learning.user.dto.AuthRegisterDTO;
import com.example.learning.user.vo.LoginVO;
import com.example.learning.user.vo.UserProfileVO;

public interface AuthService {

    UserProfileVO register(AuthRegisterDTO registerDTO);

    LoginVO login(AuthLoginDTO loginDTO);

    void logout(Long currentUserId);
}
