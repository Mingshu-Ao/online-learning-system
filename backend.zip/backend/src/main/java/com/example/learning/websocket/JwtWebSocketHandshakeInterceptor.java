package com.example.learning.websocket;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.security.JwtTokenProvider;
import com.example.learning.security.SecurityUser;
import com.example.learning.security.SecurityUserDetailsService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@RequiredArgsConstructor
public class JwtWebSocketHandshakeInterceptor implements HandshakeInterceptor {

    static final String SECURITY_USER_ATTR = "studyRoomSecurityUser";

    private final JwtTokenProvider jwtTokenProvider;
    private final SecurityUserDetailsService securityUserDetailsService;

    @Override
    public boolean beforeHandshake(ServerHttpRequest request,
                                   ServerHttpResponse response,
                                   WebSocketHandler wsHandler,
                                   Map<String, Object> attributes) {
        try {
            String token = UriComponentsBuilder.fromUri(request.getURI()).build().getQueryParams().getFirst("token");
            if (token == null || token.isBlank()) {
                response.setStatusCode(HttpStatus.UNAUTHORIZED);
                return false;
            }
            Long userId = jwtTokenProvider.getUserId(token);
            Integer tokenVersion = jwtTokenProvider.getTokenVersion(token);
            SecurityUser securityUser = securityUserDetailsService.loadUserById(userId);
            if (!securityUser.getTokenVersion().equals(tokenVersion) || !securityUser.isEnabled()) {
                throw new BusinessException(ErrorCode.TOKEN_INVALID);
            }
            attributes.put(SECURITY_USER_ATTR, securityUser);
            return true;
        } catch (Exception ex) {
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            return false;
        }
    }

    @Override
    public void afterHandshake(ServerHttpRequest request,
                               ServerHttpResponse response,
                               WebSocketHandler wsHandler,
                               Exception exception) {
    }
}
