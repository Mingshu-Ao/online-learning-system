package com.example.learning.admin.mapper;

import com.example.learning.admin.entity.LoginLogEntity;
import java.time.LocalDateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LoginLogMapper extends JpaRepository<LoginLogEntity, Long>, JpaSpecificationExecutor<LoginLogEntity> {

    @Query("""
            select count(distinct l.userId)
            from LoginLogEntity l
            where l.deleted = false
              and l.success = true
              and l.userId is not null
              and l.createdAt between :start and :end
            """)
    long countDistinctActiveUsers(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}
