package com.example.learning.course.vo;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseChapterVO {

    private Long id;
    private Long courseId;
    private Long parentId;
    private String title;
    private Integer sortOrder;
    private List<CourseResourceVO> resources;
}
