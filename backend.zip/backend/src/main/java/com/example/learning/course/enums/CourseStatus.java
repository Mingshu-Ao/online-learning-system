package com.example.learning.course.enums;

public enum CourseStatus {
    DRAFT,
    PENDING,
    PUBLISHED,
    REJECTED,
    OFFLINE
}
