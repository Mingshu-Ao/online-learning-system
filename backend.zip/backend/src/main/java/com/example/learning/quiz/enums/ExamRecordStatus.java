package com.example.learning.quiz.enums;

public enum ExamRecordStatus {
    IN_PROGRESS,
    PENDING_REVIEW,
    COMPLETED,
    EXPIRED
}
