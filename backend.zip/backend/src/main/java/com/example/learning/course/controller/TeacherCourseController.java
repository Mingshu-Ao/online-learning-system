package com.example.learning.course.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.course.dto.CourseChapterCreateDTO;
import com.example.learning.course.dto.CourseChapterSortDTO;
import com.example.learning.course.dto.CourseCreateDTO;
import com.example.learning.course.dto.CourseUpdateDTO;
import com.example.learning.course.service.TeacherCourseService;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.security.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher/courses")
public class TeacherCourseController {

    private final TeacherCourseService teacherCourseService;

    @PostMapping
    @PreAuthorize("hasAuthority('course:create')")
    public ApiResponse<CourseDetailVO> createCourse(@Valid @RequestBody CourseCreateDTO createDTO) {
        return ApiResponse.success(teacherCourseService.createCourse(SecurityUtils.getCurrentUserId(), createDTO));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('course:update')")
    public ApiResponse<CourseDetailVO> updateCourse(@PathVariable Long id,
                                                    @Valid @RequestBody CourseUpdateDTO updateDTO) {
        return ApiResponse.success(teacherCourseService.updateCourse(SecurityUtils.getCurrentUserId(), id, updateDTO));
    }

    @PostMapping("/{id}/submit-review")
    @PreAuthorize("hasAuthority('course:submit-review')")
    public ApiResponse<CourseDetailVO> submitReview(@PathVariable Long id) {
        return ApiResponse.success(teacherCourseService.submitReview(SecurityUtils.getCurrentUserId(), id));
    }

    @PostMapping("/{courseId}/chapters")
    @PreAuthorize("hasAuthority('chapter:manage')")
    public ApiResponse<CourseChapterVO> createChapter(@PathVariable Long courseId,
                                                      @Valid @RequestBody CourseChapterCreateDTO createDTO) {
        return ApiResponse.success(teacherCourseService.createChapter(SecurityUtils.getCurrentUserId(), courseId, createDTO));
    }

    @PutMapping("/{courseId}/chapters/sort")
    @PreAuthorize("hasAuthority('chapter:manage')")
    public ApiResponse<List<CourseChapterVO>> sortChapters(@PathVariable Long courseId,
                                                           @Valid @RequestBody CourseChapterSortDTO sortDTO) {
        return ApiResponse.success(teacherCourseService.sortChapters(SecurityUtils.getCurrentUserId(), courseId, sortDTO));
    }
}
