package com.example.learning.admin.entity;

import com.example.learning.admin.enums.AnnouncementStatus;
import com.example.learning.admin.enums.AnnouncementVisibility;
import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "announcement")
@EqualsAndHashCode(callSuper = true)
public class AnnouncementEntity extends BaseEntity {

    @Column(name = "title", nullable = false, length = 200)
    private String title;

    @Lob
    @Column(name = "content", nullable = false)
    private String content;

    @Enumerated(EnumType.STRING)
    @Column(name = "visibility", nullable = false, length = 32)
    private AnnouncementVisibility visibility;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private AnnouncementStatus status;

    @Column(name = "publish_at")
    private LocalDateTime publishAt;
}
