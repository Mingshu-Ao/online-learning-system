package com.example.learning.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CourseEntity extends BaseEntity {

    private String title;
    private String summary;
    private String teacherName;
    private String difficulty;
    private String status;
}

