package com.example.learning.studyroom.vo;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StudyRoomSnapshotVO {

    private Long roomId;
    private Long onlineCount;
    private List<StudyRoomSeatVO> seats;
}
