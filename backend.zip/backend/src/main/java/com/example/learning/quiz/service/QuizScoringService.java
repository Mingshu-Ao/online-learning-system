package com.example.learning.quiz.service;

import com.example.learning.quiz.entity.PaperQuestionEntity;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;

public interface QuizScoringService {

    ScoringResult score(PaperQuestionEntity paperQuestion, JsonNode answerNode);

    record ScoringResult(BigDecimal awardedScore,
                         Boolean correct,
                         boolean autoGraded,
                         boolean needsManualReview) {
    }
}
