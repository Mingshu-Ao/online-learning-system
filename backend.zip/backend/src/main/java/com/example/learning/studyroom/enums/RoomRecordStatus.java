package com.example.learning.studyroom.enums;

public enum RoomRecordStatus {
    COMPLETED,
    INTERRUPTED
}
