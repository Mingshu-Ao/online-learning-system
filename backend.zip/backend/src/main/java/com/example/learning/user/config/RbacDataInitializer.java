package com.example.learning.user.config;

import com.example.learning.user.entity.PermissionEntity;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.RolePermissionEntity;
import com.example.learning.user.enums.RoleCode;
import com.example.learning.user.mapper.PermissionMapper;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.RolePermissionMapper;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
public class RbacDataInitializer implements ApplicationRunner {

    private final RoleMapper roleMapper;
    private final PermissionMapper permissionMapper;
    private final RolePermissionMapper rolePermissionMapper;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        RoleEntity studentRole = ensureRole(RoleCode.STUDENT.name(), "Student", "Student role");
        RoleEntity teacherRole = ensureRole(RoleCode.TEACHER.name(), "Teacher", "Teacher role");
        RoleEntity adminRole = ensureRole(RoleCode.ADMIN.name(), "Admin", "Admin role");

        PermissionEntity readUser = ensurePermission("user:read", "Read Users", "API", "/api/admin/users", "GET");
        PermissionEntity disableUser = ensurePermission("user:disable", "Disable User", "API", "/api/admin/users/{id}/status", "PUT");
        PermissionEntity resetPassword = ensurePermission("user:reset-password", "Reset Password", "API", "/api/admin/users/{id}/reset-password", "PUT");
        PermissionEntity assignRole = ensurePermission("user:assign-role", "Assign Role", "API", "/api/admin/users/{id}/roles", "PUT");
        PermissionEntity createCourse = ensurePermission("course:create", "Create Course", "API", "/api/teacher/courses", "POST");
        PermissionEntity updateCourse = ensurePermission("course:update", "Update Course", "API", "/api/teacher/courses/{id}", "PUT");
        PermissionEntity submitReview = ensurePermission("course:submit-review", "Submit Course Review", "API", "/api/teacher/courses/{id}/submit-review", "POST");
        PermissionEntity manageChapter = ensurePermission("chapter:manage", "Manage Chapter", "API", "/api/teacher/courses/{courseId}/chapters", "POST");
        PermissionEntity uploadResource = ensurePermission("resource:upload", "Upload Resource Metadata", "API", "/api/teacher/resources/upload", "POST");
        PermissionEntity reviewCourse = ensurePermission("course:review", "Review Course", "API", "/api/admin/courses/{id}/review", "POST");
        PermissionEntity createQuestion = ensurePermission("question:create", "Create Question", "API", "/api/teacher/questions", "POST");
        PermissionEntity updateQuestion = ensurePermission("question:update", "Update Question", "API", "/api/teacher/questions/{id}", "PUT");
        PermissionEntity readQuestion = ensurePermission("question:read", "Read Question", "API", "/api/teacher/questions", "GET");
        PermissionEntity createPaper = ensurePermission("paper:create", "Create Paper", "API", "/api/teacher/papers", "POST");
        PermissionEntity createKnowledge = ensurePermission("knowledge:create", "Create Knowledge Point", "API", "/api/teacher/courses/{courseId}/knowledge-points", "POST");
        PermissionEntity updateKnowledge = ensurePermission("knowledge:update", "Update Knowledge Point", "API", "/api/teacher/knowledge-points/{knowledgePointId}", "PUT");
        PermissionEntity readKnowledge = ensurePermission("knowledge:read", "Read Knowledge Point", "API", "/api/teacher/courses/{courseId}/knowledge-points", "GET");
        PermissionEntity readDashboard = ensurePermission("dashboard:read", "Read Admin Dashboard", "API", "/api/admin/dashboard", "GET");
        PermissionEntity readStatistics = ensurePermission("statistics:read", "Read Admin Statistics", "API", "/api/admin/statistics", "GET");
        PermissionEntity readAnnouncement = ensurePermission("announcement:read", "Read Announcement", "API", "/api/admin/announcements", "GET");
        PermissionEntity createAnnouncement = ensurePermission("announcement:create", "Create Announcement", "API", "/api/admin/announcements", "POST");
        PermissionEntity updateAnnouncement = ensurePermission("announcement:update", "Update Announcement", "API", "/api/admin/announcements/{id}", "PUT");
        PermissionEntity deleteAnnouncement = ensurePermission("announcement:delete", "Offline Announcement", "API", "/api/admin/announcements/{id}", "DELETE");
        PermissionEntity readAuditLog = ensurePermission("audit:read", "Read Audit Log", "API", "/api/admin/logs/**", "GET");

        ensureRolePermission(adminRole.getId(), readUser.getId());
        ensureRolePermission(adminRole.getId(), disableUser.getId());
        ensureRolePermission(adminRole.getId(), resetPassword.getId());
        ensureRolePermission(adminRole.getId(), assignRole.getId());
        ensureRolePermission(adminRole.getId(), reviewCourse.getId());
        ensureRolePermission(adminRole.getId(), readDashboard.getId());
        ensureRolePermission(adminRole.getId(), readStatistics.getId());
        ensureRolePermission(adminRole.getId(), readAnnouncement.getId());
        ensureRolePermission(adminRole.getId(), createAnnouncement.getId());
        ensureRolePermission(adminRole.getId(), updateAnnouncement.getId());
        ensureRolePermission(adminRole.getId(), deleteAnnouncement.getId());
        ensureRolePermission(adminRole.getId(), readAuditLog.getId());

        ensureRolePermission(teacherRole.getId(), createCourse.getId());
        ensureRolePermission(teacherRole.getId(), updateCourse.getId());
        ensureRolePermission(teacherRole.getId(), submitReview.getId());
        ensureRolePermission(teacherRole.getId(), manageChapter.getId());
        ensureRolePermission(teacherRole.getId(), uploadResource.getId());
        ensureRolePermission(teacherRole.getId(), createQuestion.getId());
        ensureRolePermission(teacherRole.getId(), updateQuestion.getId());
        ensureRolePermission(teacherRole.getId(), readQuestion.getId());
        ensureRolePermission(teacherRole.getId(), createPaper.getId());
        ensureRolePermission(teacherRole.getId(), createKnowledge.getId());
        ensureRolePermission(teacherRole.getId(), updateKnowledge.getId());
        ensureRolePermission(teacherRole.getId(), readKnowledge.getId());

        if (studentRole.getId() == null) {
            throw new IllegalStateException("student role initialization failed");
        }
    }

    private RoleEntity ensureRole(String code, String name, String description) {
        return roleMapper.findByCodeAndDeletedFalse(code)
                .orElseGet(() -> {
                    RoleEntity role = new RoleEntity();
                    role.setCode(code);
                    role.setName(name);
                    role.setDescription(description);
                    return roleMapper.save(role);
                });
    }

    private PermissionEntity ensurePermission(String code, String name, String type, String apiPath, String httpMethod) {
        return permissionMapper.findByCodeAndDeletedFalse(code)
                .orElseGet(() -> {
                    PermissionEntity permission = new PermissionEntity();
                    permission.setCode(code);
                    permission.setName(name);
                    permission.setDescription(name);
                    permission.setPermissionType(type);
                    permission.setApiPath(apiPath);
                    permission.setHttpMethod(httpMethod);
                    return permissionMapper.save(permission);
                });
    }

    private void ensureRolePermission(Long roleId, Long permissionId) {
        List<RolePermissionEntity> existing = rolePermissionMapper.findAllByRoleIdInAndDeletedFalse(List.of(roleId));
        boolean present = existing.stream().anyMatch(item -> item.getPermissionId().equals(permissionId));
        if (present) {
            return;
        }
        RolePermissionEntity entity = new RolePermissionEntity();
        entity.setRoleId(roleId);
        entity.setPermissionId(permissionId);
        rolePermissionMapper.save(entity);
    }
}
