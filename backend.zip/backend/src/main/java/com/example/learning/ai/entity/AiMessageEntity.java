package com.example.learning.ai.entity;

import com.example.learning.ai.enums.AiInputType;
import com.example.learning.ai.enums.AiMessageRole;
import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "ai_message")
@EqualsAndHashCode(callSuper = true)
public class AiMessageEntity extends BaseEntity {

    @Column(name = "conversation_id", nullable = false)
    private Long conversationId;

    @Enumerated(EnumType.STRING)
    @Column(name = "message_role", nullable = false, length = 32)
    private AiMessageRole messageRole;

    @Enumerated(EnumType.STRING)
    @Column(name = "input_type", nullable = false, length = 32)
    private AiInputType inputType;

    @Lob
    @Column(name = "content", nullable = false)
    private String content;

    @Lob
    @Column(name = "structured_payload")
    private String structuredPayload;

    @Column(name = "file_name", length = 255)
    private String fileName;

    @Column(name = "mime_type", length = 128)
    private String mimeType;

    @Column(name = "file_size")
    private Long fileSize;
}
