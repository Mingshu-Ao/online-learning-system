package com.example.learning.course.service;

import com.example.learning.course.dto.CourseChapterCreateDTO;
import com.example.learning.course.dto.CourseChapterSortDTO;
import com.example.learning.course.dto.CourseChapterUpdateDTO;
import com.example.learning.course.dto.CourseCreateDTO;
import com.example.learning.course.dto.CourseUpdateDTO;
import com.example.learning.course.dto.ResourceUploadDTO;
import com.example.learning.course.vo.CourseChapterVO;
import com.example.learning.course.vo.CourseDetailVO;
import com.example.learning.course.vo.CourseResourceVO;
import java.util.List;

public interface TeacherCourseService {

    CourseDetailVO createCourse(Long teacherId, CourseCreateDTO createDTO);

    CourseDetailVO updateCourse(Long teacherId, Long courseId, CourseUpdateDTO updateDTO);

    CourseDetailVO submitReview(Long teacherId, Long courseId);

    CourseChapterVO createChapter(Long teacherId, Long courseId, CourseChapterCreateDTO createDTO);

    CourseChapterVO updateChapter(Long teacherId, Long chapterId, CourseChapterUpdateDTO updateDTO);

    List<CourseChapterVO> sortChapters(Long teacherId, Long courseId, CourseChapterSortDTO sortDTO);

    CourseResourceVO saveResourceMetadata(Long teacherId, ResourceUploadDTO uploadDTO);
}
