package com.example.learning.ai.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AiRecommendationPayload {

    private String type;

    @JsonProperty("resource_id")
    private Long resourceId;

    private String reason;
}
