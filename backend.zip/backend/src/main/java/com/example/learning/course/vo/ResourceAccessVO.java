package com.example.learning.course.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResourceAccessVO {

    private Long resourceId;
    private String accessUrl;
    private String resourceType;
}
