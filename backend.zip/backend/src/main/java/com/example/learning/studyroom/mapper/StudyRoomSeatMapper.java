package com.example.learning.studyroom.mapper;

import com.example.learning.studyroom.entity.StudyRoomSeatEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudyRoomSeatMapper extends JpaRepository<StudyRoomSeatEntity, Long> {

    List<StudyRoomSeatEntity> findAllByRoomIdAndDeletedFalseOrderBySeatNoAsc(Long roomId);
}
