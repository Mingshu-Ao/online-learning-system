package com.example.learning.quiz.dto;

import com.example.learning.quiz.enums.QuestionType;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class QuestionUpsertDTO {

    @NotNull(message = "courseId cannot be null")
    private Long courseId;

    private Long chapterId;

    @NotBlank(message = "stem cannot be blank")
    private String stem;

    @NotNull(message = "questionType cannot be null")
    private QuestionType questionType;

    @NotNull(message = "standardAnswer cannot be null")
    private JsonNode standardAnswer;

    private String analysis;

    private String difficulty;

    private String knowledgePoint;

    private Boolean partialCreditEnabled;

    @Valid
    private List<QuestionOptionDTO> options;
}
