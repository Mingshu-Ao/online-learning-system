package com.example.learning.ai.enums;

public enum AiCallStatus {
    SUCCESS,
    FALLBACK
}
