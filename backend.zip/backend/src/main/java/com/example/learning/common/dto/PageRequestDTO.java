package com.example.learning.common.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class PageRequestDTO {

    @Min(value = 1, message = "pageNum must be greater than 0")
    private int pageNum = 1;

    @Min(value = 1, message = "pageSize must be greater than 0")
    @Max(value = 100, message = "pageSize must be less than or equal to 100")
    private int pageSize = 10;
}
