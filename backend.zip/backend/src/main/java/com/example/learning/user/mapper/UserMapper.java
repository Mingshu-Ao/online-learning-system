package com.example.learning.user.mapper;

import com.example.learning.user.entity.UserEntity;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface UserMapper extends JpaRepository<UserEntity, Long>, JpaSpecificationExecutor<UserEntity> {

    Optional<UserEntity> findByUsernameAndDeletedFalse(String username);

    Optional<UserEntity> findByIdAndDeletedFalse(Long id);

    boolean existsByUsernameAndDeletedFalse(String username);

    boolean existsByEmailAndDeletedFalse(String email);

    boolean existsByPhoneAndDeletedFalse(String phone);

    List<UserEntity> findAllByIdInAndDeletedFalse(List<Long> ids);

    long countByDeletedFalse();

    List<UserEntity> findAllByDeletedFalseAndCreatedAtBetween(LocalDateTime start, LocalDateTime end);
}
