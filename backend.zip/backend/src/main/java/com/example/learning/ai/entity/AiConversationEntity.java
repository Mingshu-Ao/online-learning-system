package com.example.learning.ai.entity;

import com.example.learning.ai.enums.AiInputType;
import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "ai_conversation")
@EqualsAndHashCode(callSuper = true)
public class AiConversationEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Enumerated(EnumType.STRING)
    @Column(name = "input_type", nullable = false, length = 32)
    private AiInputType inputType;

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "latest_summary", length = 500)
    private String latestSummary;

    @Column(name = "last_message_at", nullable = false)
    private LocalDateTime lastMessageAt;
}
