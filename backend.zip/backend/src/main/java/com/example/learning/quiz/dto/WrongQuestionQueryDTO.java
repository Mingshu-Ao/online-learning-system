package com.example.learning.quiz.dto;

import com.example.learning.quiz.enums.WrongQuestionStatus;
import lombok.Data;

@Data
public class WrongQuestionQueryDTO {

    private Long courseId;

    private Long chapterId;

    private String knowledgePoint;

    private WrongQuestionStatus status;
}
