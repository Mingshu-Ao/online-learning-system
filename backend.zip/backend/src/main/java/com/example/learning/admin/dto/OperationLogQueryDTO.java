package com.example.learning.admin.dto;

import com.example.learning.common.dto.PageRequestDTO;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@EqualsAndHashCode(callSuper = true)
public class OperationLogQueryDTO extends PageRequestDTO {

    private String operatorUsername;

    private String action;

    private Boolean success;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime startTime;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime endTime;
}
