package com.example.learning.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class CourseQueryDTO {

    private String keyword;

    @Min(value = 1, message = "pageNum must be greater than 0")
    private long pageNum = 1;

    @Min(value = 1, message = "pageSize must be greater than 0")
    @Max(value = 50, message = "pageSize must be less than or equal to 50")
    private long pageSize = 10;
}

