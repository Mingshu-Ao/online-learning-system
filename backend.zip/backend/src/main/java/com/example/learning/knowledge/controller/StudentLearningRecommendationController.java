package com.example.learning.knowledge.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.knowledge.service.LearningRecommendationService;
import com.example.learning.knowledge.vo.LearningRecommendationVO;
import com.example.learning.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student")
public class StudentLearningRecommendationController {

    private final LearningRecommendationService learningRecommendationService;

    @GetMapping("/courses/{courseId}/recommendations")
    @PreAuthorize("hasRole('STUDENT')")
    public ApiResponse<LearningRecommendationVO> generateRecommendations(@PathVariable Long courseId) {
        return ApiResponse.success(learningRecommendationService.generateRecommendations(SecurityUtils.getCurrentUserId(), courseId));
    }
}
