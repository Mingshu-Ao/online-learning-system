package com.example.learning.studyroom.service;

import com.example.learning.studyroom.enums.UserRoomState;
import com.example.learning.studyroom.vo.StudyRoomJoinVO;
import com.example.learning.studyroom.vo.StudyRoomListItemVO;
import com.example.learning.studyroom.vo.StudyRoomSnapshotVO;
import java.util.List;

public interface StudyRoomService {

    List<StudyRoomListItemVO> listRooms();

    StudyRoomJoinVO joinRoom(Long userId, Long roomId);

    void leaveRoom(Long userId, Long roomId);

    StudyRoomSnapshotVO getSnapshot(Long roomId);

    void changeUserState(Long userId, Long roomId, UserRoomState targetState);

    void startTimer(Long userId, Long roomId, int durationMinutes);

    void finishTimer(Long userId, Long roomId, String sessionToken);

    void heartbeat(Long userId, Long roomId);

    void reconnect(Long userId, Long roomId);

    void handleSocketConnected(Long userId);

    void handleSocketDisconnected(Long userId);

    void cleanupExpiredDisconnects();
}
