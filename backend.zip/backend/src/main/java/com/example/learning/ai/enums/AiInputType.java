package com.example.learning.ai.enums;

public enum AiInputType {
    TEXT,
    IMAGE,
    HANDWRITING,
    MIXED
}
