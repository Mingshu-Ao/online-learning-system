package com.example.learning.user.vo;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserProfileVO {

    private Long id;
    private String username;
    private String nickname;
    private String email;
    private String phone;
    private String status;
    private List<String> roles;
    private List<String> permissions;
}
