package com.example.learning.quiz.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Data;

@Data
public class PaperCreateDTO {

    @NotBlank(message = "title cannot be blank")
    private String title;

    @NotNull(message = "courseId cannot be null")
    private Long courseId;

    @NotNull(message = "passScore cannot be null")
    @DecimalMin(value = "0.0", inclusive = true, message = "passScore cannot be negative")
    private BigDecimal passScore;

    @NotNull(message = "durationMinutes cannot be null")
    @Min(value = 1, message = "durationMinutes must be greater than 0")
    private Integer durationMinutes;

    @NotNull(message = "allowRedo cannot be null")
    private Boolean allowRedo;

    @Min(value = 1, message = "maxAttempts must be greater than 0")
    private Integer maxAttempts;

    @NotNull(message = "startTime cannot be null")
    private LocalDateTime startTime;

    @NotNull(message = "endTime cannot be null")
    private LocalDateTime endTime;

    private Boolean published;

    @Valid
    @NotEmpty(message = "questions cannot be empty")
    private List<PaperQuestionCreateDTO> questions;
}
