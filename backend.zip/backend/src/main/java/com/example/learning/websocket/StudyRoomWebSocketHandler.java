package com.example.learning.websocket;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.security.SecurityUser;
import com.example.learning.studyroom.dto.StudyRoomWsMessageDTO;
import com.example.learning.studyroom.enums.StudyRoomMessageType;
import com.example.learning.studyroom.enums.UserRoomState;
import com.example.learning.studyroom.service.StudyRoomService;
import com.example.learning.studyroom.vo.StudyRoomWsEnvelopeVO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Slf4j
@Component
@RequiredArgsConstructor
public class StudyRoomWebSocketHandler extends TextWebSocketHandler {

    private final ObjectMapper objectMapper;
    private final StudyRoomService studyRoomService;
    private final StudyRoomBroadcastService broadcastService;

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        SecurityUser securityUser = getSecurityUser(session);
        broadcastService.registerSession(securityUser.getId(), session, null);
        studyRoomService.handleSocketConnected(securityUser.getId());
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        SecurityUser securityUser = getSecurityUser(session);
        try {
            StudyRoomWsMessageDTO wsMessage = objectMapper.readValue(message.getPayload(), StudyRoomWsMessageDTO.class);
            validateSender(securityUser.getId(), wsMessage);
            routeMessage(securityUser.getId(), wsMessage);
        } catch (BusinessException ex) {
            sendError(securityUser.getId(), ex.getErrorCode(), ex.getMessage());
        } catch (Exception ex) {
            log.warn("failed to process study-room websocket message", ex);
            sendError(securityUser.getId(), ErrorCode.BAD_REQUEST, "websocket payload is invalid");
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        SecurityUser securityUser = getSecurityUser(session);
        broadcastService.unregisterSession(session);
        if (!broadcastService.hasActiveSession(securityUser.getId())) {
            studyRoomService.handleSocketDisconnected(securityUser.getId());
        }
    }

    private void routeMessage(Long userId, StudyRoomWsMessageDTO message) {
        if (message.getType() == null || message.getRoomId() == null) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "type and roomId are required");
        }
        switch (message.getType()) {
            case ROOM_USER_STATE_CHANGE -> studyRoomService.changeUserState(userId, message.getRoomId(), parseState(message.getPayload()));
            case ROOM_TIMER_START -> studyRoomService.startTimer(userId, message.getRoomId(), parseDuration(message.getPayload()));
            case ROOM_TIMER_FINISH -> studyRoomService.finishTimer(userId, message.getRoomId(), parseSessionToken(message.getPayload()));
            case ROOM_HEARTBEAT -> studyRoomService.heartbeat(userId, message.getRoomId());
            case ROOM_RECONNECT -> studyRoomService.reconnect(userId, message.getRoomId());
            case ROOM_LEAVE -> studyRoomService.leaveRoom(userId, message.getRoomId());
            default -> throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN,
                    "message type cannot be sent by client: " + message.getType());
        }
    }

    private void validateSender(Long userId, StudyRoomWsMessageDTO message) {
        if (message.getSenderId() != null && !userId.equals(message.getSenderId())) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_MESSAGE_FORBIDDEN, "senderId does not match authenticated user");
        }
    }

    private UserRoomState parseState(JsonNode payload) {
        if (payload == null || payload.get("state") == null || payload.get("state").isNull()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "payload.state is required");
        }
        try {
            return UserRoomState.valueOf(payload.get("state").asText());
        } catch (IllegalArgumentException ex) {
            throw new BusinessException(ErrorCode.STUDY_ROOM_STATE_INVALID, "state is invalid");
        }
    }

    private int parseDuration(JsonNode payload) {
        if (payload == null || payload.get("durationMinutes") == null || payload.get("durationMinutes").isNull()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "payload.durationMinutes is required");
        }
        return payload.get("durationMinutes").asInt();
    }

    private String parseSessionToken(JsonNode payload) {
        if (payload == null || payload.get("sessionToken") == null || payload.get("sessionToken").isNull()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "payload.sessionToken is required");
        }
        String token = payload.get("sessionToken").asText();
        if (token.isBlank()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "payload.sessionToken cannot be blank");
        }
        return token;
    }

    private void sendError(Long userId, ErrorCode errorCode, String message) {
        broadcastService.sendToUser(userId, StudyRoomWsEnvelopeVO.builder()
                .type(StudyRoomMessageType.ROOM_ERROR)
                .timestamp(System.currentTimeMillis())
                .payload(java.util.Map.of(
                        "code", errorCode.getCode(),
                        "message", message))
                .build());
    }

    private SecurityUser getSecurityUser(WebSocketSession session) {
        if (session.getPrincipal() instanceof StudyRoomWebSocketPrincipal principal) {
            return principal.securityUser();
        }
        throw new BusinessException(ErrorCode.UNAUTHORIZED);
    }
}
