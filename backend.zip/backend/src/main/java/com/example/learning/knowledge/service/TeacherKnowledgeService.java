package com.example.learning.knowledge.service;

import com.example.learning.knowledge.dto.KnowledgePointUpsertDTO;
import com.example.learning.knowledge.dto.KnowledgeRelationUpdateDTO;
import com.example.learning.knowledge.dto.KnowledgeResourceBindingDTO;
import com.example.learning.knowledge.dto.QuestionKnowledgeBindDTO;
import com.example.learning.knowledge.vo.KnowledgePointVO;
import com.example.learning.knowledge.vo.QuestionKnowledgeBindingVO;
import java.util.List;

public interface TeacherKnowledgeService {

    KnowledgePointVO createKnowledgePoint(Long teacherId, Long courseId, KnowledgePointUpsertDTO upsertDTO);

    KnowledgePointVO updateKnowledgePoint(Long teacherId, Long knowledgePointId, KnowledgePointUpsertDTO upsertDTO);

    List<KnowledgePointVO> listKnowledgePoints(Long teacherId, Long courseId);

    KnowledgePointVO updatePrerequisites(Long teacherId, Long knowledgePointId, KnowledgeRelationUpdateDTO updateDTO);

    KnowledgePointVO updateResources(Long teacherId, Long knowledgePointId, KnowledgeResourceBindingDTO bindingDTO);

    QuestionKnowledgeBindingVO bindQuestionKnowledgePoint(Long teacherId, Long questionId, QuestionKnowledgeBindDTO bindDTO);
}
