package com.example.learning.admin.entity;

import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "system_error_log")
@EqualsAndHashCode(callSuper = true)
public class SystemErrorLogEntity extends BaseEntity {

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "error_code", nullable = false)
    private Integer errorCode;

    @Column(name = "exception_class", nullable = false, length = 255)
    private String exceptionClass;

    @Column(name = "error_message", nullable = false, length = 500)
    private String errorMessage;

    @Column(name = "http_method", length = 16)
    private String httpMethod;

    @Column(name = "request_path", length = 255)
    private String requestPath;

    @Lob
    @Column(name = "request_summary")
    private String requestSummary;

    @Column(name = "ip_address", length = 64)
    private String ipAddress;

    @Column(name = "user_agent", length = 500)
    private String userAgent;
}
