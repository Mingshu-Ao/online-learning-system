package com.example.learning.quiz.mapper;

import com.example.learning.quiz.entity.UserAnswerEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserAnswerMapper extends JpaRepository<UserAnswerEntity, Long> {

    List<UserAnswerEntity> findAllByExamRecordIdAndDeletedFalseOrderByPaperQuestionIdAsc(Long examRecordId);
}
