package com.example.learning.audit;

import com.example.learning.audit.AuditLogService.OperationLogCommand;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.security.SecurityUtils;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Aspect
@Component
@RequiredArgsConstructor
public class AdminOperationAuditAspect {

    private final AuditLogService auditLogService;
    private final AuditSanitizer auditSanitizer;
    private final AuditRequestContextExtractor requestContextExtractor;

    private final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
    private final ExpressionParser expressionParser = new SpelExpressionParser();

    @Around("@annotation(audit)")
    public Object around(ProceedingJoinPoint joinPoint, AdminOperationAudit audit) throws Throwable {
        long startedAt = System.currentTimeMillis();
        boolean success = false;
        Throwable failure = null;
        try {
            Object result = joinPoint.proceed();
            success = true;
            return result;
        } catch (Throwable throwable) {
            failure = throwable;
            throw throwable;
        } finally {
            recordAuditLog(joinPoint, audit, success, failure, System.currentTimeMillis() - startedAt);
        }
    }

    private void recordAuditLog(ProceedingJoinPoint joinPoint,
                                AdminOperationAudit audit,
                                boolean success,
                                Throwable failure,
                                long durationMs) {
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        String[] parameterNames = parameterNameDiscoverer.getParameterNames(method);
        Object[] args = joinPoint.getArgs();
        StandardEvaluationContext context = new StandardEvaluationContext();
        Map<String, Object> argMap = new LinkedHashMap<>();
        for (int i = 0; i < args.length; i++) {
            String name = parameterNames != null && i < parameterNames.length ? parameterNames[i] : "arg" + i;
            context.setVariable(name, args[i]);
            argMap.put(name, args[i]);
        }
        RequestAuditContext requestContext = requestContextExtractor.currentContext();
        auditLogService.recordOperation(new OperationLogCommand(
                resolveCurrentUserId(),
                resolveCurrentUsername(),
                audit.action(),
                emptyToNull(audit.targetType()),
                evaluateExpression(audit.targetId(), context),
                resolveSummary(audit.summary(), context, argMap),
                success,
                truncate(resolveFailureMessage(failure), 500),
                durationMs,
                requestContext.requestPath(),
                requestContext.httpMethod(),
                requestContext.ipAddress(),
                requestContext.userAgent()
        ));
    }

    private String resolveSummary(String expression, StandardEvaluationContext context, Map<String, Object> argMap) {
        if (expression != null && !expression.isBlank()) {
            String evaluated = evaluateExpression(expression, context);
            if (evaluated != null) {
                return truncate(evaluated, 2000);
            }
        }
        return auditSanitizer.sanitize(argMap);
    }

    private String evaluateExpression(String expression, StandardEvaluationContext context) {
        if (expression == null || expression.isBlank()) {
            return null;
        }
        Object value = expressionParser.parseExpression(expression).getValue(context);
        return value == null ? null : String.valueOf(value);
    }

    private Long resolveCurrentUserId() {
        try {
            return SecurityUtils.getCurrentUserId();
        } catch (Exception ex) {
            return null;
        }
    }

    private String resolveCurrentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return null;
        }
        return authentication.getName();
    }

    private String resolveFailureMessage(Throwable failure) {
        if (failure == null) {
            return null;
        }
        if (failure instanceof BusinessException businessException) {
            return businessException.getMessage();
        }
        return failure.getMessage();
    }

    private String emptyToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    private String truncate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }
}
