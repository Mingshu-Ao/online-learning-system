package com.example.learning.course.entity;

import com.example.learning.course.enums.ResourceAccessType;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.enums.TranscodingStatus;
import com.example.learning.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "course_resource")
@EqualsAndHashCode(callSuper = true)
public class CourseResourceEntity extends BaseEntity {

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "chapter_id", nullable = false)
    private Long chapterId;

    @Column(name = "title", nullable = false, length = 128)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(name = "resource_type", nullable = false, length = 32)
    private ResourceType resourceType;

    @Enumerated(EnumType.STRING)
    @Column(name = "access_type", nullable = false, length = 32)
    private ResourceAccessType accessType;

    @Column(name = "original_file_name", nullable = false, length = 255)
    private String originalFileName;

    @Column(name = "storage_path", nullable = false, length = 255)
    private String storagePath;

    @Column(name = "file_url", nullable = false, length = 255)
    private String fileUrl;

    @Column(name = "mime_type", length = 128)
    private String mimeType;

    @Column(name = "file_size", nullable = false)
    private Long fileSize;

    @Column(name = "duration_seconds")
    private Long durationSeconds;

    @Enumerated(EnumType.STRING)
    @Column(name = "transcoding_status", nullable = false, length = 32)
    private TranscodingStatus transcodingStatus;

    @Column(name = "cover_url", length = 255)
    private String coverUrl;
}
