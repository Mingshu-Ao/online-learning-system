package com.example.learning.quiz.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.quiz.dto.ExamAnswerItemDTO;
import com.example.learning.quiz.dto.StudentExamSubmitDTO;
import com.example.learning.quiz.dto.WrongQuestionQueryDTO;
import com.example.learning.quiz.entity.ExamRecordEntity;
import com.example.learning.quiz.entity.PaperEntity;
import com.example.learning.quiz.entity.PaperQuestionEntity;
import com.example.learning.quiz.entity.UserAnswerEntity;
import com.example.learning.quiz.entity.WrongQuestionEntity;
import com.example.learning.quiz.enums.ExamRecordStatus;
import com.example.learning.quiz.enums.QuestionType;
import com.example.learning.quiz.enums.WrongQuestionStatus;
import com.example.learning.quiz.mapper.ExamRecordMapper;
import com.example.learning.quiz.mapper.PaperMapper;
import com.example.learning.quiz.mapper.PaperQuestionMapper;
import com.example.learning.quiz.mapper.UserAnswerMapper;
import com.example.learning.quiz.mapper.WrongQuestionMapper;
import com.example.learning.quiz.service.QuizScoringService;
import com.example.learning.quiz.service.StudentExamService;
import com.example.learning.quiz.vo.ExamResultQuestionVO;
import com.example.learning.quiz.vo.ExamResultVO;
import com.example.learning.quiz.vo.ExamStartVO;
import com.example.learning.quiz.vo.PaperDetailVO;
import com.example.learning.quiz.vo.PaperQuestionVO;
import com.example.learning.quiz.vo.QuestionOptionVO;
import com.example.learning.quiz.vo.WrongQuestionVO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class StudentExamServiceImpl implements StudentExamService {

    private final PaperMapper paperMapper;
    private final PaperQuestionMapper paperQuestionMapper;
    private final ExamRecordMapper examRecordMapper;
    private final UserAnswerMapper userAnswerMapper;
    private final WrongQuestionMapper wrongQuestionMapper;
    private final CourseMapper courseMapper;
    private final CourseEnrollmentMapper courseEnrollmentMapper;
    private final QuizScoringService quizScoringService;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    @Override
    @Transactional(readOnly = true)
    public PaperDetailVO getPaper(Long studentId, Long paperId) {
        PaperEntity paper = getAccessiblePaper(studentId, paperId);
        List<PaperQuestionEntity> paperQuestions = paperQuestionMapper.findAllByPaperIdAndDeletedFalseOrderBySortOrderAsc(paper.getId());
        return toPaperDetailVO(paper, paperQuestions);
    }

    @Override
    @Transactional
    public ExamStartVO startExam(Long studentId, Long paperId) {
        PaperEntity paper = getAccessiblePaper(studentId, paperId);
        LocalDateTime now = LocalDateTime.now(clock);
        if (now.isBefore(paper.getStartTime())) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "exam has not started yet");
        }
        if (now.isAfter(paper.getEndTime())) {
            throw new BusinessException(ErrorCode.EXAM_EXPIRED);
        }

        ExamRecordEntity existing = examRecordMapper
                .findFirstByPaperIdAndUserIdAndStatusAndDeletedFalseOrderByAttemptNoDesc(paperId, studentId, ExamRecordStatus.IN_PROGRESS)
                .orElse(null);
        if (existing != null) {
            if (now.isAfter(existing.getDeadlineTime())) {
                existing.setStatus(ExamRecordStatus.EXPIRED);
                examRecordMapper.save(existing);
            } else {
                return ExamStartVO.builder()
                        .examRecordId(existing.getId())
                        .paperId(existing.getPaperId())
                        .startTime(existing.getStartTime())
                        .endTime(existing.getDeadlineTime())
                        .build();
            }
        }

        long usedAttempts = examRecordMapper.countByPaperIdAndUserIdAndDeletedFalse(paperId, studentId);
        if (usedAttempts >= resolveAllowedAttempts(paper)) {
            throw new BusinessException(ErrorCode.PAPER_ATTEMPT_LIMIT_REACHED);
        }

        List<PaperQuestionEntity> paperQuestions = paperQuestionMapper.findAllByPaperIdAndDeletedFalseOrderBySortOrderAsc(paperId);
        LocalDateTime deadline = now.plusMinutes(paper.getDurationMinutes());
        if (deadline.isAfter(paper.getEndTime())) {
            deadline = paper.getEndTime();
        }
        if (!deadline.isAfter(now)) {
            throw new BusinessException(ErrorCode.EXAM_EXPIRED);
        }

        ExamRecordEntity examRecord = new ExamRecordEntity();
        examRecord.setPaperId(paperId);
        examRecord.setCourseId(paper.getCourseId());
        examRecord.setUserId(studentId);
        examRecord.setAttemptNo((int) usedAttempts + 1);
        examRecord.setStartTime(now);
        examRecord.setDeadlineTime(deadline);
        examRecord.setStatus(ExamRecordStatus.IN_PROGRESS);
        examRecord.setPassScore(paper.getPassScore());
        examRecord.setAnsweredCount(0);
        examRecord.setTotalQuestionCount(paperQuestions.size());
        ExamRecordEntity saved = examRecordMapper.save(examRecord);

        return ExamStartVO.builder()
                .examRecordId(saved.getId())
                .paperId(saved.getPaperId())
                .startTime(saved.getStartTime())
                .endTime(saved.getDeadlineTime())
                .build();
    }

    @Override
    @Transactional
    public ExamResultVO submitExam(Long studentId, Long examRecordId, StudentExamSubmitDTO submitDTO) {
        ExamRecordEntity examRecord = examRecordMapper.findWithLockByIdAndDeletedFalse(examRecordId)
                .orElseThrow(() -> new BusinessException(ErrorCode.EXAM_RECORD_NOT_FOUND));
        ensureResultOwner(studentId, examRecord);
        if (examRecord.getStatus() == ExamRecordStatus.COMPLETED || examRecord.getStatus() == ExamRecordStatus.PENDING_REVIEW) {
            throw new BusinessException(ErrorCode.EXAM_ALREADY_SUBMITTED);
        }
        if (examRecord.getStatus() == ExamRecordStatus.EXPIRED) {
            throw new BusinessException(ErrorCode.EXAM_EXPIRED);
        }

        LocalDateTime now = LocalDateTime.now(clock);
        if (now.isAfter(examRecord.getDeadlineTime())) {
            examRecord.setStatus(ExamRecordStatus.EXPIRED);
            examRecordMapper.save(examRecord);
            throw new BusinessException(ErrorCode.EXAM_EXPIRED);
        }

        List<PaperQuestionEntity> paperQuestions = paperQuestionMapper.findAllByPaperIdAndDeletedFalseOrderBySortOrderAsc(examRecord.getPaperId());
        if (paperQuestions.isEmpty()) {
            throw new BusinessException(ErrorCode.PAPER_QUESTION_INVALID, "paper does not contain any question");
        }

        Map<Long, JsonNode> answerMap = normalizeSubmitAnswers(submitDTO.getAnswers(), paperQuestions);
        List<UserAnswerEntity> userAnswers = new ArrayList<>();
        Map<Long, QuizScoringService.ScoringResult> scoringMap = new HashMap<>();
        BigDecimal objectiveScore = BigDecimal.ZERO;
        boolean pendingReview = false;
        int answeredCount = 0;

        for (PaperQuestionEntity paperQuestion : paperQuestions) {
            JsonNode answerNode = answerMap.get(paperQuestion.getQuestionId());
            if (hasMeaningfulAnswer(answerNode)) {
                answeredCount++;
            }
            QuizScoringService.ScoringResult scoring = quizScoringService.score(paperQuestion, answerNode);
            scoringMap.put(paperQuestion.getId(), scoring);
            if (scoring.awardedScore() != null && paperQuestion.getQuestionType().isObjective()) {
                objectiveScore = objectiveScore.add(scoring.awardedScore());
            }
            if (scoring.needsManualReview()) {
                pendingReview = true;
            }

            UserAnswerEntity userAnswer = new UserAnswerEntity();
            userAnswer.setExamRecordId(examRecord.getId());
            userAnswer.setPaperQuestionId(paperQuestion.getId());
            userAnswer.setQuestionId(paperQuestion.getQuestionId());
            userAnswer.setQuestionType(paperQuestion.getQuestionType());
            userAnswer.setAnswerContent(answerNode == null || answerNode.isNull() ? null : writeJson(answerNode));
            userAnswer.setAwardedScore(scoring.awardedScore());
            userAnswer.setCorrect(scoring.correct());
            userAnswer.setAutoGraded(scoring.autoGraded());
            userAnswer.setNeedsManualReview(scoring.needsManualReview());
            userAnswers.add(userAnswer);
        }

        List<UserAnswerEntity> savedAnswers = userAnswerMapper.saveAll(userAnswers);
        examRecord.setObjectiveScore(objectiveScore);
        examRecord.setAnsweredCount(answeredCount);
        examRecord.setSubmitTime(now);
        if (pendingReview) {
            examRecord.setStatus(ExamRecordStatus.PENDING_REVIEW);
            examRecord.setTotalScore(null);
            examRecord.setPassed(null);
        } else {
            examRecord.setStatus(ExamRecordStatus.COMPLETED);
            examRecord.setTotalScore(objectiveScore);
            examRecord.setPassed(objectiveScore.compareTo(examRecord.getPassScore()) >= 0);
        }
        ExamRecordEntity savedRecord = examRecordMapper.save(examRecord);

        for (UserAnswerEntity userAnswer : savedAnswers) {
            QuizScoringService.ScoringResult scoring = scoringMap.get(userAnswer.getPaperQuestionId());
            PaperQuestionEntity paperQuestion = paperQuestions.stream()
                    .filter(item -> Objects.equals(item.getId(), userAnswer.getPaperQuestionId()))
                    .findFirst()
                    .orElseThrow(() -> new BusinessException(ErrorCode.PAPER_QUESTION_INVALID));
            if (Boolean.FALSE.equals(scoring.correct()) && !scoring.needsManualReview()) {
                upsertWrongQuestion(studentId, savedRecord.getId(), userAnswer, paperQuestion, now);
            }
        }

        return buildExamResult(savedRecord, paperQuestions, savedAnswers);
    }

    @Override
    @Transactional(readOnly = true)
    public ExamResultVO getExamResult(Long studentId, Long examRecordId) {
        ExamRecordEntity examRecord = examRecordMapper.findByIdAndDeletedFalse(examRecordId)
                .orElseThrow(() -> new BusinessException(ErrorCode.EXAM_RECORD_NOT_FOUND));
        ensureResultOwner(studentId, examRecord);
        if (examRecord.getStatus() == ExamRecordStatus.IN_PROGRESS) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "exam has not been submitted yet");
        }
        List<PaperQuestionEntity> paperQuestions = paperQuestionMapper.findAllByPaperIdAndDeletedFalseOrderBySortOrderAsc(examRecord.getPaperId());
        List<UserAnswerEntity> userAnswers = userAnswerMapper.findAllByExamRecordIdAndDeletedFalseOrderByPaperQuestionIdAsc(examRecordId);
        return buildExamResult(examRecord, paperQuestions, userAnswers);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WrongQuestionVO> listWrongQuestions(Long studentId, WrongQuestionQueryDTO queryDTO) {
        return wrongQuestionMapper.findAllByUserIdAndDeletedFalseOrderByLastWrongAtDesc(studentId)
                .stream()
                .filter(item -> queryDTO == null || queryDTO.getCourseId() == null || Objects.equals(item.getCourseId(), queryDTO.getCourseId()))
                .filter(item -> queryDTO == null || queryDTO.getChapterId() == null || Objects.equals(item.getChapterId(), queryDTO.getChapterId()))
                .filter(item -> queryDTO == null || queryDTO.getStatus() == null || item.getStatus() == queryDTO.getStatus())
                .filter(item -> queryDTO == null || queryDTO.getKnowledgePoint() == null || queryDTO.getKnowledgePoint().trim().isEmpty()
                        || Objects.equals(item.getKnowledgePoint(), queryDTO.getKnowledgePoint().trim()))
                .map(this::toWrongQuestionVO)
                .toList();
    }

    @Override
    @Transactional
    public WrongQuestionVO redoWrongQuestion(Long studentId, Long wrongQuestionId) {
        WrongQuestionEntity wrongQuestion = getOwnedWrongQuestion(studentId, wrongQuestionId);
        wrongQuestion.setStatus(WrongQuestionStatus.REVIEWING);
        return toWrongQuestionVO(wrongQuestionMapper.save(wrongQuestion));
    }

    @Override
    @Transactional
    public WrongQuestionVO markWrongQuestionMastered(Long studentId, Long wrongQuestionId) {
        WrongQuestionEntity wrongQuestion = getOwnedWrongQuestion(studentId, wrongQuestionId);
        wrongQuestion.setStatus(WrongQuestionStatus.MASTERED);
        return toWrongQuestionVO(wrongQuestionMapper.save(wrongQuestion));
    }

    private Map<Long, JsonNode> normalizeSubmitAnswers(List<ExamAnswerItemDTO> answers, List<PaperQuestionEntity> paperQuestions) {
        if (answers == null || answers.isEmpty()) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "answers cannot be empty");
        }
        Map<Long, PaperQuestionEntity> paperQuestionMap = paperQuestions.stream()
                .collect(Collectors.toMap(PaperQuestionEntity::getQuestionId, item -> item));
        Map<Long, JsonNode> answerMap = new LinkedHashMap<>();
        for (ExamAnswerItemDTO answer : answers) {
            if (!paperQuestionMap.containsKey(answer.getQuestionId())) {
                throw new BusinessException(ErrorCode.PAPER_QUESTION_INVALID, "submitted question does not belong to paper");
            }
            if (answerMap.containsKey(answer.getQuestionId())) {
                throw new BusinessException(ErrorCode.PAPER_QUESTION_INVALID, "submitted question cannot be duplicated");
            }
            answerMap.put(answer.getQuestionId(), answer.getAnswer());
        }
        return answerMap;
    }

    private void upsertWrongQuestion(Long studentId,
                                     Long examRecordId,
                                     UserAnswerEntity userAnswer,
                                     PaperQuestionEntity paperQuestion,
                                     LocalDateTime now) {
        WrongQuestionEntity wrongQuestion = wrongQuestionMapper
                .findFirstByUserIdAndQuestionIdAndDeletedFalseOrderByCreatedAtDesc(studentId, paperQuestion.getQuestionId())
                .orElseGet(WrongQuestionEntity::new);
        wrongQuestion.setUserId(studentId);
        wrongQuestion.setCourseId(getPaperCourseId(examRecordId, paperQuestion));
        wrongQuestion.setChapterId(paperQuestion.getChapterId());
        wrongQuestion.setQuestionId(paperQuestion.getQuestionId());
        wrongQuestion.setLatestExamRecordId(examRecordId);
        wrongQuestion.setLatestUserAnswerId(userAnswer.getId());
        wrongQuestion.setQuestionType(paperQuestion.getQuestionType());
        wrongQuestion.setQuestionStem(paperQuestion.getQuestionStem());
        wrongQuestion.setOptionSnapshot(paperQuestion.getOptionSnapshot());
        wrongQuestion.setStandardAnswer(paperQuestion.getStandardAnswer());
        wrongQuestion.setAnalysis(paperQuestion.getAnalysis());
        wrongQuestion.setKnowledgePoint(paperQuestion.getKnowledgePoint());
        wrongQuestion.setStatus(WrongQuestionStatus.UNMASTERED);
        wrongQuestion.setWrongCount(wrongQuestion.getWrongCount() == null ? 1 : wrongQuestion.getWrongCount() + 1);
        wrongQuestion.setLastWrongAt(now);
        wrongQuestionMapper.save(wrongQuestion);
    }

    private Long getPaperCourseId(Long examRecordId, PaperQuestionEntity paperQuestion) {
        return examRecordMapper.findByIdAndDeletedFalse(examRecordId)
                .map(ExamRecordEntity::getCourseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.EXAM_RECORD_NOT_FOUND));
    }

    private PaperEntity getAccessiblePaper(Long studentId, Long paperId) {
        PaperEntity paper = paperMapper.findByIdAndDeletedFalse(paperId)
                .orElseThrow(() -> new BusinessException(ErrorCode.PAPER_NOT_FOUND));
        if (!Boolean.TRUE.equals(paper.getPublished())) {
            throw new BusinessException(ErrorCode.PAPER_NOT_PUBLISHED);
        }
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(paper.getCourseId())
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (course.getStatus() != CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_NOT_PUBLISHED);
        }
        if (!courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(course.getId(), studentId)) {
            throw new BusinessException(ErrorCode.USER_NOT_ENROLLED);
        }
        return paper;
    }

    private int resolveAllowedAttempts(PaperEntity paper) {
        if (!Boolean.TRUE.equals(paper.getAllowRedo())) {
            return 1;
        }
        return paper.getMaxAttempts() == null || paper.getMaxAttempts() < 1 ? 1 : paper.getMaxAttempts();
    }

    private void ensureResultOwner(Long studentId, ExamRecordEntity examRecord) {
        if (!Objects.equals(examRecord.getUserId(), studentId)) {
            throw new BusinessException(ErrorCode.FORBIDDEN, "cannot access another user's exam result");
        }
    }

    private WrongQuestionEntity getOwnedWrongQuestion(Long studentId, Long wrongQuestionId) {
        WrongQuestionEntity wrongQuestion = wrongQuestionMapper.findByIdAndDeletedFalse(wrongQuestionId)
                .orElseThrow(() -> new BusinessException(ErrorCode.WRONG_QUESTION_NOT_FOUND));
        if (!Objects.equals(wrongQuestion.getUserId(), studentId)) {
            throw new BusinessException(ErrorCode.FORBIDDEN, "cannot access another user's wrong question");
        }
        return wrongQuestion;
    }

    private PaperDetailVO toPaperDetailVO(PaperEntity paper, Collection<PaperQuestionEntity> paperQuestions) {
        List<PaperQuestionVO> questions = paperQuestions.stream()
                .sorted(Comparator.comparing(PaperQuestionEntity::getSortOrder))
                .map(item -> PaperQuestionVO.builder()
                        .questionId(item.getQuestionId())
                        .stem(item.getQuestionStem())
                        .questionType(item.getQuestionType().name())
                        .score(item.getScore())
                        .partialCreditEnabled(item.getPartialCreditEnabled())
                        .options(readOptionVOs(item.getOptionSnapshot()))
                        .build())
                .toList();
        return PaperDetailVO.builder()
                .id(paper.getId())
                .title(paper.getTitle())
                .courseId(paper.getCourseId())
                .totalScore(paper.getTotalScore())
                .passScore(paper.getPassScore())
                .durationMinutes(paper.getDurationMinutes())
                .allowRedo(paper.getAllowRedo())
                .maxAttempts(paper.getMaxAttempts())
                .startTime(paper.getStartTime())
                .endTime(paper.getEndTime())
                .published(paper.getPublished())
                .questions(questions)
                .build();
    }

    private ExamResultVO buildExamResult(ExamRecordEntity examRecord,
                                         List<PaperQuestionEntity> paperQuestions,
                                         List<UserAnswerEntity> userAnswers) {
        Map<Long, UserAnswerEntity> answerMap = userAnswers.stream()
                .collect(Collectors.toMap(UserAnswerEntity::getPaperQuestionId, item -> item));
        List<ExamResultQuestionVO> questions = paperQuestions.stream()
                .sorted(Comparator.comparing(PaperQuestionEntity::getSortOrder))
                .map(paperQuestion -> {
                    UserAnswerEntity userAnswer = answerMap.get(paperQuestion.getId());
                    return ExamResultQuestionVO.builder()
                            .questionId(paperQuestion.getQuestionId())
                            .stem(paperQuestion.getQuestionStem())
                            .questionType(paperQuestion.getQuestionType().name())
                            .fullScore(paperQuestion.getScore())
                            .awardedScore(userAnswer == null ? null : userAnswer.getAwardedScore())
                            .correct(userAnswer == null ? null : userAnswer.getCorrect())
                            .needsManualReview(userAnswer != null && Boolean.TRUE.equals(userAnswer.getNeedsManualReview()))
                            .userAnswer(userAnswer == null ? null : readJson(userAnswer.getAnswerContent()))
                            .standardAnswer(readJson(paperQuestion.getStandardAnswer()))
                            .analysis(paperQuestion.getAnalysis())
                            .options(readOptionVOs(paperQuestion.getOptionSnapshot()))
                            .build();
                })
                .toList();
        return ExamResultVO.builder()
                .examRecordId(examRecord.getId())
                .paperId(examRecord.getPaperId())
                .status(examRecord.getStatus().name())
                .objectiveScore(examRecord.getObjectiveScore())
                .totalScore(examRecord.getTotalScore())
                .passed(examRecord.getPassed())
                .pendingReview(examRecord.getStatus() == ExamRecordStatus.PENDING_REVIEW)
                .startTime(examRecord.getStartTime())
                .submitTime(examRecord.getSubmitTime())
                .deadlineTime(examRecord.getDeadlineTime())
                .questions(questions)
                .build();
    }

    private WrongQuestionVO toWrongQuestionVO(WrongQuestionEntity wrongQuestion) {
        return WrongQuestionVO.builder()
                .id(wrongQuestion.getId())
                .questionId(wrongQuestion.getQuestionId())
                .courseId(wrongQuestion.getCourseId())
                .chapterId(wrongQuestion.getChapterId())
                .questionType(wrongQuestion.getQuestionType().name())
                .stem(wrongQuestion.getQuestionStem())
                .knowledgePoint(wrongQuestion.getKnowledgePoint())
                .status(wrongQuestion.getStatus().name())
                .wrongCount(wrongQuestion.getWrongCount())
                .lastWrongAt(wrongQuestion.getLastWrongAt())
                .standardAnswer(readJson(wrongQuestion.getStandardAnswer()))
                .analysis(wrongQuestion.getAnalysis())
                .options(readOptionVOs(wrongQuestion.getOptionSnapshot()))
                .build();
    }

    private List<QuestionOptionVO> readOptionVOs(String json) {
        try {
            if (json == null || json.isBlank()) {
                return List.of();
            }
            QuestionOptionVO[] options = objectMapper.readValue(json, QuestionOptionVO[].class);
            return List.of(options);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "option snapshot is invalid");
        }
    }

    private JsonNode readJson(String json) {
        try {
            if (json == null || json.isBlank()) {
                return null;
            }
            return objectMapper.readTree(json);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "stored answer payload is invalid");
        }
    }

    private String writeJson(JsonNode node) {
        try {
            return objectMapper.writeValueAsString(node);
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INTERNAL_SERVER_ERROR, "json serialization failed");
        }
    }

    private boolean hasMeaningfulAnswer(JsonNode node) {
        if (node == null || node.isNull()) {
            return false;
        }
        if (node.isArray()) {
            return node.size() > 0;
        }
        if (node.isTextual()) {
            return !node.asText().trim().isEmpty();
        }
        return true;
    }
}
