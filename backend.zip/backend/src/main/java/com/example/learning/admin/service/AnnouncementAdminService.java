package com.example.learning.admin.service;

import com.example.learning.admin.dto.AnnouncementQueryDTO;
import com.example.learning.admin.dto.AnnouncementUpsertDTO;
import com.example.learning.admin.vo.AnnouncementVO;
import com.example.learning.common.vo.PageResultVO;

public interface AnnouncementAdminService {

    PageResultVO<AnnouncementVO> listAnnouncements(AnnouncementQueryDTO queryDTO);

    AnnouncementVO createAnnouncement(AnnouncementUpsertDTO upsertDTO);

    AnnouncementVO updateAnnouncement(Long announcementId, AnnouncementUpsertDTO upsertDTO);

    void offlineAnnouncement(Long announcementId);
}
