package com.example.learning.ai.service.impl;

import com.example.learning.ai.config.AiServiceProperties;
import com.example.learning.ai.enums.AiInputType;
import com.example.learning.ai.service.AiRateLimitService;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import java.time.Duration;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AiRateLimitServiceImpl implements AiRateLimitService {

    private static final Duration RATE_LIMIT_TTL = Duration.ofMinutes(1);

    private final StringRedisTemplate redisTemplate;
    private final AiServiceProperties properties;

    @Override
    public void assertAllowed(Long userId, AiInputType inputType) {
        long limit = inputType == AiInputType.IMAGE
                ? properties.getImageRequestsPerMinute()
                : properties.getTextRequestsPerMinute();
        String key = "ai:ratelimit:user:" + userId + ":" + inputType.name().toLowerCase();
        try {
            Long count = redisTemplate.opsForValue().increment(key);
            if (count != null && count == 1L) {
                redisTemplate.expire(key, RATE_LIMIT_TTL);
            }
            if (count != null && count > limit) {
                throw new BusinessException(ErrorCode.CONFLICT, "AI 调用过于频繁，请稍后再试");
            }
        } catch (DataAccessException ex) {
            throw new BusinessException(ErrorCode.AI_SERVICE_UNAVAILABLE, "AI 助教暂时不可用");
        }
    }
}
