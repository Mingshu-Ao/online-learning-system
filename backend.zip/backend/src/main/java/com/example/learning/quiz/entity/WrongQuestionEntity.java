package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.quiz.enums.QuestionType;
import com.example.learning.quiz.enums.WrongQuestionStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "wrong_question")
@EqualsAndHashCode(callSuper = true)
public class WrongQuestionEntity extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "course_id", nullable = false)
    private Long courseId;

    @Column(name = "chapter_id")
    private Long chapterId;

    @Column(name = "question_id", nullable = false)
    private Long questionId;

    @Column(name = "latest_exam_record_id", nullable = false)
    private Long latestExamRecordId;

    @Column(name = "latest_user_answer_id", nullable = false)
    private Long latestUserAnswerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "question_type", nullable = false, length = 32)
    private QuestionType questionType;

    @Lob
    @Column(name = "question_stem", nullable = false)
    private String questionStem;

    @Lob
    @Column(name = "option_snapshot")
    private String optionSnapshot;

    @Lob
    @Column(name = "standard_answer", nullable = false)
    private String standardAnswer;

    @Lob
    @Column(name = "analysis")
    private String analysis;

    @Column(name = "knowledge_point", length = 255)
    private String knowledgePoint;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private WrongQuestionStatus status;

    @Column(name = "wrong_count", nullable = false)
    private Integer wrongCount;

    @Column(name = "last_wrong_at", nullable = false)
    private LocalDateTime lastWrongAt;
}
