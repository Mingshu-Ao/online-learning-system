package com.example.learning.admin.service.impl;

import com.example.learning.admin.dto.AnnouncementQueryDTO;
import com.example.learning.admin.dto.AnnouncementUpsertDTO;
import com.example.learning.admin.entity.AnnouncementEntity;
import com.example.learning.admin.enums.AnnouncementStatus;
import com.example.learning.admin.mapper.AnnouncementMapper;
import com.example.learning.admin.service.AnnouncementAdminService;
import com.example.learning.admin.vo.AnnouncementVO;
import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.common.vo.PageResultVO;
import jakarta.persistence.criteria.Predicate;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class AnnouncementAdminServiceImpl implements AnnouncementAdminService {

    private final AnnouncementMapper announcementMapper;
    private final Clock clock;

    @Override
    public PageResultVO<AnnouncementVO> listAnnouncements(AnnouncementQueryDTO queryDTO) {
        Specification<AnnouncementEntity> specification = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            predicates.add(cb.isFalse(root.get("deleted")));
            if (StringUtils.hasText(queryDTO.getKeyword())) {
                String keyword = "%" + queryDTO.getKeyword().trim() + "%";
                predicates.add(cb.or(
                        cb.like(root.get("title"), keyword),
                        cb.like(root.get("content"), keyword)
                ));
            }
            if (queryDTO.getStatus() != null) {
                predicates.add(cb.equal(root.get("status"), queryDTO.getStatus()));
            }
            if (queryDTO.getVisibility() != null) {
                predicates.add(cb.equal(root.get("visibility"), queryDTO.getVisibility()));
            }
            return cb.and(predicates.toArray(Predicate[]::new));
        };
        Page<AnnouncementEntity> page = announcementMapper.findAll(
                specification,
                PageRequest.of(queryDTO.getPageNum() - 1, queryDTO.getPageSize(), Sort.by(Sort.Direction.DESC, "id"))
        );
        return PageResultVO.<AnnouncementVO>builder()
                .total(page.getTotalElements())
                .records(page.getContent().stream().map(this::toVO).toList())
                .build();
    }

    @Override
    @Transactional
    public AnnouncementVO createAnnouncement(AnnouncementUpsertDTO upsertDTO) {
        AnnouncementEntity entity = new AnnouncementEntity();
        applyUpsert(entity, upsertDTO);
        return toVO(announcementMapper.save(entity));
    }

    @Override
    @Transactional
    public AnnouncementVO updateAnnouncement(Long announcementId, AnnouncementUpsertDTO upsertDTO) {
        AnnouncementEntity entity = getAnnouncement(announcementId);
        applyUpsert(entity, upsertDTO);
        return toVO(announcementMapper.save(entity));
    }

    @Override
    @Transactional
    public void offlineAnnouncement(Long announcementId) {
        AnnouncementEntity entity = getAnnouncement(announcementId);
        entity.setStatus(AnnouncementStatus.OFFLINE);
        announcementMapper.save(entity);
    }

    private void applyUpsert(AnnouncementEntity entity, AnnouncementUpsertDTO upsertDTO) {
        if (upsertDTO.getStatus() == AnnouncementStatus.OFFLINE && entity.getId() == null) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "new announcement cannot be created as offline");
        }
        entity.setTitle(upsertDTO.getTitle().trim());
        entity.setContent(upsertDTO.getContent().trim());
        entity.setVisibility(upsertDTO.getVisibility());
        entity.setStatus(upsertDTO.getStatus());
        LocalDateTime publishAt = upsertDTO.getPublishAt();
        if (entity.getStatus() == AnnouncementStatus.PUBLISHED && publishAt == null) {
            publishAt = LocalDateTime.now(clock);
        }
        entity.setPublishAt(publishAt);
    }

    private AnnouncementEntity getAnnouncement(Long announcementId) {
        return announcementMapper.findByIdAndDeletedFalse(announcementId)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "announcement not found"));
    }

    private AnnouncementVO toVO(AnnouncementEntity entity) {
        return AnnouncementVO.builder()
                .id(entity.getId())
                .title(entity.getTitle())
                .content(entity.getContent())
                .visibility(entity.getVisibility().name())
                .status(entity.getStatus().name())
                .publishAt(entity.getPublishAt())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }
}
