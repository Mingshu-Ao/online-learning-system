package com.example.learning.admin.service;

import com.example.learning.admin.dto.ErrorLogQueryDTO;
import com.example.learning.admin.dto.LoginLogQueryDTO;
import com.example.learning.admin.dto.OperationLogQueryDTO;
import com.example.learning.admin.dto.ResourceAccessLogQueryDTO;
import com.example.learning.admin.vo.LoginLogVO;
import com.example.learning.admin.vo.OperationLogVO;
import com.example.learning.admin.vo.ResourceAccessLogVO;
import com.example.learning.admin.vo.SystemErrorLogVO;
import com.example.learning.common.vo.PageResultVO;

public interface AuditLogAdminService {

    PageResultVO<LoginLogVO> listLoginLogs(LoginLogQueryDTO queryDTO);

    PageResultVO<OperationLogVO> listOperationLogs(OperationLogQueryDTO queryDTO);

    PageResultVO<ResourceAccessLogVO> listResourceAccessLogs(ResourceAccessLogQueryDTO queryDTO);

    PageResultVO<SystemErrorLogVO> listErrorLogs(ErrorLogQueryDTO queryDTO);
}
