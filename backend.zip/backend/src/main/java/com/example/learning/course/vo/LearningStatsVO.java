package com.example.learning.course.vo;

import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LearningStatsVO {

    private LocalDate startDate;
    private LocalDate endDate;
    private Long todayStudySeconds;
    private Long totalStudySeconds;
    private Long activeDays;
    private Long consecutiveStudyDays;
    private List<LearningCalendarItemVO> calendar;
}
