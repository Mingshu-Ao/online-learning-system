package com.example.learning.ai.service;

import com.example.learning.ai.enums.AiInputType;

public interface AiRateLimitService {

    void assertAllowed(Long userId, AiInputType inputType);
}
