package com.example.learning.controller;

import com.example.learning.common.response.ApiResponse;
import com.example.learning.dto.CourseQueryDTO;
import com.example.learning.service.CourseService;
import com.example.learning.service.SystemService;
import com.example.learning.vo.CourseSimpleVO;
import com.example.learning.vo.SystemStatusVO;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/common")
public class CommonController {

    private final SystemService systemService;
    private final CourseService courseService;

    @GetMapping("/ping")
    public ApiResponse<SystemStatusVO> ping() {
        return ApiResponse.success(systemService.getSystemStatus());
    }

    @GetMapping("/courses")
    public ApiResponse<List<CourseSimpleVO>> listPublicCourses(@Valid CourseQueryDTO queryDTO) {
        return ApiResponse.success(courseService.listPublicCourses(queryDTO));
    }
}

