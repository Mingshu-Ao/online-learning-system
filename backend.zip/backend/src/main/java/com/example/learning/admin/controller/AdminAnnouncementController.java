package com.example.learning.admin.controller;

import com.example.learning.admin.dto.AnnouncementQueryDTO;
import com.example.learning.admin.dto.AnnouncementUpsertDTO;
import com.example.learning.admin.service.AnnouncementAdminService;
import com.example.learning.admin.vo.AnnouncementVO;
import com.example.learning.audit.AdminOperationAudit;
import com.example.learning.common.response.ApiResponse;
import com.example.learning.common.vo.PageResultVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/announcements")
public class AdminAnnouncementController {

    private final AnnouncementAdminService announcementAdminService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('announcement:read')")
    public ApiResponse<PageResultVO<AnnouncementVO>> listAnnouncements(@Valid AnnouncementQueryDTO queryDTO) {
        return ApiResponse.success(announcementAdminService.listAnnouncements(queryDTO));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('announcement:create')")
    @AdminOperationAudit(action = "ANNOUNCEMENT_CREATE", targetType = "ANNOUNCEMENT", summary = "#upsertDTO.title")
    public ApiResponse<AnnouncementVO> createAnnouncement(@Valid @RequestBody AnnouncementUpsertDTO upsertDTO) {
        return ApiResponse.success(announcementAdminService.createAnnouncement(upsertDTO));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('announcement:update')")
    @AdminOperationAudit(action = "ANNOUNCEMENT_UPDATE", targetType = "ANNOUNCEMENT", targetId = "#id", summary = "#upsertDTO.title")
    public ApiResponse<AnnouncementVO> updateAnnouncement(@PathVariable Long id,
                                                          @Valid @RequestBody AnnouncementUpsertDTO upsertDTO) {
        return ApiResponse.success(announcementAdminService.updateAnnouncement(id, upsertDTO));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('announcement:delete')")
    @AdminOperationAudit(action = "ANNOUNCEMENT_OFFLINE", targetType = "ANNOUNCEMENT", targetId = "#id")
    public ApiResponse<Void> offlineAnnouncement(@PathVariable Long id) {
        announcementAdminService.offlineAnnouncement(id);
        return ApiResponse.success(null);
    }
}
