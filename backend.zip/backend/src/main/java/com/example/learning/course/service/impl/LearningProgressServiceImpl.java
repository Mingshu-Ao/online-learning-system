package com.example.learning.course.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.course.dto.LearningStatsQueryDTO;
import com.example.learning.course.dto.VideoProgressReportDTO;
import com.example.learning.course.entity.CourseChapterEntity;
import com.example.learning.course.entity.CourseEntity;
import com.example.learning.course.entity.CourseResourceEntity;
import com.example.learning.course.entity.LearningDailyStatEntity;
import com.example.learning.course.entity.StudyRecordEntity;
import com.example.learning.course.entity.VideoProgressEntity;
import com.example.learning.course.enums.CourseStatus;
import com.example.learning.course.enums.ResourceType;
import com.example.learning.course.mapper.CourseChapterMapper;
import com.example.learning.course.mapper.CourseEnrollmentMapper;
import com.example.learning.course.mapper.CourseMapper;
import com.example.learning.course.mapper.CourseResourceMapper;
import com.example.learning.course.mapper.LearningDailyStatMapper;
import com.example.learning.course.mapper.StudyRecordMapper;
import com.example.learning.course.mapper.VideoProgressMapper;
import com.example.learning.course.service.LearningProgressService;
import com.example.learning.course.vo.CourseLearningProgressVO;
import com.example.learning.course.vo.LearningCalendarItemVO;
import com.example.learning.course.vo.LearningStatsVO;
import com.example.learning.course.vo.VideoProgressItemVO;
import com.example.learning.course.vo.VideoProgressReportVO;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class LearningProgressServiceImpl implements LearningProgressService {

    private static final double MIN_PLAYBACK_RATE = 0.5D;
    private static final double MAX_PLAYBACK_RATE = 2.0D;
    private static final long INITIAL_TRUST_WINDOW_SECONDS = 15L;
    private static final long MAX_TRUST_INTERVAL_SECONDS = 30L;
    private static final double VIDEO_COMPLETION_RATIO = 0.9D;
    private static final long DEFAULT_STATS_RANGE_DAYS = 30L;
    private static final long MAX_STATS_RANGE_DAYS = 366L;

    private final CourseMapper courseMapper;
    private final CourseChapterMapper courseChapterMapper;
    private final CourseResourceMapper courseResourceMapper;
    private final CourseEnrollmentMapper courseEnrollmentMapper;
    private final VideoProgressMapper videoProgressMapper;
    private final StudyRecordMapper studyRecordMapper;
    private final LearningDailyStatMapper learningDailyStatMapper;
    private final Clock clock;

    @Override
    @Transactional
    public VideoProgressReportVO reportVideoProgress(Long studentId, VideoProgressReportDTO reportDTO) {
        CourseEntity course = getPublishedEnrolledCourse(studentId, reportDTO.getCourseId());
        CourseChapterEntity chapter = getChapter(reportDTO.getChapterId());
        if (!course.getId().equals(chapter.getCourseId())) {
            throw new BusinessException(ErrorCode.CHAPTER_COURSE_MISMATCH);
        }
        CourseResourceEntity resource = getVideoResource(reportDTO.getResourceId());
        if (!course.getId().equals(resource.getCourseId()) || !chapter.getId().equals(resource.getChapterId())) {
            throw new BusinessException(ErrorCode.CHAPTER_COURSE_MISMATCH);
        }

        long canonicalDuration = resolveCanonicalDuration(resource, reportDTO);
        validatePlaybackRate(reportDTO.getPlaybackRate());

        LocalDateTime now = LocalDateTime.now(clock);
        VideoProgressEntity progress = videoProgressMapper.findByUserIdAndResourceIdAndDeletedFalse(studentId, resource.getId())
                .orElseGet(() -> createInitialProgress(studentId, course.getId(), chapter.getId(), resource.getId(), canonicalDuration, now));

        ProgressCalculation calculation = calculateProgress(progress, reportDTO, canonicalDuration, now);
        applyProgress(progress, canonicalDuration, reportDTO, now, calculation);
        videoProgressMapper.save(progress);
        saveStudyRecord(studentId, course.getId(), chapter.getId(), resource.getId(), canonicalDuration, reportDTO, calculation);
        if (calculation.trustedIncrement() > 0L) {
            updateDailyStat(studentId, calculation.trustedIncrement(), now);
        }

        return VideoProgressReportVO.builder()
                .resourceId(resource.getId())
                .currentPosition(progress.getCurrentPosition())
                .durationSeconds(progress.getDurationSeconds())
                .effectiveStudySeconds(progress.getEffectiveStudySeconds())
                .progressPercent(progress.getProgressPercent())
                .completed(progress.getCompleted())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public CourseLearningProgressVO getCourseProgress(Long studentId, Long courseId) {
        getPublishedEnrolledCourse(studentId, courseId);
        List<CourseResourceEntity> videoResources = courseResourceMapper.findAllByCourseIdAndResourceTypeAndDeletedFalse(courseId, ResourceType.VIDEO);
        if (videoResources.isEmpty()) {
            return CourseLearningProgressVO.builder()
                    .courseId(courseId)
                    .totalVideoCount(0L)
                    .completedVideoCount(0L)
                    .totalDurationSeconds(0L)
                    .totalEffectiveStudySeconds(0L)
                    .completionPercent(0D)
                    .completed(false)
                    .videos(List.of())
                    .build();
        }

        Map<Long, VideoProgressEntity> progressMap = new HashMap<>();
        List<Long> resourceIds = videoResources.stream().map(CourseResourceEntity::getId).toList();
        videoProgressMapper.findAllByUserIdAndResourceIdInAndDeletedFalse(studentId, resourceIds)
                .forEach(progress -> progressMap.put(progress.getResourceId(), progress));

        long totalRequiredStudySeconds = 0L;
        long totalEffectiveStudySeconds = 0L;
        long totalDurationSeconds = 0L;
        long completedVideoCount = 0L;
        VideoProgressEntity resumeCandidate = null;
        Long resumeChapterId = null;

        List<VideoProgressItemVO> videos = videoResources.stream()
                .sorted(Comparator.comparing(CourseResourceEntity::getChapterId).thenComparing(CourseResourceEntity::getId))
                .map(resource -> {
                    VideoProgressEntity progress = progressMap.get(resource.getId());
                    long duration = safeDuration(resource.getDurationSeconds());
                    long effectiveStudySeconds = progress == null ? 0L : progress.getEffectiveStudySeconds();
                    long currentPosition = progress == null ? 0L : progress.getCurrentPosition();
                    boolean completed = progress != null && Boolean.TRUE.equals(progress.getCompleted());
                    double progressPercent = duration == 0L ? 0D : roundToSingleDecimal(currentPosition * 100D / duration);
                    return VideoProgressItemVO.builder()
                            .resourceId(resource.getId())
                            .chapterId(resource.getChapterId())
                            .resourceTitle(resource.getTitle())
                            .durationSeconds(duration)
                            .currentPosition(currentPosition)
                            .effectiveStudySeconds(effectiveStudySeconds)
                            .progressPercent(progressPercent)
                            .completed(completed)
                            .lastStudyAt(progress == null ? null : progress.getLastStudyAt())
                            .build();
                })
                .toList();

        for (CourseResourceEntity resource : videoResources) {
            long duration = safeDuration(resource.getDurationSeconds());
            totalDurationSeconds += duration;
            totalRequiredStudySeconds += calculateRequiredStudySeconds(duration);
            VideoProgressEntity progress = progressMap.get(resource.getId());
            if (progress == null) {
                continue;
            }
            totalEffectiveStudySeconds += progress.getEffectiveStudySeconds();
            if (Boolean.TRUE.equals(progress.getCompleted())) {
                completedVideoCount++;
            }
            if (progress.getLastStudyAt() != null
                    && (resumeCandidate == null || progress.getLastStudyAt().isAfter(resumeCandidate.getLastStudyAt()))) {
                resumeCandidate = progress;
                resumeChapterId = resource.getChapterId();
            }
        }

        double completionPercent = totalRequiredStudySeconds == 0L
                ? 0D
                : roundToSingleDecimal(Math.min(100D, totalEffectiveStudySeconds * 100D / totalRequiredStudySeconds));

        return CourseLearningProgressVO.builder()
                .courseId(courseId)
                .totalVideoCount((long) videoResources.size())
                .completedVideoCount(completedVideoCount)
                .totalDurationSeconds(totalDurationSeconds)
                .totalEffectiveStudySeconds(totalEffectiveStudySeconds)
                .completionPercent(completionPercent)
                .completed(completionPercent >= 100D)
                .resumeResourceId(resumeCandidate == null ? null : resumeCandidate.getResourceId())
                .resumeChapterId(resumeChapterId)
                .resumePosition(resumeCandidate == null ? null : resumeCandidate.getCurrentPosition())
                .lastStudyAt(resumeCandidate == null ? null : resumeCandidate.getLastStudyAt())
                .videos(videos)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public LearningStatsVO getLearningStats(Long studentId, LearningStatsQueryDTO queryDTO) {
        QueryRange queryRange = resolveQueryRange(queryDTO);
        List<LearningDailyStatEntity> stats = learningDailyStatMapper
                .findAllByUserIdAndStatDateBetweenAndDeletedFalseOrderByStatDateAsc(studentId, queryRange.startDate(), queryRange.endDate());

        Map<LocalDate, Long> studySecondsByDate = new HashMap<>();
        for (LearningDailyStatEntity stat : stats) {
            studySecondsByDate.put(stat.getStatDate(), defaultLong(stat.getTotalStudySeconds()));
        }

        List<LearningCalendarItemVO> calendar = queryRange.startDate()
                .datesUntil(queryRange.endDate().plusDays(1))
                .map(date -> {
                    long studySeconds = studySecondsByDate.getOrDefault(date, 0L);
                    return LearningCalendarItemVO.builder()
                            .date(date)
                            .studySeconds(studySeconds)
                            .active(studySeconds > 0L)
                            .build();
                })
                .toList();

        long totalStudySeconds = calendar.stream().mapToLong(LearningCalendarItemVO::getStudySeconds).sum();
        long activeDays = calendar.stream().filter(LearningCalendarItemVO::getActive).count();
        long consecutiveStudyDays = calculateConsecutiveStudyDays(studySecondsByDate, queryRange.startDate(), queryRange.endDate());
        long todayStudySeconds = learningDailyStatMapper
                .findByUserIdAndStatDateAndDeletedFalse(studentId, LocalDate.now(clock))
                .map(LearningDailyStatEntity::getTotalStudySeconds)
                .map(this::defaultLong)
                .orElse(0L);

        return LearningStatsVO.builder()
                .startDate(queryRange.startDate())
                .endDate(queryRange.endDate())
                .todayStudySeconds(todayStudySeconds)
                .totalStudySeconds(totalStudySeconds)
                .activeDays(activeDays)
                .consecutiveStudyDays(consecutiveStudyDays)
                .calendar(calendar)
                .build();
    }

    private QueryRange resolveQueryRange(LearningStatsQueryDTO queryDTO) {
        LocalDate today = LocalDate.now(clock);
        LocalDate endDate = queryDTO == null || queryDTO.getEndDate() == null ? today : queryDTO.getEndDate();
        LocalDate startDate = queryDTO == null || queryDTO.getStartDate() == null
                ? endDate.minusDays(DEFAULT_STATS_RANGE_DAYS - 1)
                : queryDTO.getStartDate();

        if (endDate.isAfter(today)) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "endDate cannot be in the future");
        }
        if (startDate.isAfter(endDate)) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "startDate cannot be after endDate");
        }
        long rangeDays = ChronoUnit.DAYS.between(startDate, endDate) + 1;
        if (rangeDays > MAX_STATS_RANGE_DAYS) {
            throw new BusinessException(ErrorCode.BAD_REQUEST, "date range cannot exceed 366 days");
        }
        return new QueryRange(startDate, endDate);
    }

    private long calculateConsecutiveStudyDays(Map<LocalDate, Long> studySecondsByDate, LocalDate startDate, LocalDate endDate) {
        LocalDate anchor = endDate;
        while (!anchor.isBefore(startDate) && studySecondsByDate.getOrDefault(anchor, 0L) <= 0L) {
            anchor = anchor.minusDays(1);
        }
        if (anchor.isBefore(startDate)) {
            return 0L;
        }
        long streak = 0L;
        while (!anchor.isBefore(startDate) && studySecondsByDate.getOrDefault(anchor, 0L) > 0L) {
            streak++;
            anchor = anchor.minusDays(1);
        }
        return streak;
    }

    private CourseEntity getPublishedEnrolledCourse(Long studentId, Long courseId) {
        CourseEntity course = courseMapper.findByIdAndDeletedFalse(courseId)
                .orElseThrow(() -> new BusinessException(ErrorCode.COURSE_NOT_FOUND));
        if (course.getStatus() != CourseStatus.PUBLISHED) {
            throw new BusinessException(ErrorCode.COURSE_NOT_PUBLISHED);
        }
        if (!courseEnrollmentMapper.existsByCourseIdAndUserIdAndDeletedFalse(courseId, studentId)) {
            throw new BusinessException(ErrorCode.USER_NOT_ENROLLED);
        }
        return course;
    }

    private CourseChapterEntity getChapter(Long chapterId) {
        return courseChapterMapper.findByIdAndDeletedFalse(chapterId)
                .orElseThrow(() -> new BusinessException(ErrorCode.CHAPTER_NOT_FOUND));
    }

    private CourseResourceEntity getVideoResource(Long resourceId) {
        CourseResourceEntity resource = courseResourceMapper.findByIdAndDeletedFalse(resourceId)
                .orElseThrow(() -> new BusinessException(ErrorCode.RESOURCE_NOT_FOUND));
        if (resource.getResourceType() != ResourceType.VIDEO) {
            throw new BusinessException(ErrorCode.VIDEO_RESOURCE_REQUIRED);
        }
        return resource;
    }

    private long resolveCanonicalDuration(CourseResourceEntity resource, VideoProgressReportDTO reportDTO) {
        long storedDuration = safeDuration(resource.getDurationSeconds());
        if (storedDuration <= 0L) {
            throw new BusinessException(ErrorCode.VIDEO_DURATION_INVALID);
        }
        if (reportDTO.getCurrentPosition() > reportDTO.getDuration() || reportDTO.getCurrentPosition() > storedDuration) {
            throw new BusinessException(ErrorCode.VIDEO_PROGRESS_INVALID, "currentPosition cannot exceed duration");
        }
        return storedDuration;
    }

    private void validatePlaybackRate(Double playbackRate) {
        if (playbackRate == null || playbackRate < MIN_PLAYBACK_RATE || playbackRate > MAX_PLAYBACK_RATE) {
            throw new BusinessException(ErrorCode.VIDEO_PROGRESS_INVALID, "playbackRate is out of allowed range");
        }
    }

    private VideoProgressEntity createInitialProgress(Long studentId,
                                                      Long courseId,
                                                      Long chapterId,
                                                      Long resourceId,
                                                      long durationSeconds,
                                                      LocalDateTime now) {
        VideoProgressEntity progress = new VideoProgressEntity();
        progress.setUserId(studentId);
        progress.setCourseId(courseId);
        progress.setChapterId(chapterId);
        progress.setResourceId(resourceId);
        progress.setCurrentPosition(0L);
        progress.setDurationSeconds(durationSeconds);
        progress.setEffectiveStudySeconds(0L);
        progress.setProgressPercent(0D);
        progress.setCompleted(Boolean.FALSE);
        progress.setLastPlaybackRate(1D);
        progress.setLastReportAt(now);
        progress.setLastStudyAt(now);
        return progress;
    }

    private ProgressCalculation calculateProgress(VideoProgressEntity progress,
                                                  VideoProgressReportDTO reportDTO,
                                                  long durationSeconds,
                                                  LocalDateTime now) {
        long previousPosition = defaultLong(progress.getCurrentPosition());
        long previousEffectiveStudySeconds = defaultLong(progress.getEffectiveStudySeconds());
        long reportIntervalSeconds = calculateReportIntervalSeconds(progress.getLastReportAt(), now);
        long trustedPosition = previousPosition;
        long trustedIncrement = 0L;
        boolean suspicious = false;
        String suspiciousReason = null;

        if (Boolean.TRUE.equals(progress.getCompleted())) {
            trustedPosition = Math.max(previousPosition, Math.min(reportDTO.getCurrentPosition(), durationSeconds));
        } else {
            long allowedDelta = calculateAllowedDelta(reportDTO.getPlaybackRate(), reportIntervalSeconds, progress.getId() == null);
            long reportedDelta = Math.max(0L, reportDTO.getCurrentPosition() - previousPosition);
            long trustedDelta = Math.min(reportedDelta, allowedDelta);
            long requiredStudySeconds = calculateRequiredStudySeconds(durationSeconds);
            long remainingEffectiveStudySeconds = Math.max(0L, requiredStudySeconds - previousEffectiveStudySeconds);
            trustedIncrement = Math.min(trustedDelta, remainingEffectiveStudySeconds);
            trustedPosition = Math.max(previousPosition, Math.min(durationSeconds, previousPosition + trustedDelta));
            if (reportedDelta > allowedDelta) {
                suspicious = true;
                suspiciousReason = "reported progress exceeds trusted window";
            }
        }

        return new ProgressCalculation(trustedPosition, trustedIncrement, reportIntervalSeconds, suspicious, suspiciousReason);
    }

    private void applyProgress(VideoProgressEntity progress,
                               long durationSeconds,
                               VideoProgressReportDTO reportDTO,
                               LocalDateTime now,
                               ProgressCalculation calculation) {
        long requiredStudySeconds = calculateRequiredStudySeconds(durationSeconds);
        long effectiveStudySeconds = Math.min(requiredStudySeconds, defaultLong(progress.getEffectiveStudySeconds()) + calculation.trustedIncrement());
        boolean completed = effectiveStudySeconds >= requiredStudySeconds;

        progress.setChapterId(reportDTO.getChapterId());
        progress.setCurrentPosition(calculation.trustedPosition());
        progress.setDurationSeconds(durationSeconds);
        progress.setEffectiveStudySeconds(effectiveStudySeconds);
        progress.setProgressPercent(durationSeconds == 0L ? 0D : roundToSingleDecimal(calculation.trustedPosition() * 100D / durationSeconds));
        progress.setCompleted(completed);
        progress.setLastPlaybackRate(reportDTO.getPlaybackRate());
        progress.setLastClientTimestamp(reportDTO.getClientTimestamp());
        progress.setLastReportAt(now);
        progress.setLastStudyAt(now);
    }

    private void saveStudyRecord(Long studentId,
                                 Long courseId,
                                 Long chapterId,
                                 Long resourceId,
                                 long durationSeconds,
                                 VideoProgressReportDTO reportDTO,
                                 ProgressCalculation calculation) {
        StudyRecordEntity record = new StudyRecordEntity();
        record.setUserId(studentId);
        record.setCourseId(courseId);
        record.setChapterId(chapterId);
        record.setResourceId(resourceId);
        record.setReportedPosition(reportDTO.getCurrentPosition());
        record.setTrustedPosition(calculation.trustedPosition());
        record.setDurationSeconds(durationSeconds);
        record.setTrustedIncrementSeconds(calculation.trustedIncrement());
        record.setReportIntervalSeconds(calculation.reportIntervalSeconds());
        record.setPlaybackRate(reportDTO.getPlaybackRate());
        record.setClientTimestamp(reportDTO.getClientTimestamp());
        record.setSuspicious(calculation.suspicious());
        record.setSuspiciousReason(calculation.suspiciousReason());
        studyRecordMapper.save(record);
    }

    private void updateDailyStat(Long userId, long trustedIncrement, LocalDateTime now) {
        LocalDate statDate = now.toLocalDate();
        LearningDailyStatEntity stat = learningDailyStatMapper.findByUserIdAndStatDateAndDeletedFalse(userId, statDate)
                .orElseGet(() -> {
                    LearningDailyStatEntity entity = new LearningDailyStatEntity();
                    entity.setUserId(userId);
                    entity.setStatDate(statDate);
                    entity.setTotalStudySeconds(0L);
                    entity.setLastStudyAt(now);
                    return entity;
                });
        stat.setTotalStudySeconds(defaultLong(stat.getTotalStudySeconds()) + trustedIncrement);
        stat.setLastStudyAt(now);
        learningDailyStatMapper.save(stat);
    }

    private long calculateAllowedDelta(double playbackRate, long reportIntervalSeconds, boolean initialReport) {
        long trustedWindow = initialReport
                ? INITIAL_TRUST_WINDOW_SECONDS
                : Math.max(1L, Math.min(MAX_TRUST_INTERVAL_SECONDS, reportIntervalSeconds));
        return Math.max(1L, (long) Math.ceil(trustedWindow * playbackRate));
    }

    private long calculateReportIntervalSeconds(LocalDateTime lastReportAt, LocalDateTime now) {
        if (lastReportAt == null) {
            return 0L;
        }
        return Math.max(0L, Duration.between(lastReportAt, now).getSeconds());
    }

    private long calculateRequiredStudySeconds(long durationSeconds) {
        return Math.max(1L, (long) Math.ceil(durationSeconds * VIDEO_COMPLETION_RATIO));
    }

    private long safeDuration(Long durationSeconds) {
        return durationSeconds == null ? 0L : Math.max(0L, durationSeconds);
    }

    private long defaultLong(Long value) {
        return value == null ? 0L : value;
    }

    private double roundToSingleDecimal(double value) {
        return Math.round(value * 10D) / 10D;
    }

    private record ProgressCalculation(
            long trustedPosition,
            long trustedIncrement,
            long reportIntervalSeconds,
            boolean suspicious,
            String suspiciousReason
    ) {
    }

    private record QueryRange(LocalDate startDate, LocalDate endDate) {
    }
}
