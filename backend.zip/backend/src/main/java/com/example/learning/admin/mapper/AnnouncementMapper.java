package com.example.learning.admin.mapper;

import com.example.learning.admin.entity.AnnouncementEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AnnouncementMapper extends JpaRepository<AnnouncementEntity, Long>, JpaSpecificationExecutor<AnnouncementEntity> {

    Optional<AnnouncementEntity> findByIdAndDeletedFalse(Long id);
}
