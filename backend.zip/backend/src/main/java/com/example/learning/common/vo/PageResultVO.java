package com.example.learning.common.vo;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PageResultVO<T> {

    private long total;
    private List<T> records;
}
