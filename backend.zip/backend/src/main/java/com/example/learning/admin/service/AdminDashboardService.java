package com.example.learning.admin.service;

import com.example.learning.admin.dto.AdminStatisticsQueryDTO;
import com.example.learning.admin.vo.AdminDashboardVO;
import com.example.learning.admin.vo.AdminStatisticsVO;

public interface AdminDashboardService {

    AdminDashboardVO getDashboard();

    AdminStatisticsVO getStatistics(AdminStatisticsQueryDTO queryDTO);
}
