package com.example.learning.user.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.user.entity.PermissionEntity;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.RolePermissionEntity;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.entity.UserRoleEntity;
import com.example.learning.user.mapper.PermissionMapper;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.RolePermissionMapper;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import com.example.learning.user.service.UserService;
import com.example.learning.user.vo.UserProfileVO;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final UserRoleMapper userRoleMapper;
    private final RoleMapper roleMapper;
    private final RolePermissionMapper rolePermissionMapper;
    private final PermissionMapper permissionMapper;

    @Override
    public UserProfileVO getCurrentUserProfile(Long currentUserId) {
        UserEntity user = userMapper.findByIdAndDeletedFalse(currentUserId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        return buildUserProfile(user);
    }

    public UserProfileVO buildUserProfile(UserEntity user) {
        List<UserRoleEntity> userRoles = userRoleMapper.findAllByUserIdAndDeletedFalse(user.getId());
        List<Long> roleIds = userRoles.stream().map(UserRoleEntity::getRoleId).distinct().toList();
        List<RoleEntity> roles = roleIds.isEmpty() ? List.of() : roleMapper.findAllByIdInAndDeletedFalse(roleIds);
        List<String> roleCodes = roles.stream().map(RoleEntity::getCode).toList();

        List<RolePermissionEntity> rolePermissions = roleIds.isEmpty()
                ? List.of()
                : rolePermissionMapper.findAllByRoleIdInAndDeletedFalse(roleIds);
        List<Long> permissionIds = rolePermissions.stream().map(RolePermissionEntity::getPermissionId).distinct().toList();
        List<PermissionEntity> permissions = permissionIds.isEmpty()
                ? List.of()
                : permissionMapper.findAllByIdInAndDeletedFalse(permissionIds);
        Set<String> permissionCodes = new LinkedHashSet<>();
        permissions.forEach(permission -> permissionCodes.add(permission.getCode()));

        return UserProfileVO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .nickname(user.getNickname())
                .email(user.getEmail())
                .phone(user.getPhone())
                .status(user.getStatus().name())
                .roles(new ArrayList<>(roleCodes))
                .permissions(new ArrayList<>(permissionCodes))
                .build();
    }
}
