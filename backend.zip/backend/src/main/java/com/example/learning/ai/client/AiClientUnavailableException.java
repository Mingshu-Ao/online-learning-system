package com.example.learning.ai.client;

public class AiClientUnavailableException extends AiClientException {

    public AiClientUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
