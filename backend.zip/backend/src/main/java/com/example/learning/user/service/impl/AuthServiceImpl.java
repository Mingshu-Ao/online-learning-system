package com.example.learning.user.service.impl;

import com.example.learning.common.enums.ErrorCode;
import com.example.learning.common.exception.BusinessException;
import com.example.learning.security.JwtTokenProvider;
import com.example.learning.security.SecurityUser;
import com.example.learning.security.SecurityUserDetailsService;
import com.example.learning.user.dto.AuthLoginDTO;
import com.example.learning.user.dto.AuthRegisterDTO;
import com.example.learning.user.entity.RoleEntity;
import com.example.learning.user.entity.UserEntity;
import com.example.learning.user.entity.UserRoleEntity;
import com.example.learning.user.enums.RoleCode;
import com.example.learning.user.enums.UserStatus;
import com.example.learning.user.mapper.RoleMapper;
import com.example.learning.user.mapper.UserMapper;
import com.example.learning.user.mapper.UserRoleMapper;
import com.example.learning.user.service.AuthService;
import com.example.learning.user.vo.LoginVO;
import com.example.learning.user.vo.UserProfileVO;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserMapper userMapper;
    private final RoleMapper roleMapper;
    private final UserRoleMapper userRoleMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final SecurityUserDetailsService securityUserDetailsService;

    @Override
    @Transactional
    public UserProfileVO register(AuthRegisterDTO registerDTO) {
        String username = normalizeRequired(registerDTO.getUsername());
        String nickname = normalizeRequired(registerDTO.getNickname());
        String email = normalizeOptional(registerDTO.getEmail());
        String phone = normalizeOptional(registerDTO.getPhone());

        if (userMapper.existsByUsernameAndDeletedFalse(username)) {
            throw new BusinessException(ErrorCode.USERNAME_ALREADY_EXISTS);
        }
        if (StringUtils.hasText(email) && userMapper.existsByEmailAndDeletedFalse(email)) {
            throw new BusinessException(ErrorCode.EMAIL_ALREADY_EXISTS);
        }
        if (StringUtils.hasText(phone) && userMapper.existsByPhoneAndDeletedFalse(phone)) {
            throw new BusinessException(ErrorCode.PHONE_ALREADY_EXISTS);
        }

        RoleEntity studentRole = roleMapper.findByCodeAndDeletedFalse(RoleCode.STUDENT.name())
                .orElseThrow(() -> new BusinessException(ErrorCode.ROLE_NOT_FOUND, "default student role not found"));

        UserEntity user = new UserEntity();
        user.setUsername(username);
        user.setNickname(nickname);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPasswordHash(passwordEncoder.encode(registerDTO.getPassword()));
        user.setStatus(UserStatus.ENABLED);
        user.setTokenVersion(0);
        UserEntity savedUser = userMapper.save(user);

        UserRoleEntity userRole = new UserRoleEntity();
        userRole.setUserId(savedUser.getId());
        userRole.setRoleId(studentRole.getId());
        userRoleMapper.save(userRole);

        return UserProfileVO.builder()
                .id(savedUser.getId())
                .username(savedUser.getUsername())
                .nickname(savedUser.getNickname())
                .email(savedUser.getEmail())
                .phone(savedUser.getPhone())
                .status(savedUser.getStatus().name())
                .roles(List.of(studentRole.getCode()))
                .permissions(List.of())
                .build();
    }

    @Override
    public LoginVO login(AuthLoginDTO loginDTO) {
        UserEntity user = userMapper.findByUsernameAndDeletedFalse(normalizeRequired(loginDTO.getUsername()))
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        if (user.getStatus() == UserStatus.DISABLED) {
            throw new BusinessException(ErrorCode.USER_DISABLED);
        }
        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPasswordHash())) {
            throw new BusinessException(ErrorCode.PASSWORD_ERROR);
        }

        SecurityUser securityUser = securityUserDetailsService.loadUserById(user.getId());
        String token = jwtTokenProvider.generateToken(securityUser);
        List<String> roles = securityUser.getAuthorities().stream()
                .map(authority -> authority.getAuthority())
                .filter(authority -> authority.startsWith("ROLE_"))
                .map(authority -> authority.substring(5))
                .toList();

        return LoginVO.builder()
                .token(token)
                .userId(user.getId())
                .username(user.getUsername())
                .roles(roles)
                .build();
    }

    @Override
    @Transactional
    public void logout(Long currentUserId) {
        UserEntity user = userMapper.findByIdAndDeletedFalse(currentUserId)
                .orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
        user.setTokenVersion(user.getTokenVersion() + 1);
        userMapper.save(user);
    }

    private String normalizeRequired(String value) {
        return value == null ? null : value.trim();
    }

    private String normalizeOptional(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return value.trim();
    }
}
