package com.example.learning.quiz.vo;

import com.fasterxml.jackson.databind.JsonNode;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WrongQuestionVO {

    private Long id;
    private Long questionId;
    private Long courseId;
    private Long chapterId;
    private String questionType;
    private String stem;
    private String knowledgePoint;
    private String status;
    private Integer wrongCount;
    private LocalDateTime lastWrongAt;
    private JsonNode standardAnswer;
    private String analysis;
    private List<QuestionOptionVO> options;
}
