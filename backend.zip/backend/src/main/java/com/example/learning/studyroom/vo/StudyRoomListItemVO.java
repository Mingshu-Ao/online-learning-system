package com.example.learning.studyroom.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StudyRoomListItemVO {

    private Long roomId;
    private String roomName;
    private Integer capacity;
    private Long currentOnlineCount;
    private LocalDateTime openTime;
    private LocalDateTime closeTime;
    private String status;
}
