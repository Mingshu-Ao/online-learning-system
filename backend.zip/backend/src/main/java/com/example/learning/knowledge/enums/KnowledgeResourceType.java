package com.example.learning.knowledge.enums;

public enum KnowledgeResourceType {
    CHAPTER,
    VIDEO,
    DOCUMENT,
    QUESTION
}
