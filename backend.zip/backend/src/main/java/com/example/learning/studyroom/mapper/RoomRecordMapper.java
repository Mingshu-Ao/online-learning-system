package com.example.learning.studyroom.mapper;

import com.example.learning.studyroom.entity.RoomRecordEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRecordMapper extends JpaRepository<RoomRecordEntity, Long> {

    Optional<RoomRecordEntity> findBySessionTokenAndDeletedFalse(String sessionToken);
}
