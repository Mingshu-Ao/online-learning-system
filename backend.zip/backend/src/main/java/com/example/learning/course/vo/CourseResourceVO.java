package com.example.learning.course.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseResourceVO {

    private Long id;
    private Long courseId;
    private Long chapterId;
    private String title;
    private String resourceType;
    private String accessType;
    private String fileUrl;
    private String originalFileName;
    private String mimeType;
    private Long fileSize;
    private Long durationSeconds;
    private String transcodingStatus;
    private String coverUrl;
}
