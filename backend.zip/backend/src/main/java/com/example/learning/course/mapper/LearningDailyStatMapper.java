package com.example.learning.course.mapper;

import com.example.learning.course.entity.LearningDailyStatEntity;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LearningDailyStatMapper extends JpaRepository<LearningDailyStatEntity, Long> {

    Optional<LearningDailyStatEntity> findByUserIdAndStatDateAndDeletedFalse(Long userId, LocalDate statDate);

    List<LearningDailyStatEntity> findAllByUserIdAndStatDateBetweenAndDeletedFalseOrderByStatDateAsc(
            Long userId,
            LocalDate startDate,
            LocalDate endDate
    );
}
