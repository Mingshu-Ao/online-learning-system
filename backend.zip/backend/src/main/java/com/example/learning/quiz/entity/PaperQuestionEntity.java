package com.example.learning.quiz.entity;

import com.example.learning.entity.BaseEntity;
import com.example.learning.quiz.enums.QuestionType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.math.BigDecimal;

@Data
@Entity
@Table(name = "paper_question", uniqueConstraints = {
        @UniqueConstraint(name = "uk_paper_question_sort", columnNames = {"paper_id", "sort_order"})
})
@EqualsAndHashCode(callSuper = true)
public class PaperQuestionEntity extends BaseEntity {

    @Column(name = "paper_id", nullable = false)
    private Long paperId;

    @Column(name = "question_id", nullable = false)
    private Long questionId;

    @Column(name = "chapter_id")
    private Long chapterId;

    @Column(name = "sort_order", nullable = false)
    private Integer sortOrder;

    @Column(name = "score", nullable = false, precision = 10, scale = 2)
    private BigDecimal score;

    @Lob
    @Column(name = "question_stem", nullable = false)
    private String questionStem;

    @Enumerated(EnumType.STRING)
    @Column(name = "question_type", nullable = false, length = 32)
    private QuestionType questionType;

    @Lob
    @Column(name = "option_snapshot")
    private String optionSnapshot;

    @Lob
    @Column(name = "standard_answer", nullable = false)
    private String standardAnswer;

    @Lob
    @Column(name = "analysis")
    private String analysis;

    @Column(name = "difficulty", length = 32)
    private String difficulty;

    @Column(name = "knowledge_point", length = 255)
    private String knowledgePoint;

    @Column(name = "partial_credit_enabled", nullable = false)
    private Boolean partialCreditEnabled;
}
