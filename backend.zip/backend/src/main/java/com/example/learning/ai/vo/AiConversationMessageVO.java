package com.example.learning.ai.vo;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AiConversationMessageVO {
    Long messageId;
    String role;
    String inputType;
    String content;
    String fileName;
    String mimeType;
    Long fileSize;
    LocalDateTime createdAt;
    AiAssistantResponseVO structuredResponse;
}
