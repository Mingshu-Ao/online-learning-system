package com.example.learning.ai.vo;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AiRecommendationVO {
    String type;
    Long resourceId;
    String reason;
}
