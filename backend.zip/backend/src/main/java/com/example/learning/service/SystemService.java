package com.example.learning.service;

import com.example.learning.vo.SystemStatusVO;

public interface SystemService {

    SystemStatusVO getSystemStatus();
}

