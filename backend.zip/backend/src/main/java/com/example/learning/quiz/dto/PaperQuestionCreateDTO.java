package com.example.learning.quiz.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class PaperQuestionCreateDTO {

    @NotNull(message = "questionId cannot be null")
    private Long questionId;

    @NotNull(message = "score cannot be null")
    @DecimalMin(value = "0.0", inclusive = false, message = "score must be greater than 0")
    private BigDecimal score;
}
